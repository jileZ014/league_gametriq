import { useState, useEffect } from 'react';

export const useCountUp = (
  end: number,
  start: boolean = true,
  duration: number = 2000,
  startValue: number = 0
): number => {
  const [count, setCount] = useState(startValue);

  useEffect(() => {
    if (!start) return;

    let startTimestamp: number | null = null;
    const step = (timestamp: number) => {
      if (!startTimestamp) startTimestamp = timestamp;
      const progress = Math.min((timestamp - startTimestamp) / duration, 1);
      
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      
      setCount(Math.floor(easeOutQuart * (end - startValue) + startValue));

      if (progress < 1) {
        window.requestAnimationFrame(step);
      }
    };

    window.requestAnimationFrame(step);
  }, [end, start, duration, startValue]);

  return count;
};

export const useStaggerAnimation = (
  itemCount: number,
  baseDelay: number = 0,
  staggerDelay: number = 50
) => {
  const [visibleItems, setVisibleItems] = useState<number[]>([]);

  useEffect(() => {
    const timeouts: NodeJS.Timeout[] = [];
    
    for (let i = 0; i < itemCount; i++) {
      const timeout = setTimeout(() => {
        setVisibleItems(prev => [...prev, i]);
      }, baseDelay + (i * staggerDelay));
      
      timeouts.push(timeout);
    }

    return () => {
      timeouts.forEach(timeout => clearTimeout(timeout));
    };
  }, [itemCount, baseDelay, staggerDelay]);

  return visibleItems;
};