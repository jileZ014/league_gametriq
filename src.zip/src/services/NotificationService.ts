import { databaseService } from './DatabaseService';
import { where, orderBy, limit } from 'firebase/firestore';

export interface Notification {
  id: string;
  userId: string;
  type: 'game_reminder' | 'score_update' | 'schedule_change' | 'payment_due' | 'system';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  data?: any;
  priority: 'low' | 'medium' | 'high';
}

export interface NotificationPreferences {
  userId: string;
  email: boolean;
  push: boolean;
  sms: boolean;
  gameReminders: boolean;
  scoreUpdates: boolean;
  scheduleChanges: boolean;
  paymentReminders: boolean;
  quietHours: {
    enabled: boolean;
    start: string;
    end: string;
  };
}

class NotificationService {
  private static instance: NotificationService;
  private listeners: Map<string, (notification: Notification) => void> = new Map();
  private unreadCount: number = 0;
  private preferences: NotificationPreferences | null = null;

  private constructor() {
    this.setupServiceWorker();
    this.loadPreferences();
  }

  static getInstance(): NotificationService {
    if (!NotificationService.instance) {
      NotificationService.instance = new NotificationService();
    }
    return NotificationService.instance;
  }

  private async setupServiceWorker() {
    if ('serviceWorker' in navigator && 'PushManager' in window) {
      try {
        const registration = await navigator.serviceWorker.register('/sw.js');
        console.log('Service Worker registered:', registration);
      } catch (error) {
        console.error('Service Worker registration failed:', error);
      }
    }
  }

  private async loadPreferences() {
    const userId = localStorage.getItem('userId');
    if (!userId) return;

    try {
      const prefs = await databaseService.getDocument<NotificationPreferences>(
        'notificationPreferences',
        userId
      );
      
      if (prefs) {
        this.preferences = prefs;
      } else {
        // Create default preferences
        this.preferences = {
          userId,
          email: true,
          push: true,
          sms: false,
          gameReminders: true,
          scoreUpdates: true,
          scheduleChanges: true,
          paymentReminders: true,
          quietHours: {
            enabled: false,
            start: '22:00',
            end: '08:00'
          }
        };
        await this.savePreferences(this.preferences);
      }
    } catch (error) {
      console.error('Error loading notification preferences:', error);
    }
  }

  async savePreferences(preferences: NotificationPreferences): Promise<void> {
    this.preferences = preferences;
    try {
      await databaseService.updateDocument(
        'notificationPreferences',
        preferences.userId,
        preferences
      );
    } catch (error) {
      console.error('Error saving notification preferences:', error);
    }
  }

  getPreferences(): NotificationPreferences | null {
    return this.preferences;
  }

  async requestPermission(): Promise<boolean> {
    if (!('Notification' in window)) {
      console.log('This browser does not support notifications');
      return false;
    }

    if (Notification.permission === 'granted') {
      return true;
    }

    if (Notification.permission !== 'denied') {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }

    return false;
  }

  async sendNotification(notification: Omit<Notification, 'id' | 'timestamp' | 'read'>): Promise<void> {
    const userId = localStorage.getItem('userId');
    if (!userId) return;

    // Check quiet hours
    if (this.isInQuietHours()) {
      console.log('Notification suppressed due to quiet hours');
      return;
    }

    // Check preferences
    if (!this.shouldSendNotification(notification.type)) {
      console.log('Notification suppressed due to user preferences');
      return;
    }

    const fullNotification: Notification = {
      ...notification,
      id: `notif_${Date.now()}`,
      timestamp: new Date().toISOString(),
      read: false
    };

    // Save to database
    try {
      await databaseService.createDocument(
        'notifications',
        fullNotification.id,
        fullNotification
      );
    } catch (error) {
      console.error('Error saving notification:', error);
    }

    // Send browser notification if enabled
    if (this.preferences?.push && Notification.permission === 'granted') {
      this.showBrowserNotification(fullNotification);
    }

    // Notify listeners
    this.listeners.forEach(listener => listener(fullNotification));
    
    // Update unread count
    this.unreadCount++;
    this.notifyUnreadCountChange();
  }

  private showBrowserNotification(notification: Notification) {
    const options: NotificationOptions = {
      body: notification.message,
      icon: '/icon-192x192.png',
      badge: '/badge-72x72.png',
      tag: notification.id,
      data: notification.data,
      requireInteraction: notification.priority === 'high'
    };

    if ('serviceWorker' in navigator && navigator.serviceWorker.controller) {
      navigator.serviceWorker.controller.postMessage({
        type: 'SHOW_NOTIFICATION',
        title: notification.title,
        options
      });
    } else {
      new Notification(notification.title, options);
    }
  }

  private isInQuietHours(): boolean {
    if (!this.preferences?.quietHours.enabled) return false;

    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const { start, end } = this.preferences.quietHours;

    if (start < end) {
      return currentTime >= start && currentTime < end;
    } else {
      return currentTime >= start || currentTime < end;
    }
  }

  private shouldSendNotification(type: Notification['type']): boolean {
    if (!this.preferences) return true;

    switch (type) {
      case 'game_reminder':
        return this.preferences.gameReminders;
      case 'score_update':
        return this.preferences.scoreUpdates;
      case 'schedule_change':
        return this.preferences.scheduleChanges;
      case 'payment_due':
        return this.preferences.paymentReminders;
      default:
        return true;
    }
  }

  async getNotifications(userId: string, limit: number = 20): Promise<Notification[]> {
    try {
      const notifications = await databaseService.getCollection<Notification>(
        'notifications',
        [
          where('userId', '==', userId),
          orderBy('timestamp', 'desc'),
          limit(limit)
        ]
      );
      return notifications;
    } catch (error) {
      console.error('Error fetching notifications:', error);
      return [];
    }
  }

  async markAsRead(notificationId: string): Promise<void> {
    try {
      await databaseService.updateDocument('notifications', notificationId, {
        read: true
      });
      this.unreadCount = Math.max(0, this.unreadCount - 1);
      this.notifyUnreadCountChange();
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  }

  async markAllAsRead(userId: string): Promise<void> {
    try {
      const notifications = await this.getNotifications(userId);
      const unreadNotifications = notifications.filter(n => !n.read);
      
      const batch = unreadNotifications.map(n => ({
        type: 'update' as const,
        collection: 'notifications',
        id: n.id,
        data: { read: true }
      }));

      await databaseService.batchWrite(batch);
      this.unreadCount = 0;
      this.notifyUnreadCountChange();
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
    }
  }

  async deleteNotification(notificationId: string): Promise<void> {
    try {
      await databaseService.deleteDocument('notifications', notificationId);
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  }

  subscribeToNotifications(userId: string, callback: (notification: Notification) => void): () => void {
    const key = `user_${userId}`;
    this.listeners.set(key, callback);

    // Subscribe to real-time updates
    const unsubscribe = databaseService.subscribeToCollection(
      'notifications',
      [where('userId', '==', userId), orderBy('timestamp', 'desc')],
      (notifications: Notification[]) => {
        const unreadCount = notifications.filter(n => !n.read).length;
        this.unreadCount = unreadCount;
        this.notifyUnreadCountChange();
      }
    );

    return () => {
      this.listeners.delete(key);
      unsubscribe();
    };
  }

  getUnreadCount(): number {
    return this.unreadCount;
  }

  private notifyUnreadCountChange() {
    window.dispatchEvent(new CustomEvent('unreadCountChanged', {
      detail: { count: this.unreadCount }
    }));
  }

  // Game-specific notifications
  async sendGameReminder(gameId: string, teamNames: string, time: string) {
    await this.sendNotification({
      userId: localStorage.getItem('userId')!,
      type: 'game_reminder',
      title: 'Game Starting Soon',
      message: `${teamNames} starts at ${time}`,
      priority: 'medium',
      data: { gameId }
    });
  }

  async sendScoreUpdate(gameId: string, homeTeam: string, awayTeam: string, homeScore: number, awayScore: number) {
    await this.sendNotification({
      userId: localStorage.getItem('userId')!,
      type: 'score_update',
      title: 'Score Update',
      message: `${homeTeam} ${homeScore} - ${awayScore} ${awayTeam}`,
      priority: 'low',
      data: { gameId, homeScore, awayScore }
    });
  }

  async sendScheduleChange(gameId: string, message: string) {
    await this.sendNotification({
      userId: localStorage.getItem('userId')!,
      type: 'schedule_change',
      title: 'Schedule Change',
      message,
      priority: 'high',
      data: { gameId }
    });
  }

  async sendPaymentReminder(amount: number, dueDate: string) {
    await this.sendNotification({
      userId: localStorage.getItem('userId')!,
      type: 'payment_due',
      title: 'Payment Reminder',
      message: `Payment of $${amount} is due on ${dueDate}`,
      priority: 'high',
      data: { amount, dueDate }
    });
  }
}

export const notificationService = NotificationService.getInstance();

// Helper functions for easy import
export const sendNotification = notificationService.sendNotification.bind(notificationService);
export const getNotifications = notificationService.getNotifications.bind(notificationService);
export const markAsRead = notificationService.markAsRead.bind(notificationService);
export const markAllAsRead = notificationService.markAllAsRead.bind(notificationService);
export const subscribeToNotifications = notificationService.subscribeToNotifications.bind(notificationService);
export const requestPermission = notificationService.requestPermission.bind(notificationService);