import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
  QueryConstraint,
  DocumentData,
  FirestoreError,
  onSnapshot,
  enableNetwork,
  disableNetwork,
  enableIndexedDbPersistence,
  clearIndexedDbPersistence,
  serverTimestamp,
  writeBatch,
  Unsubscribe
} from 'firebase/firestore';
import { db } from '../firebase';

// Database configuration
const RETRY_ATTEMPTS = 3;
const RETRY_DELAY = 1000;
const CONNECTION_TIMEOUT = 10000;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

interface CacheEntry {
  data: any;
  timestamp: number;
}

export class DatabaseService {
  private static instance: DatabaseService;
  private cache: Map<string, CacheEntry> = new Map();
  private listeners: Map<string, Unsubscribe> = new Map();
  private isOnline = true;
  private connectionCheckInterval: NodeJS.Timeout | null = null;
  private offlineQueue: Array<() => Promise<void>> = [];

  private constructor() {
    this.initializeDatabase();
    this.setupConnectionMonitoring();
  }

  static getInstance(): DatabaseService {
    if (!DatabaseService.instance) {
      DatabaseService.instance = new DatabaseService();
    }
    return DatabaseService.instance;
  }

  // Initialize database with offline persistence
  private async initializeDatabase() {
    try {
      // Enable offline persistence
      await enableIndexedDbPersistence(db).catch((err) => {
        if (err.code === 'failed-precondition') {
          console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
        } else if (err.code === 'unimplemented') {
          console.warn('The current browser does not support offline persistence.');
        }
      });

      console.log('Database initialized with offline persistence');
    } catch (error) {
      console.error('Failed to initialize database:', error);
    }
  }

  // Setup connection monitoring
  private setupConnectionMonitoring() {
    // Monitor online/offline status
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());

    // Periodic connection check
    this.connectionCheckInterval = setInterval(() => {
      this.checkConnection();
    }, 30000); // Check every 30 seconds
  }

  // Handle going online
  private async handleOnline() {
    console.log('Connection restored');
    this.isOnline = true;
    
    try {
      await enableNetwork(db);
      // Process offline queue
      await this.processOfflineQueue();
    } catch (error) {
      console.error('Error enabling network:', error);
    }
    
    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent('databaseOnline'));
  }

  // Handle going offline
  private async handleOffline() {
    console.log('Connection lost - switching to offline mode');
    this.isOnline = false;
    
    try {
      await disableNetwork(db);
    } catch (error) {
      console.error('Error disabling network:', error);
    }
    
    // Dispatch event for UI updates
    window.dispatchEvent(new CustomEvent('databaseOffline'));
  }

  // Check connection status
  private async checkConnection() {
    try {
      // Try to fetch a small document to verify connection
      const testDoc = await this.getDocumentWithRetry('system', 'health');
      this.isOnline = true;
    } catch (error) {
      this.isOnline = false;
    }
  }

  // Process offline queue
  private async processOfflineQueue() {
    const queue = [...this.offlineQueue];
    this.offlineQueue = [];
    
    for (const operation of queue) {
      try {
        await operation();
      } catch (error) {
        console.error('Failed to process offline operation:', error);
      }
    }
  }

  // Get document with retry logic
  async getDocument<T = DocumentData>(
    collectionName: string,
    documentId: string,
    useCache = true
  ): Promise<T | null> {
    const cacheKey = `${collectionName}/${documentId}`;
    
    // Check cache first
    if (useCache && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey)!;
      if (Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.data as T;
      }
    }
    
    return this.retryOperation(async () => {
      try {
        const docRef = doc(db, collectionName, documentId);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const data = { id: docSnap.id, ...docSnap.data() } as T;
          
          // Update cache
          this.cache.set(cacheKey, {
            data,
            timestamp: Date.now()
          });
          
          return data;
        }
        
        return null;
      } catch (error) {
        throw this.handleFirestoreError(error as FirestoreError);
      }
    });
  }

  // Get collection with retry logic
  async getCollection<T = DocumentData>(
    collectionName: string,
    constraints: QueryConstraint[] = [],
    useCache = true
  ): Promise<T[]> {
    const cacheKey = `collection:${collectionName}:${JSON.stringify(constraints)}`;
    
    // Check cache first
    if (useCache && this.cache.has(cacheKey)) {
      const cached = this.cache.get(cacheKey)!;
      if (Date.now() - cached.timestamp < CACHE_DURATION) {
        return cached.data as T[];
      }
    }
    
    return this.retryOperation(async () => {
      try {
        const collectionRef = collection(db, collectionName);
        const q = query(collectionRef, ...constraints);
        const querySnapshot = await getDocs(q);
        
        const data = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as T[];
        
        // Update cache
        this.cache.set(cacheKey, {
          data,
          timestamp: Date.now()
        });
        
        return data;
      } catch (error) {
        throw this.handleFirestoreError(error as FirestoreError);
      }
    });
  }

  // Create document with retry logic
  async createDocument(
    collectionName: string,
    documentId: string | null,
    data: any
  ): Promise<string> {
    const operation = async () => {
      return this.retryOperation(async () => {
        try {
          const docData = {
            ...data,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          };
          
          if (documentId) {
            const docRef = doc(db, collectionName, documentId);
            await setDoc(docRef, docData);
            this.invalidateCache(`${collectionName}/${documentId}`);
            return documentId;
          } else {
            const collectionRef = collection(db, collectionName);
            const docRef = doc(collectionRef);
            await setDoc(docRef, docData);
            this.invalidateCache(`collection:${collectionName}`);
            return docRef.id;
          }
        } catch (error) {
          throw this.handleFirestoreError(error as FirestoreError);
        }
      });
    };
    
    if (!this.isOnline) {
      this.offlineQueue.push(operation);
      return 'offline-pending-' + Date.now();
    }
    
    return operation();
  }

  // Update document with retry logic
  async updateDocument(
    collectionName: string,
    documentId: string,
    data: any
  ): Promise<void> {
    const operation = async () => {
      return this.retryOperation(async () => {
        try {
          const docRef = doc(db, collectionName, documentId);
          await updateDoc(docRef, {
            ...data,
            updatedAt: serverTimestamp()
          });
          
          this.invalidateCache(`${collectionName}/${documentId}`);
          this.invalidateCache(`collection:${collectionName}`);
        } catch (error) {
          throw this.handleFirestoreError(error as FirestoreError);
        }
      });
    };
    
    if (!this.isOnline) {
      this.offlineQueue.push(operation);
      return;
    }
    
    return operation();
  }

  // Delete document with retry logic
  async deleteDocument(
    collectionName: string,
    documentId: string
  ): Promise<void> {
    const operation = async () => {
      return this.retryOperation(async () => {
        try {
          const docRef = doc(db, collectionName, documentId);
          await deleteDoc(docRef);
          
          this.invalidateCache(`${collectionName}/${documentId}`);
          this.invalidateCache(`collection:${collectionName}`);
        } catch (error) {
          throw this.handleFirestoreError(error as FirestoreError);
        }
      });
    };
    
    if (!this.isOnline) {
      this.offlineQueue.push(operation);
      return;
    }
    
    return operation();
  }

  // Batch write operations
  async batchWrite(operations: Array<{
    type: 'create' | 'update' | 'delete';
    collection: string;
    id: string;
    data?: any;
  }>): Promise<void> {
    return this.retryOperation(async () => {
      try {
        const batch = writeBatch(db);
        
        for (const op of operations) {
          const docRef = doc(db, op.collection, op.id);
          
          switch (op.type) {
            case 'create':
              batch.set(docRef, {
                ...op.data,
                createdAt: serverTimestamp(),
                updatedAt: serverTimestamp()
              });
              break;
            case 'update':
              batch.update(docRef, {
                ...op.data,
                updatedAt: serverTimestamp()
              });
              break;
            case 'delete':
              batch.delete(docRef);
              break;
          }
        }
        
        await batch.commit();
        
        // Invalidate relevant caches
        for (const op of operations) {
          this.invalidateCache(`${op.collection}/${op.id}`);
        }
      } catch (error) {
        throw this.handleFirestoreError(error as FirestoreError);
      }
    });
  }

  // Subscribe to document changes
  subscribeToDocument(
    collectionName: string,
    documentId: string,
    callback: (data: any) => void
  ): () => void {
    const key = `${collectionName}/${documentId}`;
    
    // Unsubscribe from existing listener
    if (this.listeners.has(key)) {
      this.listeners.get(key)!();
    }
    
    const docRef = doc(db, collectionName, documentId);
    const unsubscribe = onSnapshot(
      docRef,
      (doc) => {
        if (doc.exists()) {
          const data = { id: doc.id, ...doc.data() };
          callback(data);
          
          // Update cache
          this.cache.set(key, {
            data,
            timestamp: Date.now()
          });
        } else {
          callback(null);
        }
      },
      (error) => {
        console.error('Snapshot error:', error);
        callback(null);
      }
    );
    
    this.listeners.set(key, unsubscribe);
    
    return () => {
      unsubscribe();
      this.listeners.delete(key);
    };
  }

  // Subscribe to collection changes
  subscribeToCollection(
    collectionName: string,
    constraints: QueryConstraint[],
    callback: (data: any[]) => void
  ): () => void {
    const key = `collection:${collectionName}:${JSON.stringify(constraints)}`;
    
    // Unsubscribe from existing listener
    if (this.listeners.has(key)) {
      this.listeners.get(key)!();
    }
    
    const collectionRef = collection(db, collectionName);
    const q = query(collectionRef, ...constraints);
    const unsubscribe = onSnapshot(
      q,
      (querySnapshot) => {
        const data = querySnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        
        callback(data);
        
        // Update cache
        this.cache.set(key, {
          data,
          timestamp: Date.now()
        });
      },
      (error) => {
        console.error('Snapshot error:', error);
        callback([]);
      }
    );
    
    this.listeners.set(key, unsubscribe);
    
    return () => {
      unsubscribe();
      this.listeners.delete(key);
    };
  }

  // Invalidate cache
  private invalidateCache(pattern?: string) {
    if (!pattern) {
      this.cache.clear();
      return;
    }
    
    for (const key of this.cache.keys()) {
      if (key.includes(pattern)) {
        this.cache.delete(key);
      }
    }
  }

  // Retry operation with exponential backoff
  private async retryOperation<T>(
    operation: () => Promise<T>,
    attempts = RETRY_ATTEMPTS,
    delay = RETRY_DELAY
  ): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      if (attempts <= 1) {
        throw error;
      }
      
      console.log(`Retrying operation, ${attempts - 1} attempts remaining`);
      
      await new Promise(resolve => setTimeout(resolve, delay));
      
      return this.retryOperation(
        operation,
        attempts - 1,
        delay * 2 // Exponential backoff
      );
    }
  }

  // Handle Firestore errors
  private handleFirestoreError(error: FirestoreError): Error {
    let message = 'A database error occurred.';
    
    switch (error.code) {
      case 'cancelled':
        message = 'Operation was cancelled.';
        break;
      case 'unknown':
        message = 'An unknown error occurred.';
        break;
      case 'invalid-argument':
        message = 'Invalid data provided.';
        break;
      case 'deadline-exceeded':
        message = 'Operation timed out.';
        break;
      case 'not-found':
        message = 'Document not found.';
        break;
      case 'already-exists':
        message = 'Document already exists.';
        break;
      case 'permission-denied':
        message = 'Permission denied.';
        break;
      case 'resource-exhausted':
        message = 'Resource limit exceeded.';
        break;
      case 'failed-precondition':
        message = 'Operation failed due to precondition.';
        break;
      case 'aborted':
        message = 'Operation aborted.';
        break;
      case 'out-of-range':
        message = 'Operation out of valid range.';
        break;
      case 'unimplemented':
        message = 'Operation not implemented.';
        break;
      case 'internal':
        message = 'Internal server error.';
        break;
      case 'unavailable':
        message = 'Service temporarily unavailable.';
        break;
      case 'data-loss':
        message = 'Unrecoverable data loss.';
        break;
      case 'unauthenticated':
        message = 'User not authenticated.';
        break;
      default:
        message = error.message || message;
    }
    
    const enhancedError = new Error(message);
    enhancedError.name = error.code || 'DatabaseError';
    return enhancedError;
  }

  // Get document with retry (helper for connection check)
  private async getDocumentWithRetry(
    collectionName: string,
    documentId: string
  ): Promise<any> {
    const docRef = doc(db, collectionName, documentId);
    const timeout = new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Connection timeout')), CONNECTION_TIMEOUT)
    );
    
    try {
      const result = await Promise.race([
        getDoc(docRef),
        timeout
      ]);
      return result;
    } catch (error) {
      throw error;
    }
  }

  // Cleanup
  destroy() {
    // Clear all listeners
    for (const unsubscribe of this.listeners.values()) {
      unsubscribe();
    }
    this.listeners.clear();
    
    // Clear cache
    this.cache.clear();
    
    // Clear connection check interval
    if (this.connectionCheckInterval) {
      clearInterval(this.connectionCheckInterval);
    }
    
    // Remove event listeners
    window.removeEventListener('online', () => this.handleOnline());
    window.removeEventListener('offline', () => this.handleOffline());
  }

  // Get connection status
  getConnectionStatus(): boolean {
    return this.isOnline;
  }

  // Get offline queue size
  getOfflineQueueSize(): number {
    return this.offlineQueue.length;
  }

  // Clear offline queue
  clearOfflineQueue(): void {
    this.offlineQueue = [];
  }
}

// Export singleton instance
export const databaseService = DatabaseService.getInstance();

// Export convenience functions
export const dbGet = databaseService.getDocument.bind(databaseService);
export const dbGetAll = databaseService.getCollection.bind(databaseService);
export const dbCreate = databaseService.createDocument.bind(databaseService);
export const dbUpdate = databaseService.updateDocument.bind(databaseService);
export const dbDelete = databaseService.deleteDocument.bind(databaseService);
export const dbBatch = databaseService.batchWrite.bind(databaseService);
export const dbSubscribe = databaseService.subscribeToDocument.bind(databaseService);
export const dbSubscribeCollection = databaseService.subscribeToCollection.bind(databaseService);