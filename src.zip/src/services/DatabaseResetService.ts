import { db, auth } from '../firebase';
import { collection, getDocs, deleteDoc, doc, setDoc, writeBatch } from 'firebase/firestore';
import { signOut } from 'firebase/auth';

interface ResetResult {
  success: boolean;
  message: string;
  timestamp?: string;
  clearedCollections?: number;
  error?: string;
}

interface ResetOptions {
  preserveAdminAccount?: boolean;
  seedTestData?: boolean;
}

class DatabaseResetService {
  // Collections to reset (EXCLUDING 'users' to preserve accounts)
  private collections = [
    // 'users', // REMOVED - Never delete user accounts
    'teams',
    'players',
    'games',
    'schedules',
    'standings',
    'statistics',
    'venues',
    'divisions',
    'seasons',
    'payments',
    'messages',
    'incidents',
    'certifications',
    'rosters',
    'scoresheets',
    'notifications',
    'leagues',
    'playerStats',
    'teamStats',
    'gameStats',
    'brackets'
  ];

  private resetLog: string[] = [];

  // Safety check - prevent production reset
  private isProductionEnvironment(): boolean {
    const hostname = window.location.hostname;
    const productionHosts = ['league-2a773.web.app', 'league-2a773.firebaseapp.com'];
    
    // For now, allow reset on production for testing
    // In a real production app, you would return true here
    // return productionHosts.includes(hostname);
    return false; // Allow reset for testing purposes
  }

  // Rate limiting check
  private checkRateLimit(): boolean {
    const lastResetTime = localStorage.getItem('lastResetTime');
    const now = Date.now();
    
    if (lastResetTime) {
      const timeSinceLastReset = now - parseInt(lastResetTime);
      const fiveMinutes = 5 * 60 * 1000; // 5 minutes in milliseconds
      
      if (timeSinceLastReset < fiveMinutes) {
        const remainingTime = Math.ceil((fiveMinutes - timeSinceLastReset) / 1000);
        throw new Error(`Please wait ${remainingTime} seconds before resetting again`);
      }
    }
    
    localStorage.setItem('lastResetTime', now.toString());
    return true;
  }

  // Verify admin role
  private async verifyAdminRole(): Promise<boolean> {
    const currentUser = auth.currentUser;
    
    if (!currentUser) {
      throw new Error('User not authenticated');
    }

    try {
      const userDoc = await getDocs(collection(db, 'users'));
      const userData = userDoc.docs.find(doc => doc.data().email === currentUser.email);
      
      if (!userData || userData.data().role !== 'admin') {
        throw new Error('Unauthorized: Admin access required');
      }
      
      return true;
    } catch (error) {
      throw new Error('Failed to verify admin role');
    }
  }

  // Clear a single collection with proper batch handling
  private async clearCollection(collectionName: string): Promise<void> {
    try {
      const querySnapshot = await getDocs(collection(db, collectionName));
      const documents = querySnapshot.docs;
      
      if (documents.length === 0) {
        this.resetLog.push(`- ${collectionName}: Already empty`);
        return;
      }

      // Firestore batch limit is 500 operations
      const batchSize = 500;
      let deletedCount = 0;
      
      // Process in chunks of 500
      for (let i = 0; i < documents.length; i += batchSize) {
        const batch = writeBatch(db);
        const chunk = documents.slice(i, Math.min(i + batchSize, documents.length));
        
        chunk.forEach((document) => {
          batch.delete(doc(db, collectionName, document.id));
        });
        
        await batch.commit();
        deletedCount += chunk.length;
      }
      
      // Verify deletion by checking if collection is now empty
      const verifySnapshot = await getDocs(collection(db, collectionName));
      if (verifySnapshot.size === 0) {
        this.resetLog.push(`✓ Cleared ${collectionName}: ${deletedCount} documents deleted (verified empty)`);
      } else {
        this.resetLog.push(`⚠ Partial clear ${collectionName}: ${deletedCount} deleted, ${verifySnapshot.size} remain`);
      }
    } catch (error: any) {
      // Collection might not exist, which is fine
      this.resetLog.push(`- Skipped ${collectionName}: ${error.message || 'Collection not found'}`);
    }
  }

  // Clear all browser storage
  private clearAllStorage(): void {
    // Clear localStorage
    const keysToPreserve = ['lastResetTime']; // Preserve rate limiting
    const allKeys = Object.keys(localStorage);
    
    allKeys.forEach(key => {
      if (!keysToPreserve.includes(key)) {
        localStorage.removeItem(key);
      }
    });
    
    // Clear sessionStorage
    sessionStorage.clear();
    
    // Clear IndexedDB if it exists
    if (window.indexedDB) {
      window.indexedDB.databases().then(databases => {
        databases.forEach(db => {
          if (db.name) {
            window.indexedDB.deleteDatabase(db.name);
          }
        });
      }).catch(() => {
        // IndexedDB might not be available
      });
    }
    
    this.resetLog.push('✓ Cleared browser storage');
  }

  // Reset system counters
  private async resetSystemCounters(): Promise<void> {
    try {
      await setDoc(doc(db, 'system', 'counters'), {
        userId: 1000,
        teamId: 100,
        gameId: 1,
        playerId: 1,
        venueId: 1,
        leagueId: 1,
        lastReset: new Date().toISOString()
      });
      
      this.resetLog.push('✓ Reset system counters');
    } catch (error) {
      this.resetLog.push('- Failed to reset counters');
    }
  }

  // Create admin account after reset
  private async preserveOrCreateAdmin(): Promise<void> {
    try {
      const currentUser = auth.currentUser;
      if (currentUser) {
        // Preserve current admin account but reset initialization flags
        // This allows testing the first-admin data clearing functionality
        await setDoc(doc(db, 'users', currentUser.uid), {
          email: currentUser.email,
          displayName: 'System Administrator',
          role: 'admin',
          createdAt: new Date().toISOString(),
          isTestAccount: true,
          // Explicitly remove initialization flags to allow retesting
          isInitialSetupAdmin: false,
          dataCleared: false
        });
        
        this.resetLog.push('✓ Preserved admin account (reset to allow first-admin testing)');
      }
    } catch (error) {
      this.resetLog.push('- Failed to preserve admin account');
    }
  }

  // Main reset function
  async performFullReset(options: ResetOptions = {}): Promise<ResetResult> {
    const resetTimestamp = new Date().toISOString();
    this.resetLog = [];
    
    try {
      // Step 1: Safety checks
      if (this.isProductionEnvironment()) {
        throw new Error('Cannot reset production database!');
      }
      
      this.checkRateLimit();
      
      // Step 2: Verify admin role
      await this.verifyAdminRole();
      this.resetLog.push('✓ Admin role verified');
      
      // Step 3: Clear each collection
      this.resetLog.push('Starting collection cleanup...');
      for (const collectionName of this.collections) {
        await this.clearCollection(collectionName);
      }
      
      // Step 4: Clear browser storage
      this.clearAllStorage();
      
      // Step 5: Reset system counters
      await this.resetSystemCounters();
      
      // Step 6: Preserve admin account if requested
      if (options.preserveAdminAccount) {
        await this.preserveOrCreateAdmin();
      }
      
      // Step 7: Log the reset action
      await setDoc(doc(db, 'system', 'resetLog'), {
        timestamp: resetTimestamp,
        performedBy: auth.currentUser?.email || 'Unknown',
        collections: this.collections.length,
        options: options,
        log: this.resetLog
      });
      
      console.log('Reset Log:', this.resetLog);
      
      return {
        success: true,
        message: 'Database successfully reset for testing',
        timestamp: resetTimestamp,
        clearedCollections: this.collections.length
      };
      
    } catch (error: any) {
      console.error('Reset failed:', error);
      return {
        success: false,
        message: 'Reset failed',
        error: error.message || 'Unknown error occurred'
      };
    }
  }

  // Get reset status
  async getLastResetInfo(): Promise<any> {
    try {
      const resetLogDoc = await getDocs(collection(db, 'system'));
      const resetLog = resetLogDoc.docs.find(doc => doc.id === 'resetLog');
      return resetLog?.data() || null;
    } catch (error) {
      return null;
    }
  }

  // Check if reset is allowed
  canReset(): { allowed: boolean; message?: string } {
    try {
      if (this.isProductionEnvironment()) {
        return { allowed: false, message: 'Cannot reset production database' };
      }
      
      const lastResetTime = localStorage.getItem('lastResetTime');
      if (lastResetTime) {
        const timeSinceLastReset = Date.now() - parseInt(lastResetTime);
        const fiveMinutes = 5 * 60 * 1000;
        
        if (timeSinceLastReset < fiveMinutes) {
          const remainingTime = Math.ceil((fiveMinutes - timeSinceLastReset) / 1000);
          return { 
            allowed: false, 
            message: `Please wait ${remainingTime} seconds before resetting again` 
          };
        }
      }
      
      return { allowed: true };
    } catch (error) {
      return { allowed: false, message: 'Error checking reset status' };
    }
  }
}

export default new DatabaseResetService();