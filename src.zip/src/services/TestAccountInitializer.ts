import { db, auth } from '../firebase';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from 'firebase/auth';

interface TestAccount {
  email: string;
  password: string;
  displayName: string;
  role: string;
  uid?: string;
}

class TestAccountInitializer {
  private testAccounts: TestAccount[] = [
    {
      email: 'admin@legacytest.com',
      password: 'TestAdmin123!',
      displayName: 'Test Administrator',
      role: 'admin',
      uid: 'test-admin-001'
    },
    {
      email: 'coach1@legacytest.com',
      password: 'TestCoach123!',
      displayName: 'Coach Johnson',
      role: 'coach',
      uid: 'test-coach-001'
    },
    {
      email: 'coach2@legacytest.com',
      password: 'TestCoach123!',
      displayName: 'Coach Williams',
      role: 'coach',
      uid: 'test-coach-002'
    },
    {
      email: 'coach3@legacytest.com',
      password: 'TestCoach123!',
      displayName: 'Coach Martinez',
      role: 'coach',
      uid: 'test-coach-003'
    },
    {
      email: 'scorekeeper@legacytest.com',
      password: 'TestScore123!',
      displayName: 'Score Keeper',
      role: 'scorekeeper',
      uid: 'test-scorekeeper-001'
    },
    {
      email: 'director@legacytest.com',
      password: 'TestDirector123!',
      displayName: 'Site Director',
      role: 'site-director',
      uid: 'test-director-001'
    }
  ];

  // Initialize all test accounts
  async initializeTestAccounts(): Promise<{ success: boolean; message: string; details?: any }> {
    const results = [];
    const currentUser = auth.currentUser;
    
    try {
      console.log('Starting test account initialization...');
      
      for (const account of this.testAccounts) {
        try {
          // Try to create the account first
          const result = await this.createTestAccount(account);
          results.push(result);
        } catch (error: any) {
          // If account exists, try to update it
          if (error.code === 'auth/email-already-in-use') {
            const updateResult = await this.updateExistingTestAccount(account);
            results.push(updateResult);
          } else {
            results.push({
              email: account.email,
              success: false,
              error: error.message
            });
          }
        }
      }

      // Restore original user session if there was one
      if (currentUser) {
        // Sign back in as the original user if we have their credentials cached
        // This is a limitation - we can't restore the exact session
        await signOut(auth);
      }

      const successCount = results.filter(r => r.success).length;
      const failCount = results.filter(r => !r.success).length;

      return {
        success: failCount === 0,
        message: `Initialized ${successCount} test accounts${failCount > 0 ? `, ${failCount} failed` : ''}`,
        details: results
      };
    } catch (error: any) {
      console.error('Test account initialization failed:', error);
      return {
        success: false,
        message: `Initialization failed: ${error.message}`,
        details: results
      };
    }
  }

  // Create a single test account
  private async createTestAccount(account: TestAccount): Promise<any> {
    try {
      // Create Firebase Auth account
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        account.email,
        account.password
      );

      // Create Firestore user document
      await setDoc(doc(db, 'users', userCredential.user.uid), {
        uid: userCredential.user.uid,
        email: account.email,
        displayName: account.displayName,
        role: account.role,
        isTestAccount: true,
        createdAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        testCredentials: {
          password: account.password, // Store for test purposes only
          originalTestUid: account.uid
        }
      });

      // Sign out after creating account
      await signOut(auth);

      return {
        email: account.email,
        success: true,
        uid: userCredential.user.uid,
        message: `Created test account: ${account.email}`
      };
    } catch (error: any) {
      throw error;
    }
  }

  // Update existing test account
  private async updateExistingTestAccount(account: TestAccount): Promise<any> {
    try {
      // Try to sign in to verify the account exists
      const userCredential = await signInWithEmailAndPassword(
        auth,
        account.email,
        account.password
      );

      // Update the user document
      await setDoc(doc(db, 'users', userCredential.user.uid), {
        uid: userCredential.user.uid,
        email: account.email,
        displayName: account.displayName,
        role: account.role,
        isTestAccount: true,
        updatedAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        testCredentials: {
          password: account.password,
          originalTestUid: account.uid
        }
      }, { merge: true });

      // Sign out after updating
      await signOut(auth);

      return {
        email: account.email,
        success: true,
        uid: userCredential.user.uid,
        message: `Updated existing test account: ${account.email}`
      };
    } catch (error: any) {
      return {
        email: account.email,
        success: false,
        error: `Failed to update: ${error.message}`
      };
    }
  }

  // Verify test accounts exist and can log in
  async verifyTestAccounts(): Promise<{ success: boolean; results: any[] }> {
    const results = [];
    const currentUser = auth.currentUser;

    for (const account of this.testAccounts) {
      try {
        // Try to sign in
        const userCredential = await signInWithEmailAndPassword(
          auth,
          account.email,
          account.password
        );

        // Check if user document exists
        const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
        
        results.push({
          email: account.email,
          success: true,
          hasAuth: true,
          hasDocument: userDoc.exists(),
          role: userDoc.data()?.role || 'not set',
          uid: userCredential.user.uid
        });

        // Sign out
        await signOut(auth);
      } catch (error: any) {
        results.push({
          email: account.email,
          success: false,
          error: error.message
        });
      }
    }

    // Restore original session if needed
    if (currentUser) {
      // Note: We can't restore the exact session without credentials
      await signOut(auth);
    }

    const allSuccess = results.every(r => r.success);
    return {
      success: allSuccess,
      results
    };
  }

  // Get test credentials for display
  getTestCredentials(): any {
    return {
      admin: {
        email: 'admin@legacytest.com',
        password: 'TestAdmin123!',
        role: 'Admin',
        description: 'Full system access'
      },
      coach: {
        email: 'coach1@legacytest.com',
        password: 'TestCoach123!',
        role: 'Coach',
        description: 'Team management access'
      },
      scorekeeper: {
        email: 'scorekeeper@legacytest.com',
        password: 'TestScore123!',
        role: 'Scorekeeper',
        description: 'Game scoring access'
      },
      siteDirector: {
        email: 'director@legacytest.com',
        password: 'TestDirector123!',
        role: 'Site Director',
        description: 'Venue management access'
      },
      additionalCoaches: [
        {
          email: 'coach2@legacytest.com',
          password: 'TestCoach123!',
          displayName: 'Coach Williams'
        },
        {
          email: 'coach3@legacytest.com',
          password: 'TestCoach123!',
          displayName: 'Coach Martinez'
        }
      ]
    };
  }

  // Check if an email is a test account
  isTestAccount(email: string): boolean {
    return this.testAccounts.some(account => account.email === email);
  }

  // Get test account info by email
  getTestAccountInfo(email: string): TestAccount | null {
    return this.testAccounts.find(account => account.email === email) || null;
  }
}

export default new TestAccountInitializer();