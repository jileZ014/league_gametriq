import { 
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  onAuthStateChanged,
  User as FirebaseUser,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
  AuthError
} from 'firebase/auth';
import { auth, googleProvider, db } from '../firebase';
import { doc, getDoc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import type { User, UserRole } from '../types';

// Session configuration
const SESSION_TIMEOUT = 24 * 60 * 60 * 1000; // 24 hours
const SESSION_WARNING = 30 * 60 * 1000; // 30 minutes before timeout

export class AuthService {
  private static instance: AuthService;
  private sessionTimer: NodeJS.Timeout | null = null;
  private warningTimer: NodeJS.Timeout | null = null;
  private retryCount = 0;
  private maxRetries = 3;
  private retryDelay = 1000;

  private constructor() {
    this.initializeSessionManagement();
  }

  static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  // Initialize session management
  private initializeSessionManagement() {
    // Set persistence to local (survives browser restart)
    setPersistence(auth, browserLocalPersistence).catch(error => {
      console.error('Failed to set persistence:', error);
      // Fallback to session persistence
      setPersistence(auth, browserSessionPersistence);
    });

    // Monitor auth state changes
    onAuthStateChanged(auth, (user) => {
      if (user) {
        this.startSessionTimer();
        this.updateLastActivity(user.uid);
      } else {
        this.clearSessionTimers();
      }
    });
  }

  // Start session timeout timer
  private startSessionTimer() {
    this.clearSessionTimers();
    
    // Warning timer - 30 minutes before timeout
    this.warningTimer = setTimeout(() => {
      this.showSessionWarning();
    }, SESSION_TIMEOUT - SESSION_WARNING);

    // Timeout timer
    this.sessionTimer = setTimeout(() => {
      this.handleSessionTimeout();
    }, SESSION_TIMEOUT);
  }

  // Clear all session timers
  private clearSessionTimers() {
    if (this.sessionTimer) {
      clearTimeout(this.sessionTimer);
      this.sessionTimer = null;
    }
    if (this.warningTimer) {
      clearTimeout(this.warningTimer);
      this.warningTimer = null;
    }
  }

  // Show session warning
  private showSessionWarning() {
    // Dispatch custom event for UI to handle
    window.dispatchEvent(new CustomEvent('sessionWarning', {
      detail: { minutesRemaining: 30 }
    }));
  }

  // Handle session timeout
  private async handleSessionTimeout() {
    try {
      await this.logout();
      window.dispatchEvent(new CustomEvent('sessionTimeout'));
    } catch (error) {
      console.error('Error during session timeout:', error);
    }
  }

  // Update last activity timestamp
  private async updateLastActivity(userId: string) {
    try {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, {
        lastActivity: serverTimestamp(),
        lastLogin: serverTimestamp()
      });
    } catch (error) {
      console.error('Failed to update last activity:', error);
    }
  }

  // Login with Google
  async loginWithGoogle(): Promise<User> {
    return this.retryOperation(async () => {
      try {
        const result = await signInWithPopup(auth, googleProvider);
        return await this.processAuthResult(result.user);
      } catch (error) {
        throw this.handleAuthError(error as AuthError);
      }
    });
  }

  // Login with email and password
  async loginWithEmail(email: string, password: string): Promise<User> {
    return this.retryOperation(async () => {
      try {
        const result = await signInWithEmailAndPassword(auth, email, password);
        return await this.processAuthResult(result.user);
      } catch (error) {
        throw this.handleAuthError(error as AuthError);
      }
    });
  }

  // Register with email and password
  async registerWithEmail(email: string, password: string, displayName: string): Promise<User> {
    return this.retryOperation(async () => {
      try {
        const result = await createUserWithEmailAndPassword(auth, email, password);
        // Update display name
        await result.user.updateProfile({ displayName });
        return await this.processAuthResult(result.user);
      } catch (error) {
        throw this.handleAuthError(error as AuthError);
      }
    });
  }

  // Process authentication result
  private async processAuthResult(firebaseUser: FirebaseUser): Promise<User> {
    try {
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        const userData = userDoc.data();
        
        // Update last login
        await updateDoc(userDocRef, {
          lastLogin: serverTimestamp(),
          lastActivity: serverTimestamp()
        });
        
        return {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          displayName: firebaseUser.displayName || userData.displayName || '',
          role: userData.role as UserRole || null,
          photoURL: firebaseUser.photoURL || userData.photoURL || null
        };
      } else {
        // Create new user document
        const newUserData = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName || 'User',
          role: null,
          photoURL: firebaseUser.photoURL || null,
          createdAt: serverTimestamp(),
          lastLogin: serverTimestamp(),
          lastActivity: serverTimestamp(),
          status: 'active'
        };
        
        await setDoc(userDocRef, newUserData);
        
        return {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          displayName: firebaseUser.displayName || 'User',
          role: null,
          photoURL: firebaseUser.photoURL || null
        };
      }
    } catch (error) {
      console.error('Error processing auth result:', error);
      throw new Error('Failed to process authentication. Please try again.');
    }
  }

  // Update user role
  async updateUserRole(userId: string, role: UserRole): Promise<void> {
    try {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, {
        role,
        roleUpdatedAt: serverTimestamp()
      });
    } catch (error) {
      console.error('Failed to update user role:', error);
      throw new Error('Failed to update role. Please try again.');
    }
  }

  // Logout
  async logout(): Promise<void> {
    try {
      // Clear session timers
      this.clearSessionTimers();
      
      // Update last activity before logout
      if (auth.currentUser) {
        await this.updateLastActivity(auth.currentUser.uid);
      }
      
      // Sign out
      await signOut(auth);
      
      // Clear any cached data
      sessionStorage.clear();
      
      // Dispatch logout event
      window.dispatchEvent(new CustomEvent('userLogout'));
    } catch (error) {
      console.error('Logout error:', error);
      throw new Error('Failed to logout. Please try again.');
    }
  }

  // Reset password
  async resetPassword(email: string): Promise<void> {
    try {
      await sendPasswordResetEmail(auth, email);
    } catch (error) {
      throw this.handleAuthError(error as AuthError);
    }
  }

  // Get current user
  getCurrentUser(): FirebaseUser | null {
    return auth.currentUser;
  }

  // Check if user is authenticated
  isAuthenticated(): boolean {
    return !!auth.currentUser;
  }

  // Refresh user session
  async refreshSession(): Promise<void> {
    if (auth.currentUser) {
      this.startSessionTimer();
      await this.updateLastActivity(auth.currentUser.uid);
    }
  }

  // Retry operation with exponential backoff
  private async retryOperation<T>(operation: () => Promise<T>): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      if (this.retryCount < this.maxRetries) {
        this.retryCount++;
        const delay = this.retryDelay * Math.pow(2, this.retryCount - 1);
        
        console.log(`Retrying operation (attempt ${this.retryCount}/${this.maxRetries}) after ${delay}ms`);
        
        await new Promise(resolve => setTimeout(resolve, delay));
        return this.retryOperation(operation);
      } else {
        this.retryCount = 0;
        throw error;
      }
    }
  }

  // Handle authentication errors
  private handleAuthError(error: AuthError): Error {
    let message = 'An authentication error occurred.';
    
    switch (error.code) {
      case 'auth/user-not-found':
        message = 'No account found with this email address.';
        break;
      case 'auth/wrong-password':
        message = 'Incorrect password. Please try again.';
        break;
      case 'auth/invalid-email':
        message = 'Invalid email address format.';
        break;
      case 'auth/user-disabled':
        message = 'This account has been disabled. Contact support.';
        break;
      case 'auth/too-many-requests':
        message = 'Too many failed attempts. Please try again later.';
        break;
      case 'auth/network-request-failed':
        message = 'Network error. Please check your connection.';
        break;
      case 'auth/popup-closed-by-user':
        message = 'Sign-in cancelled.';
        break;
      case 'auth/popup-blocked':
        message = 'Sign-in popup blocked. Please allow popups.';
        break;
      case 'auth/invalid-credential':
        message = 'Invalid credentials. Please try again.';
        break;
      case 'auth/operation-not-allowed':
        message = 'This sign-in method is not enabled.';
        break;
      case 'auth/weak-password':
        message = 'Password is too weak. Use at least 6 characters.';
        break;
      case 'auth/email-already-in-use':
        message = 'An account already exists with this email.';
        break;
      default:
        message = error.message || message;
    }
    
    const enhancedError = new Error(message);
    enhancedError.name = error.code || 'AuthError';
    return enhancedError;
  }

  // Verify user session is still valid
  async verifySession(): Promise<boolean> {
    try {
      if (!auth.currentUser) return false;
      
      // Force token refresh to verify session
      await auth.currentUser.getIdToken(true);
      
      // Check last activity
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (userDoc.exists()) {
        const lastActivity = userDoc.data().lastActivity;
        if (lastActivity) {
          const timeSinceActivity = Date.now() - lastActivity.toMillis();
          if (timeSinceActivity > SESSION_TIMEOUT) {
            await this.logout();
            return false;
          }
        }
      }
      
      return true;
    } catch (error) {
      console.error('Session verification failed:', error);
      return false;
    }
  }
}

// Export singleton instance
export const authService = AuthService.getInstance();