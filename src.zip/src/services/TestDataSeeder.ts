import { db, auth } from '../firebase';
import { collection, doc, setDoc, addDoc } from 'firebase/firestore';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { leagueConfig, getLeagueCollection } from '../config/league.config';

interface TestVenue {
  name: string;
  courts: number;
  address: string;
}

interface TestDivision {
  name: string;
  ageGroup: string;
  maxTeams: number;
}

class TestDataSeeder {
  // Basic test data configuration
  private testData = {
    admin: {
      email: 'admin@legacytest.com',
      password: 'TestAdmin123!',
      displayName: 'Test Administrator',
      role: 'admin'
    },
    
    coaches: [
      {
        email: 'coach1@legacytest.com',
        password: 'TestCoach123!',
        displayName: 'Coach Johnson',
        role: 'coach',
        teamName: 'Phoenix Suns Jr'
      },
      {
        email: 'coach2@legacytest.com',
        password: 'TestCoach123!',
        displayName: 'Coach Williams',
        role: 'coach',
        teamName: 'Desert Storm'
      },
      {
        email: 'coach3@legacytest.com',
        password: 'TestCoach123!',
        displayName: 'Coach Martinez',
        role: 'coach',
        teamName: 'Valley Vipers'
      }
    ],
    
    scorekeeper: {
      email: 'scorekeeper@legacytest.com',
      password: 'TestScore123!',
      displayName: 'Score Keeper',
      role: 'scorekeeper'
    },
    
    siteDirector: {
      email: 'director@legacytest.com',
      password: 'TestDirector123!',
      displayName: 'Site Director',
      role: 'site-director'
    },
    
    venues: [
      { name: 'Legacy Main Gymnasium', courts: 3, address: '123 Champions Way, Phoenix, AZ 85001' },
      { name: 'Phoenix Recreation Center', courts: 2, address: '456 Game Street, Phoenix, AZ 85002' },
      { name: 'Desert Palms Middle School', courts: 2, address: '789 School Road, Phoenix, AZ 85003' },
      { name: 'Valley Community Center', courts: 1, address: '321 Community Drive, Phoenix, AZ 85004' },
      { name: 'Legacy Sports Complex', courts: 4, address: '654 Athletic Avenue, Phoenix, AZ 85005' }
    ],
    
    divisions: [
      { name: '3rd Grade Boys', ageGroup: '8-9', maxTeams: 8 },
      { name: '4th Grade Boys', ageGroup: '9-10', maxTeams: 8 },
      { name: '5th Grade Boys', ageGroup: '10-11', maxTeams: 10 },
      { name: '6th Grade Boys', ageGroup: '11-12', maxTeams: 10 },
      { name: '7th Grade Boys', ageGroup: '12-13', maxTeams: 12 },
      { name: '8th Grade Boys', ageGroup: '13-14', maxTeams: 12 },
      { name: 'JV Division', ageGroup: '14-15', maxTeams: 8 },
      { name: 'Varsity Division', ageGroup: '15-18', maxTeams: 8 }
    ],
    
    teams: [
      {
        name: 'Phoenix Suns Jr',
        division: '5th Grade Boys',
        coachName: 'Coach Johnson',
        primaryColor: '#1D1160',
        secondaryColor: '#E56020',
        wins: 0,
        losses: 0
      },
      {
        name: 'Desert Storm',
        division: '5th Grade Boys',
        coachName: 'Coach Williams',
        primaryColor: '#FDB927',
        secondaryColor: '#552583',
        wins: 0,
        losses: 0
      },
      {
        name: 'Valley Vipers',
        division: '5th Grade Boys',
        coachName: 'Coach Martinez',
        primaryColor: '#00471B',
        secondaryColor: '#EEE1C6',
        wins: 0,
        losses: 0
      },
      {
        name: 'Thunderbolts',
        division: '6th Grade Boys',
        coachName: 'Coach Davis',
        primaryColor: '#002B5C',
        secondaryColor: '#00A8E6',
        wins: 0,
        losses: 0
      },
      {
        name: 'Rising Stars',
        division: '6th Grade Boys',
        coachName: 'Coach Brown',
        primaryColor: '#CE1141',
        secondaryColor: '#000000',
        wins: 0,
        losses: 0
      },
      {
        name: 'Legacy Elite',
        division: '7th Grade Boys',
        coachName: 'Coach Wilson',
        primaryColor: '#FFD700',
        secondaryColor: '#000000',
        wins: 0,
        losses: 0
      }
    ],
    
    samplePlayers: [
      { name: 'Michael Jordan Jr', number: '23', position: 'SG', grade: '5th' },
      { name: 'LeBron James III', number: '6', position: 'SF', grade: '5th' },
      { name: 'Stephen Curry Jr', number: '30', position: 'PG', grade: '5th' },
      { name: 'Kevin Durant Jr', number: '35', position: 'PF', grade: '6th' },
      { name: 'Kobe Bryant Jr', number: '24', position: 'SG', grade: '6th' },
      { name: 'Tim Duncan Jr', number: '21', position: 'C', grade: '7th' }
    ]
  };

  // Seed basic data (venues, divisions, admin account)
  async seedBasicData(): Promise<string> {
    try {
      console.log('Starting basic data seeding...');
      
      // Create venues
      for (const venue of this.testData.venues) {
        await this.createVenue(venue);
      }
      console.log(`✓ Created ${this.testData.venues.length} venues`);
      
      // Create divisions
      for (const division of this.testData.divisions) {
        await this.createDivision(division);
      }
      console.log(`✓ Created ${this.testData.divisions.length} divisions`);
      
      // Create default league
      await this.createDefaultLeague();
      console.log('✓ Created default league');
      
      return 'Basic test data seeded successfully';
    } catch (error: any) {
      console.error('Failed to seed basic data:', error);
      throw new Error(`Seeding failed: ${error.message}`);
    }
  }

  // Seed full test data (includes teams, players, sample games)
  async seedFullTestData(): Promise<string> {
    try {
      console.log('Starting full test data seeding...');
      
      // First seed basic data
      await this.seedBasicData();
      
      // Create test user accounts
      await this.createTestAccounts();
      console.log('✓ Created test user accounts');
      
      // Create teams
      for (const team of this.testData.teams) {
        await this.createTeam(team);
      }
      console.log(`✓ Created ${this.testData.teams.length} teams`);
      
      // Create sample players
      await this.createSamplePlayers();
      console.log('✓ Created sample players');
      
      // Create sample schedule
      await this.createSampleSchedule();
      console.log('✓ Created sample game schedule');
      
      return 'Full test data seeded successfully';
    } catch (error: any) {
      console.error('Failed to seed full test data:', error);
      throw new Error(`Full seeding failed: ${error.message}`);
    }
  }

  // Create a venue
  private async createVenue(venue: TestVenue): Promise<void> {
    await addDoc(collection(db, 'venues'), {
      ...venue,
      available: true,
      createdAt: new Date().toISOString(),
      features: ['Scoreboard', 'Bleachers', 'Concessions'],
      isTestData: true
    });
  }

  // Create a division
  private async createDivision(division: TestDivision): Promise<void> {
    await addDoc(collection(db, 'divisions'), {
      ...division,
      active: true,
      currentTeams: 0,
      createdAt: new Date().toISOString(),
      season: 'Spring 2025',
      isTestData: true
    });
  }

  // Create default league
  private async createDefaultLeague(): Promise<void> {
    await setDoc(doc(db, 'leagues', 'default'), {
      name: 'Legacy Youth Sports - Phoenix',
      location: 'Phoenix, AZ',
      established: '2020',
      motto: 'Where Champions Begin',
      primaryColor: '#FFD700',
      secondaryColor: '#000000',
      contactEmail: leagueConfig.contactEmail,
      contactPhone: leagueConfig.contactPhone,
      websiteUrl: leagueConfig.websiteUrl,
      socialMedia: {
        facebook: leagueConfig.socialMedia.facebook || '',
        instagram: 'legacy_youth_phx',
        twitter: 'LegacyYouthPHX'
      },
      settings: {
        registrationOpen: true,
        playoffsEnabled: false,
        statsTrackingEnabled: true,
        maxPlayersPerTeam: 12,
        gameLength: 32,
        quarterLength: 8,
        overtimeLength: 4
      },
      createdAt: new Date().toISOString(),
      isTestData: true
    });
  }

  // Create test user accounts
  private async createTestAccounts(): Promise<void> {
    // Note: In a real implementation, you would create actual Firebase Auth users
    // For testing, we'll just create user documents
    
    // Admin account
    await setDoc(doc(db, 'users', 'test-admin'), {
      ...this.testData.admin,
      uid: 'test-admin',
      createdAt: new Date().toISOString(),
      isTestAccount: true
    });
    
    // Coach accounts
    for (let i = 0; i < this.testData.coaches.length; i++) {
      const coach = this.testData.coaches[i];
      await setDoc(doc(db, 'users', `test-coach-${i + 1}`), {
        ...coach,
        uid: `test-coach-${i + 1}`,
        createdAt: new Date().toISOString(),
        isTestAccount: true
      });
    }
    
    // Scorekeeper account
    await setDoc(doc(db, 'users', 'test-scorekeeper'), {
      ...this.testData.scorekeeper,
      uid: 'test-scorekeeper',
      createdAt: new Date().toISOString(),
      isTestAccount: true
    });
    
    // Site Director account
    await setDoc(doc(db, 'users', 'test-director'), {
      ...this.testData.siteDirector,
      uid: 'test-director',
      createdAt: new Date().toISOString(),
      isTestAccount: true
    });
  }

  // Create a team
  private async createTeam(team: any): Promise<void> {
    await addDoc(collection(db, 'teams'), {
      ...team,
      roster: [],
      gamesPlayed: 0,
      pointsFor: 0,
      pointsAgainst: 0,
      winPercentage: 0,
      streak: 'N/A',
      lastGameResult: null,
      createdAt: new Date().toISOString(),
      isTestData: true
    });
  }

  // Create sample players
  private async createSamplePlayers(): Promise<void> {
    for (const player of this.testData.samplePlayers) {
      await addDoc(collection(db, 'players'), {
        ...player,
        team: 'Unassigned',
        stats: {
          gamesPlayed: 0,
          points: 0,
          rebounds: 0,
          assists: 0,
          steals: 0,
          blocks: 0,
          fouls: 0
        },
        createdAt: new Date().toISOString(),
        isTestData: true
      });
    }
  }

  // Create sample game schedule
  private async createSampleSchedule(): Promise<void> {
    const sampleGames = [
      {
        homeTeam: 'Phoenix Suns Jr',
        awayTeam: 'Desert Storm',
        date: this.getNextSaturday(),
        time: '10:00 AM',
        venue: 'Legacy Main Gymnasium',
        court: 'Court 1',
        division: '5th Grade Boys',
        status: 'scheduled'
      },
      {
        homeTeam: 'Valley Vipers',
        awayTeam: 'Phoenix Suns Jr',
        date: this.getNextSaturday(),
        time: '11:00 AM',
        venue: 'Legacy Main Gymnasium',
        court: 'Court 2',
        division: '5th Grade Boys',
        status: 'scheduled'
      },
      {
        homeTeam: 'Thunderbolts',
        awayTeam: 'Rising Stars',
        date: this.getNextSaturday(),
        time: '12:00 PM',
        venue: 'Phoenix Recreation Center',
        court: 'Court 1',
        division: '6th Grade Boys',
        status: 'scheduled'
      }
    ];
    
    for (const game of sampleGames) {
      await addDoc(collection(db, 'games'), {
        ...game,
        homeScore: 0,
        awayScore: 0,
        quarter: 1,
        timeRemaining: '8:00',
        officials: ['TBD'],
        createdAt: new Date().toISOString(),
        isTestData: true
      });
    }
  }

  // Helper function to get next Saturday
  private getNextSaturday(): string {
    const today = new Date();
    const daysUntilSaturday = (6 - today.getDay() + 7) % 7 || 7;
    const nextSaturday = new Date(today);
    nextSaturday.setDate(today.getDate() + daysUntilSaturday);
    return nextSaturday.toISOString().split('T')[0];
  }

  // Get test credentials for documentation
  getTestCredentials(): any {
    return {
      admin: {
        email: this.testData.admin.email,
        password: this.testData.admin.password,
        role: 'Admin'
      },
      coach: {
        email: this.testData.coaches[0].email,
        password: this.testData.coaches[0].password,
        role: 'Coach'
      },
      scorekeeper: {
        email: this.testData.scorekeeper.email,
        password: this.testData.scorekeeper.password,
        role: 'Scorekeeper'
      },
      siteDirector: {
        email: this.testData.siteDirector.email,
        password: this.testData.siteDirector.password,
        role: 'Site Director'
      }
    };
  }
}

export default new TestDataSeeder();