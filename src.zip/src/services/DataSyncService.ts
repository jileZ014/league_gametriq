import { db } from '../firebase';
import { 
  collection, 
  doc, 
  onSnapshot, 
  query, 
  where, 
  getDocs,
  updateDoc,
  setDoc,
  writeBatch 
} from 'firebase/firestore';

/**
 * DataSyncService handles asymmetric data synchronization between roles
 * Ensures data created by one role is properly visible and editable by related roles
 */
class DataSyncService {
  private listeners: Map<string, () => void> = new Map();

  /**
   * Initialize real-time sync listeners for cross-role data sharing
   */
  initializeSync(userRole: string, userId: string) {
    // Clear any existing listeners
    this.cleanup();

    switch (userRole) {
      case 'admin':
        this.syncAdminData();
        break;
      case 'coach':
        this.syncCoachData(userId);
        break;
      case 'scorekeeper':
        this.syncScorekeeperData(userId);
        break;
      case 'site-director':
      case 'sitedirector':
        this.syncSiteDirectorData(userId);
        break;
    }
  }

  /**
   * Admin sees everything and changes propagate to all roles
   */
  private syncAdminData() {
    // When admin creates/updates venues, auto-assign to site directors
    const venuesListener = onSnapshot(collection(db, 'venues'), async (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        if (change.type === 'added' || change.type === 'modified') {
          const venueData = change.doc.data();
          
          // Find site directors and assign venue if in same location
          if (venueData.location) {
            const directorsQuery = query(
              collection(db, 'users'),
              where('role', '==', 'site-director')
            );
            const directors = await getDocs(directorsQuery);
            
            directors.forEach(async (directorDoc) => {
              const directorData = directorDoc.data();
              // Auto-assign venue to site director if no venue assigned
              if (!directorData.assignedVenueId) {
                await updateDoc(doc(db, 'users', directorDoc.id), {
                  assignedVenueId: change.doc.id,
                  assignedVenueName: venueData.name
                });
              }
            });
          }
        }
      });
    });
    
    this.listeners.set('venues', venuesListener);

    // When admin creates games, ensure proper visibility
    const gamesListener = onSnapshot(collection(db, 'games'), async (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        if (change.type === 'added') {
          const gameData = change.doc.data();
          
          // Ensure game has necessary fields for other roles
          const updates: any = {};
          
          if (!gameData.scorekeeperId) {
            updates.scorekeeperId = null; // Available for any scorekeeper
          }
          
          if (!gameData.venueId && gameData.location) {
            // Try to match with existing venue
            const venuesQuery = query(
              collection(db, 'venues'),
              where('name', '==', gameData.location)
            );
            const venues = await getDocs(venuesQuery);
            if (!venues.empty) {
              updates.venueId = venues.docs[0].id;
            }
          }
          
          if (Object.keys(updates).length > 0) {
            await updateDoc(doc(db, 'games', change.doc.id), updates);
          }
        }
      });
    });
    
    this.listeners.set('games', gamesListener);
  }

  /**
   * Coach data syncs with admin and relevant games/players
   */
  private syncCoachData(coachId: string) {
    // When coach creates a team, ensure admin can see it
    const teamsListener = onSnapshot(
      query(collection(db, 'teams'), where('coachId', '==', coachId)),
      async (snapshot) => {
        snapshot.docChanges().forEach(async (change) => {
          if (change.type === 'added') {
            const teamData = change.doc.data();
            
            // Ensure team has all necessary fields
            const updates: any = {};
            
            if (!teamData.status) {
              updates.status = 'pending'; // Admin needs to approve
            }
            
            if (!teamData.division) {
              updates.division = 'unassigned';
            }
            
            if (!teamData.createdBy) {
              updates.createdBy = coachId;
              updates.createdAt = new Date().toISOString();
            }
            
            if (Object.keys(updates).length > 0) {
              await updateDoc(doc(db, 'teams', change.doc.id), updates);
            }
          }
        });
      }
    );
    
    this.listeners.set('teams', teamsListener);

    // When coach adds players, ensure they're visible in games
    const playersListener = onSnapshot(
      query(collection(db, 'players'), where('coachId', '==', coachId)),
      async (snapshot) => {
        snapshot.docChanges().forEach(async (change) => {
          if (change.type === 'added') {
            const playerData = change.doc.data();
            
            // Ensure player has team assignment
            if (!playerData.teamId && playerData.teamName) {
              const teamsQuery = query(
                collection(db, 'teams'),
                where('name', '==', playerData.teamName),
                where('coachId', '==', coachId)
              );
              const teams = await getDocs(teamsQuery);
              
              if (!teams.empty) {
                await updateDoc(doc(db, 'players', change.doc.id), {
                  teamId: teams.docs[0].id
                });
              }
            }
          }
        });
      }
    );
    
    this.listeners.set('players', playersListener);
  }

  /**
   * Scorekeeper sees games they're assigned to or available games
   */
  private syncScorekeeperData(scorekeeperId: string) {
    // Listen for games that need scorekeepers
    const gamesListener = onSnapshot(collection(db, 'games'), async (snapshot) => {
      snapshot.docChanges().forEach(async (change) => {
        if (change.type === 'modified') {
          const gameData = change.doc.data();
          
          // If game score is updated by scorekeeper, update standings
          if (gameData.status === 'completed' && gameData.homeScore !== undefined && gameData.awayScore !== undefined) {
            await this.updateStandingsFromGame(change.doc.id, gameData);
          }
        }
      });
    });
    
    this.listeners.set('games', gamesListener);
  }

  /**
   * Site Director manages venues and sees games at their venue
   */
  private syncSiteDirectorData(directorId: string) {
    // Get director's assigned venue
    const userListener = onSnapshot(doc(db, 'users', directorId), async (userDoc) => {
      if (userDoc.exists()) {
        const userData = userDoc.data();
        
        if (userData.assignedVenueId) {
          // Listen to games at this venue
          const gamesListener = onSnapshot(
            query(collection(db, 'games'), where('venueId', '==', userData.assignedVenueId)),
            async (snapshot) => {
              // Site director can see all games at their venue
              console.log(`Site director has ${snapshot.size} games at their venue`);
            }
          );
          
          this.listeners.set('venue-games', gamesListener);
        }
      }
    });
    
    this.listeners.set('user', userListener);
  }

  /**
   * Update standings when a game is completed
   */
  private async updateStandingsFromGame(gameId: string, gameData: any) {
    if (!gameData.homeTeamId || !gameData.awayTeamId) return;

    const batch = writeBatch(db);

    // Update home team standings
    const homeStandingRef = doc(db, 'standings', gameData.homeTeamId);
    const awayStandingRef = doc(db, 'standings', gameData.awayTeamId);

    // Determine winner
    const homeWon = gameData.homeScore > gameData.awayScore;
    const awayWon = gameData.awayScore > gameData.homeScore;
    const tie = gameData.homeScore === gameData.awayScore;

    // Get current standings
    const [homeStanding, awayStanding] = await Promise.all([
      getDocs(query(collection(db, 'standings'), where('teamId', '==', gameData.homeTeamId))),
      getDocs(query(collection(db, 'standings'), where('teamId', '==', gameData.awayTeamId)))
    ]);

    // Update home team
    if (!homeStanding.empty) {
      const currentHome = homeStanding.docs[0].data();
      batch.update(homeStanding.docs[0].ref, {
        wins: currentHome.wins + (homeWon ? 1 : 0),
        losses: currentHome.losses + (awayWon ? 1 : 0),
        ties: currentHome.ties + (tie ? 1 : 0),
        pointsFor: currentHome.pointsFor + gameData.homeScore,
        pointsAgainst: currentHome.pointsAgainst + gameData.awayScore,
        lastUpdated: new Date().toISOString()
      });
    }

    // Update away team
    if (!awayStanding.empty) {
      const currentAway = awayStanding.docs[0].data();
      batch.update(awayStanding.docs[0].ref, {
        wins: currentAway.wins + (awayWon ? 1 : 0),
        losses: currentAway.losses + (homeWon ? 1 : 0),
        ties: currentAway.ties + (tie ? 1 : 0),
        pointsFor: currentAway.pointsFor + gameData.awayScore,
        pointsAgainst: currentAway.pointsAgainst + gameData.homeScore,
        lastUpdated: new Date().toISOString()
      });
    }

    await batch.commit();
  }

  /**
   * Clean up all listeners
   */
  cleanup() {
    this.listeners.forEach((unsubscribe) => unsubscribe());
    this.listeners.clear();
  }
}

export default new DataSyncService();