import React, { lazy, Suspense } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './AuthContext';
import OfflineAlert from './components/OfflineAlert';

// Lazy load components for better performance
const Landing = lazy(() => import('./pages/Landing').then(m => ({ default: m.Landing })));
const Login = lazy(() => import('./Login').then(m => ({ default: m.Login })));
const Dashboard = lazy(() => import('./Dashboard'));
const TeamRegistration = lazy(() => import('./pages/public/TeamRegistration'));
const RoleSelection = lazy(() => import('./RoleSelection'));
const TeamRoster = lazy(() => import('./pages/TeamRoster'));
const Schedule = lazy(() => import('./pages/Schedule'));
const Stats = lazy(() => import('./pages/Stats'));
const Messages = lazy(() => import('./pages/Messages'));
const PublicSchedule = lazy(() => import('./pages/PublicSchedule'));
const LiveScoring = lazy(() => import('./pages/LiveScoring'));
const Scoring = lazy(() => import('./pages/Scoring'));
const ManageUsers = lazy(() => import('./pages/ManageUsers'));
const Standings = lazy(() => import('./pages/Standings'));
const TestPage = lazy(() => import('./pages/TestPage'));
const BrowserTest = lazy(() => import('./testing/BrowserTest'));
const UIVerification = lazy(() => import('./pages/UIVerification'));
const ContractTestSuite = lazy(() => import('./testing/ContractTestSuite'));
const InitDatabase = lazy(() => import('./pages/InitDatabase'));
const InitializeTestAccounts = lazy(() => import('./pages/InitializeTestAccounts'));

// Public Pages (NO AUTH REQUIRED - CONTRACT)
const PublicHomepage = lazy(() => import('./pages/public/HomepageNew'));
const PublicSchedulePage = lazy(() => import('./pages/public/PublicSchedule'));
const PublicStandingsPage = lazy(() => import('./pages/public/PublicStandings'));
const PublicLeaderboardPage = lazy(() => import('./pages/public/PublicLeaderboard'));

// Admin Components
const LeagueManagement = lazy(() => import('./pages/admin/LeagueManagement'));
const TeamManagementAdmin = lazy(() => import('./pages/admin/TeamManagement'));
const ScheduleGenerator = lazy(() => import('./pages/admin/ScheduleGenerator'));
const FinancialCompliance = lazy(() => import('./pages/admin/FinancialCompliance'));
const TeamApproval = lazy(() => import('./pages/admin/TeamApproval'));
const ScheduleGeneratorFixed = lazy(() => import('./pages/admin/ScheduleGeneratorFixed'));
const PlayoffsBracket = lazy(() => import('./pages/admin/PlayoffsBracket'));
const SystemConfig = lazy(() => import('./pages/admin/SystemConfig'));

// Coach Components
const PerformanceAnalytics = lazy(() => import('./pages/coach/PerformanceAnalytics'));

// Scorekeeper Components
const LiveScoringNew = lazy(() => import('./pages/scorekeeper/LiveScoring'));
const StatTracker = lazy(() => import('./pages/scorekeeper/StatTracker'));

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, loading, needsRoleSelection } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-basketball-orange-50 to-basketball-green-50">
        <div className="text-center">
          <div className="inline-block animate-basketball-spin">
            <svg className="w-16 h-16 text-basketball-orange-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.94-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/>
            </svg>
          </div>
          <p className="mt-4 text-lg font-semibold text-gray-700">Loading GameTriq...</p>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <Navigate to="/login" />;
  }

  // Check if user needs to select a role
  if (needsRoleSelection && window.location.pathname !== '/role-selection') {
    return <Navigate to="/role-selection" />;
  }

  return <>{children}</>;
};

const LoadingSpinner = () => (
  <div className="min-h-screen flex items-center justify-center bg-gray-50">
    <div className="text-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500 mx-auto"></div>
      <p className="mt-4 text-gray-600">Loading...</p>
    </div>
  </div>
);

const AppRoutes: React.FC = () => {
  const { currentUser, needsRoleSelection } = useAuth();

  return (
    <Suspense fallback={<LoadingSpinner />}>
      <Routes>
        {/* PUBLIC ROUTES - NO AUTH REQUIRED (CONTRACT) */}
        <Route path="/" element={<PublicHomepage />} />
        <Route path="/public" element={<PublicHomepage />} />
        <Route path="/public/schedule" element={<PublicSchedulePage />} />
        <Route path="/public/standings" element={<PublicStandingsPage />} />
        <Route path="/public/leaderboard" element={<PublicLeaderboardPage />} />
        
        {/* Registration Routes (PUBLIC - NO AUTH) */}
        <Route path="/register" element={<TeamRegistration />} />
        <Route path="/register/organization" element={<TeamRegistration />} />
        <Route path="/register/team" element={<TeamRegistration />} />
        <Route path="/register/individual" element={<TeamRegistration />} />
        
        {/* Landing page (legacy) */}
        <Route path="/landing" element={<Landing />} />
        <Route path="/login" element={currentUser ? <Navigate to="/dashboard" /> : <Login />} />
        <Route path="/test" element={<TestPage />} />
        <Route path="/e2e-test" element={<BrowserTest />} />
        <Route path="/ui-verify" element={<UIVerification />} />
        <Route path="/contract-test" element={<ContractTestSuite />} />
        <Route path="/init-db" element={<InitDatabase />} />
        <Route path="/init-test-accounts" element={<InitializeTestAccounts />} />
        <Route path="/role-selection" element={
          currentUser && needsRoleSelection ? <RoleSelection /> : <Navigate to="/dashboard" />
        } />
        <Route path="/dashboard" element={
          <ProtectedRoute>
            <Dashboard />
          </ProtectedRoute>
        } />
        <Route path="/team-roster" element={
          <ProtectedRoute>
            <TeamRoster />
          </ProtectedRoute>
        } />
        <Route path="/schedule" element={
          <ProtectedRoute>
            <Schedule />
          </ProtectedRoute>
        } />
        <Route path="/stats" element={
          <ProtectedRoute>
            <Stats />
          </ProtectedRoute>
        } />
        <Route path="/messages" element={
          <ProtectedRoute>
            <Messages />
          </ProtectedRoute>
        } />
        <Route path="/scoring" element={
          <ProtectedRoute>
            <LiveScoring />
          </ProtectedRoute>
        } />
        <Route path="/scoring/:gameId" element={
          <ProtectedRoute>
            <Scoring />
          </ProtectedRoute>
        } />
        <Route path="/notifications" element={
          <ProtectedRoute>
            <div className="p-8">Notifications - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/updates" element={
          <ProtectedRoute>
            <div className="p-8">Team Updates - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/results" element={
          <ProtectedRoute>
            <div className="p-8">Game Results - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/assignments" element={
          <ProtectedRoute>
            <div className="p-8">Game Assignments - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/reports" element={
          <ProtectedRoute>
            <div className="p-8">Reports - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/rules" element={
          <ProtectedRoute>
            <div className="p-8">Rules Reference - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/history" element={
          <ProtectedRoute>
            <div className="p-8">Game History - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/stats-entry" element={
          <ProtectedRoute>
            <div className="p-8">Statistics Entry - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/users" element={
          <ProtectedRoute>
            <ManageUsers />
          </ProtectedRoute>
        } />
        <Route path="/standings" element={
          <ProtectedRoute>
            <Standings />
          </ProtectedRoute>
        } />
        
        {/* Admin Routes */}
        <Route path="/admin/leagues" element={
          <ProtectedRoute>
            <LeagueManagement />
          </ProtectedRoute>
        } />
        <Route path="/admin/teams" element={
          <ProtectedRoute>
            <TeamManagementAdmin />
          </ProtectedRoute>
        } />
        <Route path="/admin/teams/approval" element={
          <ProtectedRoute>
            <TeamApproval />
          </ProtectedRoute>
        } />
        <Route path="/admin/schedule" element={
          <ProtectedRoute>
            <ScheduleGenerator />
          </ProtectedRoute>
        } />
        <Route path="/admin/schedule-generator" element={
          <ProtectedRoute>
            <ScheduleGeneratorFixed />
          </ProtectedRoute>
        } />
        <Route path="/admin/financial" element={
          <ProtectedRoute>
            <FinancialCompliance />
          </ProtectedRoute>
        } />
        <Route path="/admin/playoffs" element={
          <ProtectedRoute>
            <PlayoffsBracket />
          </ProtectedRoute>
        } />
        <Route path="/admin/system-config" element={
          <ProtectedRoute>
            <SystemConfig />
          </ProtectedRoute>
        } />
        
        {/* Coach Routes */}
        <Route path="/coach/analytics" element={
          <ProtectedRoute>
            <PerformanceAnalytics />
          </ProtectedRoute>
        } />
        
        {/* Scorekeeper Routes */}
        <Route path="/scorekeeper/live" element={
          <ProtectedRoute>
            <LiveScoringNew />
          </ProtectedRoute>
        } />
        <Route path="/scorekeeper/stat-tracker" element={
          <ProtectedRoute>
            <StatTracker />
          </ProtectedRoute>
        } />
        <Route path="/scorekeeper/stat-tracker/:gameId" element={
          <ProtectedRoute>
            <StatTracker />
          </ProtectedRoute>
        } />
        <Route path="/settings" element={
          <ProtectedRoute>
            <div className="p-8">Settings - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/analytics" element={
          <ProtectedRoute>
            <div className="p-8">Analytics - Coming Soon</div>
          </ProtectedRoute>
        } />
        <Route path="/register" element={<Navigate to="/login" />} />
        <Route path="/privacy" element={<div className="p-8">Privacy Policy</div>} />
        <Route path="/terms" element={<div className="p-8">Terms of Service</div>} />
        <Route path="/support" element={<div className="p-8">Support</div>} />
        <Route path="/tournaments" element={<div className="p-8">Tournaments</div>} />
      </Routes>
    </Suspense>
  );
};

function App() {
  return (
    <Router>
      <AuthProvider>
        <OfflineAlert />
        <AppRoutes />
      </AuthProvider>
    </Router>
  );
}

export default App;