/**
 * AUTOMATED QA/QC VALIDATION SCRIPT
 * Senior QA Engineer Agent v1.0
 * 
 * This script acts as an autonomous QA engineer to validate all fixes
 * and provide sign-off before deployment.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import util from 'util';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const execPromise = util.promisify(exec);

class QAValidationAgent {
  constructor() {
    this.testResults = {
      timestamp: new Date().toISOString(),
      environment: 'local',
      url: 'http://localhost:5173',
      tests: [],
      passed: 0,
      failed: 0,
      warnings: 0,
      recommendation: null
    };
  }

  // Log test result
  logTest(testName, passed, details = '') {
    const result = {
      test: testName,
      passed,
      details,
      timestamp: new Date().toISOString()
    };
    
    this.testResults.tests.push(result);
    if (passed) {
      this.testResults.passed++;
      console.log(`✅ ${testName}`);
    } else {
      this.testResults.failed++;
      console.log(`❌ ${testName}: ${details}`);
    }
  }

  // Test 1: Code Quality Checks
  async testCodeQuality() {
    console.log('\n🔍 Test Suite 1: Code Quality Validation');
    
    // Check if Supabase file is deleted
    const supabasePath = path.join(__dirname, 'lib', 'supabase.ts');
    const supabaseExists = fs.existsSync(supabasePath);
    this.logTest('Supabase File Removed', !supabaseExists, 
      supabaseExists ? 'supabase.ts still exists' : 'Successfully removed');

    // Check for Supabase imports in key files
    const filesToCheck = [
      'AuthContext.tsx',
      'components/RoleSelection.tsx',
      'App.tsx'
    ];

    for (const file of filesToCheck) {
      const filePath = path.join(__dirname, file);
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf8');
        const hasSupabaseImport = content.includes('supabase');
        this.logTest(
          `No Supabase in ${file}`,
          !hasSupabaseImport,
          hasSupabaseImport ? 'Supabase import found' : 'Clean'
        );
      }
    }

    // Check for Phoenix/AZ references
    const uiFiles = ['Login.tsx', 'pages/Schedule.tsx', 'pages/Landing.tsx'];
    for (const file of uiFiles) {
      const filePath = path.join(__dirname, file);
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf8');
        const hasPhoenix = content.toLowerCase().includes('phoenix');
        const hasAZ = content.includes('AZ') || content.includes('Arizona');
        this.logTest(
          `No Phoenix/AZ in ${file}`,
          !hasPhoenix && !hasAZ,
          hasPhoenix || hasAZ ? 'Location references found' : 'Clean'
        );
      }
    }
  }

  // Test 2: Firebase Integration
  async testFirebaseIntegration() {
    console.log('\n🔍 Test Suite 2: Firebase Integration');
    
    // Check AuthContext uses Firebase
    const authPath = path.join(__dirname, 'AuthContext.tsx');
    if (fs.existsSync(authPath)) {
      const content = fs.readFileSync(authPath, 'utf8');
      
      // Check for Firebase imports
      const hasFirebaseAuth = content.includes('firebase/auth');
      const hasFirestore = content.includes('firebase/firestore');
      const hasFirebaseImports = content.includes("from './firebase'");
      
      this.logTest('AuthContext uses Firebase Auth', hasFirebaseAuth);
      this.logTest('AuthContext uses Firestore', hasFirestore);
      this.logTest('AuthContext imports from firebase.ts', hasFirebaseImports);
      
      // Check for proper role management
      const hasRoleCheck = content.includes('userData.role');
      const hasRoleSelection = content.includes('/role-selection');
      
      this.logTest('Role management implemented', hasRoleCheck);
      this.logTest('Role selection redirect exists', hasRoleSelection);
    }
    
    // Check RoleSelection uses Firestore
    const rolePath = path.join(__dirname, 'components/RoleSelection.tsx');
    if (fs.existsSync(rolePath)) {
      const content = fs.readFileSync(rolePath, 'utf8');
      
      const hasFirestore = content.includes('firebase/firestore');
      const hasUpdateDoc = content.includes('updateDoc');
      
      this.logTest('RoleSelection uses Firestore', hasFirestore);
      this.logTest('RoleSelection updates user doc', hasUpdateDoc);
    }
  }

  // Test 3: Dashboard Safety
  async testDashboardSafety() {
    console.log('\n🔍 Test Suite 3: Dashboard Safety Checks');
    
    const dashboardPath = path.join(__dirname, 'Dashboard.tsx');
    if (fs.existsSync(dashboardPath)) {
      const content = fs.readFileSync(dashboardPath, 'utf8');
      
      // Check for null safety on role
      const hasNullSafety = content.includes('currentUser?.role');
      const hasDefaultRole = content.includes("|| 'PARENT'") || content.includes("|| 'parent'");
      const hasSafeUpperCase = content.includes('?.toUpperCase()');
      
      this.logTest('Dashboard has null safety for role', hasNullSafety);
      this.logTest('Dashboard has default role fallback', hasDefaultRole);
      this.logTest('Dashboard has safe toUpperCase', hasSafeUpperCase);
      
      // Check for no hardcoded role
      const lines = content.split('\n');
      let hasHardcodedRole = false;
      lines.forEach((line, index) => {
        if (line.includes("role: 'parent'") && !line.includes('||')) {
          hasHardcodedRole = true;
        }
      });
      
      this.logTest('No hardcoded role in Dashboard', !hasHardcodedRole);
    }
  }

  // Test 4: App Routing
  async testAppRouting() {
    console.log('\n🔍 Test Suite 4: App Routing Validation');
    
    const appPath = path.join(__dirname, 'App.tsx');
    if (fs.existsSync(appPath)) {
      const content = fs.readFileSync(appPath, 'utf8');
      
      // Check homepage route
      const hasLandingRoute = content.includes('<Landing />');
      const hasPublicScheduleRoute = content.includes('path="/" element={<PublicSchedule');
      
      this.logTest('Homepage uses Landing component', hasLandingRoute && !hasPublicScheduleRoute);
      
      // Check ProtectedRoute implementation
      const hasRoleCheck = content.includes('!currentUser.role');
      const hasRoleRedirect = content.includes('"/role-selection"');
      
      this.logTest('ProtectedRoute checks for role', hasRoleCheck);
      this.logTest('ProtectedRoute redirects to role selection', hasRoleRedirect);
    }
  }

  // Test 5: Build Process
  async testBuildProcess() {
    console.log('\n🔍 Test Suite 5: Build Process Validation');
    
    try {
      console.log('Running build... (this may take a minute)');
      const { stdout, stderr } = await execPromise('npm run build');
      
      // Check if build succeeded
      const buildSuccess = !stderr.includes('ERROR') && fs.existsSync(path.join(path.dirname(__dirname), 'dist/index.html'));
      this.logTest('Build Successful', buildSuccess,
        buildSuccess ? '' : 'Build failed or dist not created');
      
      // Check build output
      if (buildSuccess) {
        const distPath = path.join(path.dirname(__dirname), 'dist');
        const files = fs.readdirSync(path.join(distPath, 'assets'));
        const hasJS = files.some(f => f.endsWith('.js'));
        const hasCSS = files.some(f => f.endsWith('.css'));
        
        this.logTest('Build has JS files', hasJS);
        this.logTest('Build has CSS files', hasCSS);
        
        // Check for Landing in build
        const landingFile = files.find(f => f.startsWith('Landing-'));
        if (landingFile) {
          const landingContent = fs.readFileSync(path.join(distPath, 'assets', landingFile), 'utf8');
          const hasHeatRef = landingContent.includes('Phoenix Heat') || landingContent.includes('heat safety');
          this.logTest('Built Landing has no heat references', !hasHeatRef);
        }
      }
    } catch (error) {
      this.logTest('Build Process', false, error.message);
    }
  }

  // Test 6: Environment Variables
  async testEnvironmentVariables() {
    console.log('\n🔍 Test Suite 6: Environment Variables');
    
    const envPath = path.join(path.dirname(__dirname), '.env.local');
    
    if (fs.existsSync(envPath)) {
      const content = fs.readFileSync(envPath, 'utf8');
      const requiredVars = [
        'VITE_FIREBASE_API_KEY',
        'VITE_FIREBASE_AUTH_DOMAIN',
        'VITE_FIREBASE_PROJECT_ID',
        'VITE_FIREBASE_STORAGE_BUCKET',
        'VITE_FIREBASE_MESSAGING_SENDER_ID',
        'VITE_FIREBASE_APP_ID'
      ];
      
      requiredVars.forEach(varName => {
        const hasVar = content.includes(varName);
        this.logTest(`Environment variable: ${varName}`, hasVar);
      });
      
      // Check NO Supabase vars
      const hasSupabaseVars = content.includes('SUPABASE');
      this.logTest('No Supabase environment variables', !hasSupabaseVars);
    } else {
      this.logTest('Environment file exists', false, '.env.local not found');
    }
  }

  // Generate QA Report
  async generateReport() {
    console.log('\n📊 Generating QA Report...\n');
    
    const passRate = this.testResults.tests.length > 0 
      ? (this.testResults.passed / this.testResults.tests.length * 100).toFixed(1)
      : 0;
    
    // Determine recommendation
    if (this.testResults.failed === 0) {
      this.testResults.recommendation = '✅ APPROVED FOR DEPLOYMENT';
    } else if (this.testResults.failed <= 2 && passRate >= 80) {
      this.testResults.recommendation = '⚠️ CONDITIONAL APPROVAL - Minor fixes needed';
    } else {
      this.testResults.recommendation = '❌ NOT READY - Critical issues found';
    }
    
    // Console report
    console.log('╔════════════════════════════════════════════════════════════╗');
    console.log('║                   QA VALIDATION REPORT                      ║');
    console.log('╠════════════════════════════════════════════════════════════╣');
    console.log(`║ Timestamp: ${new Date().toLocaleString().padEnd(47)}║`);
    console.log(`║ Total Tests: ${this.testResults.tests.length.toString().padEnd(46)}║`);
    console.log(`║ Passed: ${this.testResults.passed.toString().padEnd(51)}║`);
    console.log(`║ Failed: ${this.testResults.failed.toString().padEnd(51)}║`);
    console.log(`║ Pass Rate: ${(passRate + '%').padEnd(48)}║`);
    console.log('╠════════════════════════════════════════════════════════════╣');
    console.log(`║ ${this.testResults.recommendation.padEnd(58)} ║`);
    console.log('╚════════════════════════════════════════════════════════════╝');
    
    // Failed tests details
    if (this.testResults.failed > 0) {
      console.log('\n❌ Failed Tests:');
      this.testResults.tests
        .filter(t => !t.passed)
        .forEach(t => console.log(`  - ${t.test}: ${t.details}`));
    }
    
    // Save JSON report
    fs.writeFileSync(
      path.join(path.dirname(__dirname), 'qa-report.json'),
      JSON.stringify(this.testResults, null, 2)
    );
    
    // Save HTML report
    const htmlReport = this.generateHTMLReport();
    fs.writeFileSync(path.join(path.dirname(__dirname), 'qa-report.html'), htmlReport);
    
    console.log('\n📁 Reports saved: qa-report.json, qa-report.html\n');
    
    return this.testResults.recommendation.includes('APPROVED');
  }

  // Generate HTML Report
  generateHTMLReport() {
    const passRate = this.testResults.tests.length > 0
      ? (this.testResults.passed / this.testResults.tests.length * 100).toFixed(1)
      : 0;
    
    return `
<!DOCTYPE html>
<html>
<head>
  <title>QA Validation Report - GameTriq League</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
              color: white; padding: 30px; border-radius: 10px; }
    .stats { display: flex; gap: 20px; margin: 20px 0; }
    .stat-card { background: white; padding: 20px; border-radius: 10px; 
                 flex: 1; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .stat-number { font-size: 36px; font-weight: bold; }
    .passed { color: #10b981; }
    .failed { color: #ef4444; }
    .warning { color: #f59e0b; }
    .test-list { background: white; padding: 20px; border-radius: 10px; 
                 margin-top: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .test-item { padding: 10px; border-bottom: 1px solid #eee; 
                 display: flex; justify-content: space-between; }
    .test-pass { color: #10b981; }
    .test-fail { color: #ef4444; }
    .recommendation { background: white; padding: 30px; border-radius: 10px; 
                      margin-top: 20px; text-align: center; font-size: 24px; 
                      font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .approved { background: #10b981; color: white; }
    .conditional { background: #f59e0b; color: white; }
    .rejected { background: #ef4444; color: white; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🤖 QA Validation Report</h1>
    <p>GameTriq League Management System</p>
    <p>Generated: ${new Date().toLocaleString()}</p>
  </div>
  
  <div class="stats">
    <div class="stat-card">
      <div class="stat-number">${this.testResults.tests.length}</div>
      <div>Total Tests</div>
    </div>
    <div class="stat-card">
      <div class="stat-number passed">${this.testResults.passed}</div>
      <div>Passed</div>
    </div>
    <div class="stat-card">
      <div class="stat-number failed">${this.testResults.failed}</div>
      <div>Failed</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${passRate}%</div>
      <div>Pass Rate</div>
    </div>
  </div>
  
  <div class="recommendation ${
    this.testResults.recommendation.includes('APPROVED') ? 'approved' :
    this.testResults.recommendation.includes('CONDITIONAL') ? 'conditional' : 'rejected'
  }">
    ${this.testResults.recommendation}
  </div>
  
  <div class="test-list">
    <h2>Test Results</h2>
    ${this.testResults.tests.map(test => `
      <div class="test-item">
        <span>${test.test}</span>
        <span class="${test.passed ? 'test-pass' : 'test-fail'}">
          ${test.passed ? '✅ PASS' : '❌ FAIL'}
          ${!test.passed && test.details ? ` - ${test.details}` : ''}
        </span>
      </div>
    `).join('')}
  </div>
</body>
</html>
    `;
  }

  // Main execution
  async run() {
    console.log('╔════════════════════════════════════════════════════════════╗');
    console.log('║          🤖 SENIOR QA ENGINEER AGENT v1.0                  ║');
    console.log('║                  Starting Validation...                     ║');
    console.log('╚════════════════════════════════════════════════════════════╝\n');
    
    try {
      // Run all test suites
      await this.testCodeQuality();
      await this.testFirebaseIntegration();
      await this.testDashboardSafety();
      await this.testAppRouting();
      await this.testBuildProcess();
      await this.testEnvironmentVariables();
      
      // Generate report
      const approved = await this.generateReport();
      
      // Exit with appropriate code
      process.exit(approved ? 0 : 1);
      
    } catch (error) {
      console.error('❌ QA Agent Error:', error);
      process.exit(1);
    }
  }
}

// Execute QA validation
const agent = new QAValidationAgent();
agent.run();