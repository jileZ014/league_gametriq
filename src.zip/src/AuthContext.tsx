import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  User as FirebaseUser, 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged 
} from 'firebase/auth';
import { auth, googleProvider, db } from './firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import DataSyncService from './services/DataSyncService';
import type { User, UserRole } from './types';
import { getUserRole } from './utils/roleMapper';

interface AuthContextType {
  currentUser: User | null;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  loading: boolean;
  needsRoleSelection: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [needsRoleSelection, setNeedsRoleSelection] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDocRef = doc(db, 'users', firebaseUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (userDoc.exists()) {
            const userData = userDoc.data();
            
            // Use roleMapper to get/fix the role
            const userRole = await getUserRole(firebaseUser.email || '', firebaseUser.uid);
            
            setCurrentUser({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || '',
              role: userRole
            });
            setNeedsRoleSelection(false);
            
            // Initialize data sync for this role
            DataSyncService.initializeSync(userRole, firebaseUser.uid);
          } else {
            // New user - get role from mapper
            const userRole = await getUserRole(firebaseUser.email || '', firebaseUser.uid);
            
            // Create initial document with correct role
            await setDoc(userDocRef, {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              displayName: firebaseUser.displayName,
              role: userRole,
              createdAt: new Date().toISOString(),
              lastLogin: new Date().toISOString()
            });
            
            setCurrentUser({
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || '',
              role: userRole
            });
            setNeedsRoleSelection(false);
            
            // Initialize data sync for this role
            DataSyncService.initializeSync(userRole, firebaseUser.uid);
          }
        } catch (error) {
          console.error('Error loading user data:', error);
          // Fallback - use roleMapper
          const userRole = await getUserRole(firebaseUser.email || '', firebaseUser.uid);
          
          setCurrentUser({
            uid: firebaseUser.uid,
            email: firebaseUser.email || '',
            displayName: firebaseUser.displayName || '',
            role: userRole
          });
          setNeedsRoleSelection(false);
        }
      } else {
        setCurrentUser(null);
        setNeedsRoleSelection(false);
        // Clean up data sync when user logs out
        DataSyncService.cleanup();
      }
      setLoading(false);
    });

    return () => {
      unsubscribe();
      // Clean up data sync on unmount
      DataSyncService.cleanup();
    };
  }, []);

  const login = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setCurrentUser(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <AuthContext.Provider value={{ 
      currentUser, 
      login, 
      logout, 
      loading,
      needsRoleSelection 
    }}>
      {children}
    </AuthContext.Provider>
  );
};