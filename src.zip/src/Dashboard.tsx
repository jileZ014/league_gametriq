import React from 'react';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import { Button } from './components/ui/button';
import { Badge } from './components/ui/badge';
import { LogOut } from 'lucide-react';
import { DashboardErrorBoundary } from './components/ErrorBoundary';
import { leagueConfig } from './config/league.config';

// Import role-specific dashboard components
import { CoachDashboard } from './dashboards/CoachDashboard';
import { AdminDashboard } from './dashboards/AdminDashboard';
import { ScorekeeperDashboard } from './dashboards/ScorekeeperDashboard';
import { ParentDashboard } from './dashboards/ParentDashboard';
import { PlayerDashboard } from './dashboards/PlayerDashboard';
import { RefereeDashboard } from './dashboards/RefereeDashboard';
import SiteDirectorDashboard from './dashboards/SiteDirectorDashboard';

export const Dashboard: React.FC = () => {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();

  if (!currentUser) return null;

  const userRole = currentUser?.role || 'parent';

  // Render the appropriate dashboard based on user role
  const renderRoleDashboard = () => {
    const dashboardName = userRole || 'default';
    let DashboardComponent;
    
    switch (userRole) {
      case 'coach':
        DashboardComponent = CoachDashboard;
        break;
      case 'admin':
        DashboardComponent = AdminDashboard;
        break;
      case 'sitedirector':
        DashboardComponent = SiteDirectorDashboard;
        break;
      case 'scorekeeper':
        DashboardComponent = ScorekeeperDashboard;
        break;
      case 'parent':
        DashboardComponent = ParentDashboard;
        break;
      case 'player':
        DashboardComponent = PlayerDashboard;
        break;
      case 'referee':
        DashboardComponent = RefereeDashboard;
        break;
      default:
        DashboardComponent = ParentDashboard;
    }
    
    return (
      <DashboardErrorBoundary dashboardName={dashboardName}>
        <DashboardComponent />
      </DashboardErrorBoundary>
    );
  };

  return (
    <div className="min-h-screen bg-navy-950">
      {/* Header */}
      <header className="bg-gradient-navy border-b border-navy-800" role="banner" aria-label="Main header">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-4">
              <img 
                src={leagueConfig.logoUrl}
                alt={`${leagueConfig.leagueName} Logo`}
                className="h-12 w-12 rounded-full object-cover shadow-lg"
              />
              <div>
                <h1 className="text-3xl font-display font-bold text-white">
                  {leagueConfig.leagueShortName}
                </h1>
                <p className="text-gray-400 text-sm">
                  {leagueConfig.leagueTagline} • {leagueConfig.division}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="font-semibold text-white">{currentUser.displayName}</p>
                <Badge variant="secondary">
                  {currentUser?.role?.toUpperCase() || 'USER'}
                </Badge>
              </div>
              <Button
                onClick={logout}
                variant="ghost"
                className="text-white hover:bg-navy-800"
                aria-label="Logout"
              >
                <LogOut className="h-5 w-5" aria-hidden="true" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" role="main" aria-label="Dashboard content">
        {renderRoleDashboard()}
      </main>
    </div>
  );
};

export default Dashboard;