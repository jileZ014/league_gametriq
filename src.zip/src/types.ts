export type UserRole = 'coach' | 'parent' | 'player' | 'referee' | 'scorekeeper' | 'admin' | 'sitedirector';

export interface User {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole | null;
  photoURL?: string | null;
}

export interface Game {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  date: Date;
  status: 'scheduled' | 'in_progress' | 'completed';
}