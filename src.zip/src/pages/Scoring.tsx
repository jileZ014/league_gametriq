import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Plus, 
  Minus, 
  Clock, 
  Play, 
  Pause, 
  RotateCcw,
  Trophy,
  ArrowLeft,
  Users,
  Activity
} from 'lucide-react';

interface Game {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  location: string;
  status: 'scheduled' | 'in_progress' | 'completed';
  homeScore: number;
  awayScore: number;
  period: number;
  timeRemaining: string;
}

export const Scoring: React.FC = () => {
  const { gameId } = useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [game, setGame] = useState<Game | null>(null);
  const [loading, setLoading] = useState(true);
  const [isClockRunning, setIsClockRunning] = useState(false);
  const [period, setPeriod] = useState(1);
  const [timeRemaining, setTimeRemaining] = useState('10:00');

  useEffect(() => {
    if (!gameId || !currentUser) return;

    // Subscribe to real-time game updates
    const gameRef = doc(db, 'games', gameId);
    const unsubscribe = onSnapshot(gameRef, (doc) => {
      if (doc.exists()) {
        const gameData = { id: doc.id, ...doc.data() } as Game;
        setGame(gameData);
        setPeriod(gameData.period || 1);
        setTimeRemaining(gameData.timeRemaining || '10:00');
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, [gameId, currentUser]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isClockRunning && timeRemaining !== '0:00') {
      interval = setInterval(() => {
        setTimeRemaining(prev => {
          const [minutes, seconds] = prev.split(':').map(Number);
          const totalSeconds = minutes * 60 + seconds - 1;
          
          if (totalSeconds <= 0) {
            setIsClockRunning(false);
            return '0:00';
          }
          
          const newMinutes = Math.floor(totalSeconds / 60);
          const newSeconds = totalSeconds % 60;
          return `${newMinutes}:${newSeconds.toString().padStart(2, '0')}`;
        });
      }, 1000);
    }
    
    return () => clearInterval(interval);
  }, [isClockRunning, timeRemaining]);

  const updateScore = async (team: 'home' | 'away', points: number) => {
    if (!game || !gameId) return;
    
    const newScore = team === 'home' 
      ? Math.max(0, game.homeScore + points)
      : Math.max(0, game.awayScore + points);
    
    try {
      await updateDoc(doc(db, 'games', gameId), {
        [team === 'home' ? 'homeScore' : 'awayScore']: newScore,
        status: 'in_progress',
        period,
        timeRemaining
      });
    } catch (error) {
      console.error('Error updating score:', error);
    }
  };

  const startGame = async () => {
    if (!gameId) return;
    
    try {
      await updateDoc(doc(db, 'games', gameId), {
        status: 'in_progress',
        period: 1,
        timeRemaining: '10:00'
      });
      setIsClockRunning(true);
    } catch (error) {
      console.error('Error starting game:', error);
    }
  };

  const endPeriod = async () => {
    if (!gameId || !game) return;
    
    const nextPeriod = period + 1;
    const isGameOver = period >= 4;
    
    try {
      await updateDoc(doc(db, 'games', gameId), {
        period: isGameOver ? 4 : nextPeriod,
        timeRemaining: isGameOver ? '0:00' : '10:00',
        status: isGameOver ? 'completed' : 'in_progress'
      });
      
      if (!isGameOver) {
        setPeriod(nextPeriod);
        setTimeRemaining('10:00');
        setIsClockRunning(false);
      }
    } catch (error) {
      console.error('Error ending period:', error);
    }
  };

  const resetGame = async () => {
    if (!gameId || !window.confirm('Are you sure you want to reset this game?')) return;
    
    try {
      await updateDoc(doc(db, 'games', gameId), {
        homeScore: 0,
        awayScore: 0,
        period: 1,
        timeRemaining: '10:00',
        status: 'scheduled'
      });
      setIsClockRunning(false);
    } catch (error) {
      console.error('Error resetting game:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-8">
            <p className="text-red-500">Game not found</p>
            <Button onClick={() => navigate('/dashboard')} className="mt-4">
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 p-4">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-6">
        <div className="flex items-center justify-between">
          <Button
            onClick={() => navigate('/dashboard')}
            variant="ghost"
            className="text-white hover:bg-white/10"
          >
            <ArrowLeft className="h-5 w-5 mr-2" />
            Back to Dashboard
          </Button>
          <Badge 
            variant={game.status === 'in_progress' ? 'destructive' : 'secondary'}
            className="text-lg px-4 py-2"
          >
            {game.status === 'in_progress' ? 'LIVE' : game.status.toUpperCase()}
          </Badge>
        </div>
      </div>

      {/* Game Info */}
      <div className="max-w-6xl mx-auto mb-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="text-center text-white">
              <p className="text-sm text-gray-400">{game.date} at {game.time}</p>
              <p className="text-sm text-gray-400">{game.location}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Score Display */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Home Team */}
        <Card className="bg-gradient-to-br from-blue-600 to-blue-700 border-0">
          <CardHeader>
            <CardTitle className="text-white text-center">
              <Users className="h-8 w-8 mx-auto mb-2" />
              {game.homeTeam}
            </CardTitle>
            <p className="text-blue-100 text-center">HOME</p>
          </CardHeader>
          <CardContent>
            <div className="text-6xl font-bold text-white text-center mb-4">
              {game.homeScore}
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => updateScore('home', -1)}
                className="flex-1 bg-red-500 hover:bg-red-600"
                disabled={game.status === 'completed'}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => updateScore('home', 1)}
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={game.status === 'completed'}
              >
                <Plus className="h-4 w-4 mr-1" /> 1
              </Button>
              <Button
                onClick={() => updateScore('home', 2)}
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={game.status === 'completed'}
              >
                <Plus className="h-4 w-4 mr-1" /> 2
              </Button>
              <Button
                onClick={() => updateScore('home', 3)}
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={game.status === 'completed'}
              >
                <Plus className="h-4 w-4 mr-1" /> 3
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Game Clock */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white text-center">
              <Clock className="h-8 w-8 mx-auto mb-2" />
              Game Clock
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-4">
              <p className="text-gray-400 text-sm">Period</p>
              <p className="text-4xl font-bold text-white">{period}</p>
            </div>
            <div className="text-center mb-4">
              <p className="text-gray-400 text-sm">Time Remaining</p>
              <p className="text-4xl font-bold text-white">{timeRemaining}</p>
            </div>
            <div className="flex gap-2">
              {game.status === 'scheduled' ? (
                <Button
                  onClick={startGame}
                  className="flex-1 bg-green-500 hover:bg-green-600"
                >
                  <Play className="h-4 w-4 mr-2" />
                  Start Game
                </Button>
              ) : (
                <>
                  <Button
                    onClick={() => setIsClockRunning(!isClockRunning)}
                    className="flex-1"
                    variant={isClockRunning ? "destructive" : "default"}
                    disabled={game.status === 'completed'}
                  >
                    {isClockRunning ? (
                      <><Pause className="h-4 w-4 mr-2" /> Pause</>
                    ) : (
                      <><Play className="h-4 w-4 mr-2" /> Start</>
                    )}
                  </Button>
                  <Button
                    onClick={endPeriod}
                    className="flex-1"
                    disabled={game.status === 'completed'}
                  >
                    End Period
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Away Team */}
        <Card className="bg-gradient-to-br from-red-600 to-red-700 border-0">
          <CardHeader>
            <CardTitle className="text-white text-center">
              <Users className="h-8 w-8 mx-auto mb-2" />
              {game.awayTeam}
            </CardTitle>
            <p className="text-red-100 text-center">AWAY</p>
          </CardHeader>
          <CardContent>
            <div className="text-6xl font-bold text-white text-center mb-4">
              {game.awayScore}
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => updateScore('away', -1)}
                className="flex-1 bg-red-500 hover:bg-red-600"
                disabled={game.status === 'completed'}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <Button
                onClick={() => updateScore('away', 1)}
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={game.status === 'completed'}
              >
                <Plus className="h-4 w-4 mr-1" /> 1
              </Button>
              <Button
                onClick={() => updateScore('away', 2)}
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={game.status === 'completed'}
              >
                <Plus className="h-4 w-4 mr-1" /> 2
              </Button>
              <Button
                onClick={() => updateScore('away', 3)}
                className="flex-1 bg-green-500 hover:bg-green-600"
                disabled={game.status === 'completed'}
              >
                <Plus className="h-4 w-4 mr-1" /> 3
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Game Controls */}
      <div className="max-w-6xl mx-auto">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex gap-4 justify-center">
              <Button
                onClick={resetGame}
                variant="outline"
                className="text-white border-gray-600 hover:bg-gray-700"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset Game
              </Button>
              {game.status === 'completed' && (
                <Button
                  onClick={() => navigate('/dashboard')}
                  className="bg-green-500 hover:bg-green-600"
                >
                  <Trophy className="h-4 w-4 mr-2" />
                  Game Complete
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Scoring;