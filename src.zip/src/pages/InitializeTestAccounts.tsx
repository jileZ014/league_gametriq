import React, { useState } from 'react';
import TestAccountInitializer from '../services/TestAccountInitializer';
import { Shield, Users, CheckCircle, XCircle, Loader } from 'lucide-react';

const InitializeTestAccounts: React.FC = () => {
  const [isInitializing, setIsInitializing] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [verificationResults, setVerificationResults] = useState<any>(null);

  const handleInitialize = async () => {
    setIsInitializing(true);
    setResults(null);
    setVerificationResults(null);

    try {
      // Initialize accounts
      const initResult = await TestAccountInitializer.initializeTestAccounts();
      setResults(initResult);

      // Verify accounts
      const verifyResult = await TestAccountInitializer.verifyTestAccounts();
      setVerificationResults(verifyResult);
    } catch (error: any) {
      setResults({
        success: false,
        message: `Error: ${error.message}`
      });
    } finally {
      setIsInitializing(false);
    }
  };

  const testCredentials = TestAccountInitializer.getTestCredentials();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 shadow-2xl">
          <div className="flex items-center gap-4 mb-8">
            <Shield className="w-10 h-10 text-yellow-400" />
            <h1 className="text-3xl font-bold text-white">Initialize Test Accounts</h1>
          </div>

          <div className="bg-white/5 rounded-lg p-6 mb-6">
            <h2 className="text-xl font-semibold text-white mb-4">Test Accounts to Create:</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white/10 rounded-lg p-4">
                <h3 className="text-yellow-400 font-semibold mb-2">Admin</h3>
                <p className="text-gray-300 text-sm">Email: {testCredentials.admin.email}</p>
                <p className="text-gray-300 text-sm">Password: {testCredentials.admin.password}</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <h3 className="text-blue-400 font-semibold mb-2">Coach</h3>
                <p className="text-gray-300 text-sm">Email: {testCredentials.coach.email}</p>
                <p className="text-gray-300 text-sm">Password: {testCredentials.coach.password}</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <h3 className="text-green-400 font-semibold mb-2">Scorekeeper</h3>
                <p className="text-gray-300 text-sm">Email: {testCredentials.scorekeeper.email}</p>
                <p className="text-gray-300 text-sm">Password: {testCredentials.scorekeeper.password}</p>
              </div>
              <div className="bg-white/10 rounded-lg p-4">
                <h3 className="text-purple-400 font-semibold mb-2">Site Director</h3>
                <p className="text-gray-300 text-sm">Email: {testCredentials.siteDirector.email}</p>
                <p className="text-gray-300 text-sm">Password: {testCredentials.siteDirector.password}</p>
              </div>
            </div>
          </div>

          <button
            onClick={handleInitialize}
            disabled={isInitializing}
            className="w-full bg-gradient-to-r from-yellow-400 to-yellow-600 text-black font-bold py-4 px-6 rounded-lg 
                     hover:from-yellow-500 hover:to-yellow-700 transition-all duration-200 
                     disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isInitializing ? (
              <>
                <Loader className="w-5 h-5 animate-spin" />
                Creating Test Accounts...
              </>
            ) : (
              <>
                <Users className="w-5 h-5" />
                Initialize All Test Accounts
              </>
            )}
          </button>

          {results && (
            <div className={`mt-6 p-4 rounded-lg ${results.success ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              <div className="flex items-center gap-2 mb-2">
                {results.success ? (
                  <CheckCircle className="w-5 h-5 text-green-400" />
                ) : (
                  <XCircle className="w-5 h-5 text-red-400" />
                )}
                <h3 className="text-white font-semibold">Initialization Results</h3>
              </div>
              <p className="text-gray-300">{results.message}</p>
              
              {results.details && (
                <div className="mt-3 space-y-2">
                  {results.details.map((detail: any, index: number) => (
                    <div key={index} className="text-sm">
                      <span className={detail.success ? 'text-green-400' : 'text-red-400'}>
                        {detail.success ? '✓' : '✗'} {detail.email}
                      </span>
                      {detail.message && (
                        <span className="text-gray-400 ml-2">- {detail.message}</span>
                      )}
                      {detail.error && (
                        <span className="text-red-400 ml-2">- {detail.error}</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {verificationResults && (
            <div className="mt-4 p-4 rounded-lg bg-blue-500/20">
              <h3 className="text-white font-semibold mb-2">Verification Results</h3>
              <div className="space-y-2">
                {verificationResults.results.map((result: any, index: number) => (
                  <div key={index} className="text-sm flex items-center gap-2">
                    {result.success ? (
                      <CheckCircle className="w-4 h-4 text-green-400" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-400" />
                    )}
                    <span className="text-gray-300">
                      {result.email} - {result.success ? `Verified (Role: ${result.role})` : result.error}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="mt-8 p-4 bg-yellow-500/20 rounded-lg">
            <p className="text-yellow-300 text-sm">
              <strong>Note:</strong> This page creates Firebase Authentication accounts for testing purposes. 
              Once created, you can log in with any of the test credentials shown above.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InitializeTestAccounts;