import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Trophy, Users, Calendar, Activity } from 'lucide-react';
import Header from '../../components/public/Header';
import HeroSection from '../../components/public/HeroSection';
import GameShowcase from '../../components/public/GameShowcase';
import TeamStandings from '../../components/public/TeamStandings';
import ScheduleSection from '../../components/public/ScheduleSection';
import LeaderboardSection from '../../components/public/LeaderboardSection';
import BottomNav from '../../components/public/BottomNav';
import LoadingSkeleton from '../../components/public/LoadingSkeleton';
import { useResponsive } from '../../hooks/useResponsive';
import { useScrollAnimation } from '../../hooks/useScrollAnimation';
import { mockData } from '../../utils/mockDataGenerator';
import { leagueConfig } from '../../config/league.config';
import '../../styles/legacy-sports.css';

const HomepageNew: React.FC = () => {
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [activeSection, setActiveSection] = useState<string>('home');
  const [loading, setLoading] = useState(true);
  const { isMobile } = useResponsive();
  const navigate = useNavigate();

  useEffect(() => {
    // Simulate data loading
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  }, []);

  const handleNavigate = (section: string) => {
    // Handle registration navigation
    if (section === 'register') {
      navigate('/register');
      return;
    }
    
    setActiveSection(section);
    // Scroll to top when changing sections
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleDivisionChange = (division: string) => {
    setSelectedDivision(division);
  };

  if (loading) {
    return <LoadingSkeleton type="full" />;
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header with Navigation */}
      <Header 
        selectedDivision={selectedDivision}
        onDivisionChange={handleDivisionChange}
        onNavigate={handleNavigate}
      />

      {/* Home/Hero Section - Outside of main container for full width */}
      {activeSection === 'home' && (
        <HeroSection 
          totalPlayers={mockData.stats.totalPlayers}
          totalTeams={mockData.stats.totalTeams}
          totalDivisions={8}
          liveGamesCount={mockData.stats.liveGames}
          onNavigate={handleNavigate}
        />
      )}

      {/* Main Content - Add padding bottom for mobile nav */}
      <main className={`max-w-7xl mx-auto px-4 py-8 ${isMobile ? 'pb-24' : ''}`}>
        {/* Home Page Content */}
        {activeSection === 'home' && (
          <>

            {/* Games Showcase */}
            <GameShowcase 
              games={mockData.games}
              selectedDivision={selectedDivision}
            />

            {/* Quick Navigation Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
              <button
                onClick={() => handleNavigate('standings')}
                className="premium-card interactive-card spring-click p-8 text-left group hover:border-yellow-400/30 stagger-item"
                style={{ animationDelay: '0.1s' }}
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-yellow-400/20 to-yellow-600/20 flex items-center justify-center mb-4 icon-spin">
                  <Trophy className="h-8 w-8 text-yellow-400" />
                </div>
                <h3 className="text-xl font-heading font-bold text-white mb-2 group-hover:text-yellow-400 transition-colors">
                  STANDINGS
                </h3>
                <p className="text-gray-400 text-sm">Check team rankings and playoff positions</p>
              </button>
              
              <button
                onClick={() => handleNavigate('schedule')}
                className="premium-card interactive-card spring-click p-8 text-left group hover:border-cyan-400/30 stagger-item"
                style={{ animationDelay: '0.2s' }}
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-cyan-400/20 to-cyan-600/20 flex items-center justify-center mb-4 icon-spin">
                  <Calendar className="h-8 w-8 text-cyan-400" />
                </div>
                <h3 className="text-xl font-heading font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                  SCHEDULE
                </h3>
                <p className="text-gray-400 text-sm">Upcoming games and recent results</p>
              </button>
              
              <button
                onClick={() => handleNavigate('leaderboard')}
                className="premium-card interactive-card spring-click p-8 text-left group hover:border-green-400/30 stagger-item"
                style={{ animationDelay: '0.3s' }}
              >
                <div className="w-14 h-14 rounded-full bg-gradient-to-br from-green-400/20 to-green-600/20 flex items-center justify-center mb-4 icon-spin">
                  <Activity className="h-8 w-8 text-green-400" />
                </div>
                <h3 className="text-xl font-heading font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                  LEADERBOARD
                </h3>
                <p className="text-gray-400 text-sm">Top performers and MVP candidates</p>
              </button>
            </div>
          </>
        )}

        {/* Standings Section */}
        {activeSection === 'standings' && (
          <div className="page-transition">
            <TeamStandings 
              standings={mockData.standings}
              selectedDivision={selectedDivision}
              onDivisionChange={handleDivisionChange}
            />
          </div>
        )}

        {/* Schedule Section */}
        {activeSection === 'schedule' && (
          <div className="page-transition">
            <ScheduleSection 
              games={mockData.games}
              teams={mockData.teams}
              selectedDivision={selectedDivision}
            />
          </div>
        )}

        {/* Leaderboard Section */}
        {activeSection === 'leaderboard' && (
          <div className="page-transition">
            <LeaderboardSection 
              playerStats={mockData.playerStats}
              weeklyMVPs={mockData.weeklyMVPs}
              selectedDivision={selectedDivision}
            />
          </div>
        )}

        {/* Teams Section (Placeholder) */}
        {activeSection === 'teams' && (
          <div className="py-8">
            <div className="glass-panel p-12 text-center">
              <Users className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-4">Teams Directory</h2>
              <p className="text-gray-400 mb-6">
                Browse all teams, rosters, and coaching staff
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
                {mockData.teams.slice(0, 6).map(team => (
                  <div key={team.id} className="glass-panel p-4 text-left">
                    <h3 className="font-semibold text-white mb-2">{team.name}</h3>
                    <p className="text-sm text-gray-400">{team.division}</p>
                    <p className="text-sm text-gray-500">
                      Record: {team.wins}-{team.losses}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="glass-panel border-0 rounded-none mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center text-gray-400">
            <p className="mb-2 font-heading">© 2025 {leagueConfig.leagueName}. All rights reserved.</p>
            <p className="text-sm">{leagueConfig.leagueTagline} • {leagueConfig.leagueSlogan}</p>
            <p className="text-xs mt-2 text-gray-600">Powered by GameTriq League Management System</p>
          </div>
        </div>
      </footer>

      {/* Mobile Bottom Navigation */}
      {isMobile && (
        <BottomNav 
          activeSection={activeSection}
          onNavigate={handleNavigate}
        />
      )}
    </div>
  );
};

export default HomepageNew;