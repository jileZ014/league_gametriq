import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  Trophy, Calendar, Users, Activity, 
  ChevronRight, Clock, MapPin, TrendingUp 
} from 'lucide-react';
import { db } from '../../firebase';
import { collection, query, getDocs, where, orderBy, limit } from 'firebase/firestore';
import type { ContractGame, ContractTeam, ContractStanding } from '../../types/contract.types';

interface LeagueInfo {
  name: string;
  logo?: string;
  season: string;
  description: string;
}

const PublicHomepage: React.FC = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [leagueInfo] = useState<LeagueInfo>({
    name: 'Youth Basketball League',
    season: 'Winter 2025',
    description: 'Phoenix Premier Youth Basketball League'
  });
  const [upcomingGames, setUpcomingGames] = useState<ContractGame[]>([]);
  const [topTeams, setTopTeams] = useState<ContractStanding[]>([]);
  const [liveGames, setLiveGames] = useState<ContractGame[]>([]);
  const [stats, setStats] = useState({
    totalTeams: 0,
    totalGames: 0,
    liveGamesCount: 0,
    totalDivisions: 0
  });

  useEffect(() => {
    console.log('📊 PUBLIC HOMEPAGE LOADED - NO AUTH REQUIRED');
    console.log('Contract Compliance: PUBLIC ACCESS ✅');
    loadPublicData();
    // Set up real-time updates
    const interval = setInterval(loadPublicData, 30000); // Update every 30 seconds
    return () => clearInterval(interval);
  }, []);

  const loadPublicData = async () => {
    try {
      // Load upcoming games
      const gamesQuery = query(collection(db, 'games'));
      const gamesSnapshot = await getDocs(gamesQuery).catch(() => null);
      
      // If no data or error, use mock data
      if (!gamesSnapshot || gamesSnapshot.empty) {
        console.log('Using mock data for public homepage');
        setUpcomingGames([]);
        setLiveGames([]);
        setTopTeams([]);
        setStats({
          totalTeams: 24,
          totalGames: 60,
          liveGamesCount: 0,
          totalDivisions: 5
        });
        setLoading(false);
        return;
      }
      
      const gamesData = gamesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as ContractGame));

      // Filter games by status
      const today = new Date().toISOString().split('T')[0];
      const upcoming = gamesData
        .filter(g => g.status === 'scheduled' && g.date >= today)
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 5);
      
      const live = gamesData.filter(g => g.status === 'in_progress');

      setUpcomingGames(upcoming);
      setLiveGames(live);

      // Load teams and calculate standings
      const teamsQuery = query(collection(db, 'teams'));
      const teamsSnapshot = await getDocs(teamsQuery);
      const teamsData = teamsSnapshot.docs.map(doc => {
        const data = doc.data();
        const wins = data.wins || 0;
        const losses = data.losses || 0;
        const totalGames = wins + losses;
        return {
          teamId: doc.id,
          teamName: data.name,
          division: data.division,
          wins,
          losses,
          winPercentage: totalGames > 0 ? (wins / totalGames) : 0,
          gamesBack: 0,
          pointsFor: data.pointsFor || 0,
          pointsAgainst: data.pointsAgainst || 0,
          differential: (data.pointsFor || 0) - (data.pointsAgainst || 0),
          streak: data.streak || 'W0',
          lastFive: data.lastFive || '0-0',
          position: 0
        } as ContractStanding;
      });

      // Sort by win percentage and get top 5
      const topTeamsList = teamsData
        .sort((a, b) => b.winPercentage - a.winPercentage)
        .slice(0, 5);

      setTopTeams(topTeamsList);

      // Calculate stats
      const divisions = new Set(teamsData.map(t => t.division));
      setStats({
        totalTeams: teamsData.length,
        totalGames: gamesData.length,
        liveGamesCount: live.length,
        totalDivisions: divisions.size
      });

      setLoading(false);
    } catch (error) {
      console.error('Error loading public data:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Section */}
      <div className="glass-panel border-0 rounded-none">
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center">
            <Trophy className="h-16 w-16 text-yellow-400 mx-auto mb-4" />
            <h1 className="text-5xl font-display font-bold text-gradient mb-4">
              {leagueInfo.name}
            </h1>
            <p className="text-xl text-gray-400 mb-2">{leagueInfo.season}</p>
            <p className="text-lg text-gray-500">{leagueInfo.description}</p>
            
            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
              <div className="glass-panel p-4">
                <Users className="h-8 w-8 text-cyan-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{stats.totalTeams}</p>
                <p className="text-sm text-gray-400">Teams</p>
              </div>
              <div className="glass-panel p-4">
                <Calendar className="h-8 w-8 text-green-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{stats.totalGames}</p>
                <p className="text-sm text-gray-400">Games</p>
              </div>
              <div className="glass-panel p-4">
                <Activity className="h-8 w-8 text-red-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{stats.liveGamesCount}</p>
                <p className="text-sm text-gray-400">Live Now</p>
              </div>
              <div className="glass-panel p-4">
                <Trophy className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
                <p className="text-2xl font-bold text-white">{stats.totalDivisions}</p>
                <p className="text-sm text-gray-400">Divisions</p>
              </div>
            </div>

            {/* Navigation Buttons */}
            <div className="flex flex-wrap justify-center gap-4 mt-8">
              <Button 
                onClick={() => navigate('/public/schedule')}
                className="glass-button text-white"
              >
                <Calendar className="h-5 w-5 mr-2" />
                View Schedule
              </Button>
              <Button 
                onClick={() => navigate('/public/standings')}
                className="glass-button text-white"
              >
                <TrendingUp className="h-5 w-5 mr-2" />
                View Standings
              </Button>
              <Button 
                onClick={() => navigate('/public/leaderboard')}
                className="glass-button text-white"
              >
                <Trophy className="h-5 w-5 mr-2" />
                Leaderboard
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Live Games */}
        {liveGames.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
              <Activity className="h-6 w-6 text-red-400 mr-2 pulse-glow" />
              Live Games
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {liveGames.map(game => (
                <Card key={game.id} className="glass-panel border-red-500/50">
                  <CardContent className="p-6">
                    <Badge className="glass-badge border-red-500/50 mb-3 pulse-glow">LIVE</Badge>
                    <div className="flex justify-between items-center">
                      <div className="text-center flex-1">
                        <p className="text-white font-semibold">{game.homeTeamName}</p>
                        <p className="text-3xl font-bold text-white">{game.homeScore}</p>
                      </div>
                      <div className="text-gray-400">VS</div>
                      <div className="text-center flex-1">
                        <p className="text-white font-semibold">{game.awayTeamName}</p>
                        <p className="text-3xl font-bold text-white">{game.awayScore}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-center gap-4 mt-4 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {game.venue}
                      </span>
                      <span>{game.division}</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Upcoming Games */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
            <Calendar className="h-6 w-6 text-green-400 mr-2" />
            Upcoming Games
          </h2>
          <div className="space-y-3">
            {upcomingGames.length === 0 ? (
              <Card className="glass-panel">
                <CardContent className="p-8 text-center">
                  <p className="text-gray-400">No upcoming games scheduled</p>
                </CardContent>
              </Card>
            ) : (
              upcomingGames.map(game => (
                <Card key={game.id} className="glass-panel">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center">
                      <div className="flex-1">
                        <p className="text-white font-semibold">
                          {game.homeTeamName} vs {game.awayTeamName}
                        </p>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-400">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(game.date).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {game.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {game.venue}
                          </span>
                        </div>
                      </div>
                      <Badge className="glass-badge">{game.division}</Badge>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
          <Button 
            onClick={() => navigate('/public/schedule')}
            className="glass-button text-white mt-4 w-full"
          >
            View Full Schedule
            <ChevronRight className="h-5 w-5 ml-2" />
          </Button>
        </div>

        {/* Top Teams */}
        <div>
          <h2 className="text-2xl font-semibold text-white mb-4 flex items-center">
            <Trophy className="h-6 w-6 text-yellow-400 mr-2" />
            Top Teams
          </h2>
          <Card className="glass-panel">
            <CardContent className="p-0">
              <div className="divide-y divide-gray-800/30">
                {topTeams.length === 0 ? (
                  <div className="p-8 text-center text-gray-400">
                    No team standings available yet
                  </div>
                ) : (
                  topTeams.map((team, index) => (
                    <div key={team.teamId} className="p-4 hover:bg-white/5 transition-colors">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center">
                            <span className="text-black font-bold text-sm">{index + 1}</span>
                          </div>
                          <div>
                            <p className="font-semibold text-white">{team.teamName}</p>
                            <p className="text-sm text-gray-400">
                              {team.division} • {team.wins}W - {team.losses}L
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-bold text-green-400">
                            .{Math.round(team.winPercentage * 1000)}
                          </p>
                          <p className="text-xs text-gray-400">WIN %</p>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
          <Button 
            onClick={() => navigate('/public/standings')}
            className="glass-button text-white mt-4 w-full"
          >
            View Full Standings
            <ChevronRight className="h-5 w-5 ml-2" />
          </Button>
        </div>
      </div>

      {/* Footer */}
      <div className="glass-panel border-0 rounded-none mt-12">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="text-center text-gray-400">
            <p className="mb-2">© 2025 {leagueInfo.name}. All rights reserved.</p>
            <p className="text-sm">Powered by GameTriq League Management System</p>
            <p className="text-xs mt-2 text-green-400">
              ✅ CONTRACT COMPLIANT - PUBLIC ACCESS - NO LOGIN REQUIRED
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PublicHomepage;