import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Home } from 'lucide-react';
import { Button } from '../../components/ui/button';
import RegistrationWizard from '../../components/registration/RegistrationWizard';
import { leagueConfig } from '../../config/league.config';

const TeamRegistration: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [registrationType, setRegistrationType] = useState<'organization' | 'team' | 'individual' | null>(null);

  useEffect(() => {
    // Determine registration type from URL
    if (location.pathname.includes('/organization')) {
      setRegistrationType('organization');
    } else if (location.pathname.includes('/team')) {
      setRegistrationType('team');
    } else if (location.pathname.includes('/individual')) {
      setRegistrationType('individual');
    }
  }, [location]);

  return (
    <div className="min-h-screen bg-navy-950">
      {/* Header */}
      <header className="glass-panel border-0 rounded-none">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/')}
                variant="ghost"
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-3">
                <img 
                  src={leagueConfig.logoUrl}
                  alt={`${leagueConfig.leagueName} Logo`}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <div>
                  <h1 className="text-xl font-bold text-white">
                    {leagueConfig.leagueShortName} Registration
                  </h1>
                  <p className="text-sm text-gray-400">Join our league for {leagueConfig.season}</p>
                </div>
              </div>
            </div>
            <Button
              onClick={() => navigate('/')}
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <Home className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <RegistrationWizard 
          initialType={registrationType}
          onTypeChange={setRegistrationType}
        />
      </div>
    </div>
  );
};

export default TeamRegistration;