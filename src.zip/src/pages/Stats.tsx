import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, TrendingUp, Award, Users, Target } from 'lucide-react';

const Stats: React.FC = () => {
  const navigate = useNavigate();

  const teamStats = {
    wins: 12,
    losses: 3,
    ppg: 72.5,
    oppg: 65.2,
    fg: 45.2,
    threePt: 38.5,
    ft: 78.9
  };

  const topPlayers = [
    { name: 'Michael Johnson', ppg: 15.2, rpg: 7.1, apg: 3.5, fg: 48.5 },
    { name: 'David Chen', ppg: 12.8, rpg: 4.2, apg: 6.3, fg: 44.2 },
    { name: 'Marcus Williams', ppg: 11.5, rpg: 8.8, apg: 2.1, fg: 52.1 },
  ];

  return (
    <div className="min-h-screen bg-navy-950">
      <div className="glass-panel p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => navigate('/dashboard')}
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-display font-bold text-gradient">
                Team Statistics
              </h1>
              <p className="text-gray-400 mt-1">2025 Season Performance</p>
            </div>
          </div>
        </div>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-white">
                <Award className="h-5 w-5 mr-2 text-yellow-500" />
                Season Record
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-white">{teamStats.wins}-{teamStats.losses}</div>
              <p className="text-gray-400">Win Rate: {((teamStats.wins / (teamStats.wins + teamStats.losses)) * 100).toFixed(1)}%</p>
              <Badge className="mt-2 bg-green-500/20 text-green-400 border-green-500/50">2nd in Division</Badge>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-white">
                <Target className="h-5 w-5 mr-2 text-basketball-orange-500" />
                Scoring Average
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-white">{teamStats.ppg}</div>
              <p className="text-gray-400">Opp PPG: {teamStats.oppg}</p>
              <Badge className="mt-2 bg-basketball-orange-500/20 text-basketball-orange-400 border-basketball-orange-500/50">
                +{(teamStats.ppg - teamStats.oppg).toFixed(1)} Differential
              </Badge>
            </CardContent>
          </Card>

          <Card className="glass-panel">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-white">
                <TrendingUp className="h-5 w-5 mr-2 text-blue-500" />
                Shooting %
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-gray-300">
                  <span>FG%</span>
                  <span className="font-bold text-white">{teamStats.fg}%</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>3PT%</span>
                  <span className="font-bold text-white">{teamStats.threePt}%</span>
                </div>
                <div className="flex justify-between text-gray-300">
                  <span>FT%</span>
                  <span className="font-bold text-white">{teamStats.ft}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="flex items-center text-white">
              <Users className="h-6 w-6 mr-2 text-basketball-orange-500" />
              Top Performers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left p-3 text-gray-400">Player</th>
                    <th className="text-center p-3 text-gray-400">PPG</th>
                    <th className="text-center p-3 text-gray-400">RPG</th>
                    <th className="text-center p-3 text-gray-400">APG</th>
                    <th className="text-center p-3 text-gray-400">FG%</th>
                  </tr>
                </thead>
                <tbody>
                  {topPlayers.map((player, idx) => (
                    <tr key={idx} className="border-b border-gray-800 hover:bg-white/5 transition-colors">
                      <td className="p-3 font-semibold text-white">{player.name}</td>
                      <td className="text-center p-3 text-gray-300">{player.ppg}</td>
                      <td className="text-center p-3 text-gray-300">{player.rpg}</td>
                      <td className="text-center p-3 text-gray-300">{player.apg}</td>
                      <td className="text-center p-3 text-gray-300">{player.fg}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Stats;