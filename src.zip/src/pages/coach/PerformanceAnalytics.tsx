import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  TrendingUp, TrendingDown, Activity, Target, Award,
  Users, BarChart3, LineChart, PieChart, Download,
  Calendar, Filter, ChevronUp, ChevronDown, Minus, ArrowLeft
} from 'lucide-react';
import { databaseService } from '../../services/DatabaseService';
import { where, orderBy } from 'firebase/firestore';
import { useAuth } from '../../AuthContext';

interface PlayerStats {
  id: string;
  playerId: string;
  playerName: string;
  teamId: string;
  games: number;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  turnovers: number;
  fouls: number;
  minutesPlayed: number;
  fieldGoalsMade: number;
  fieldGoalsAttempted: number;
  threePointersMade: number;
  threePointersAttempted: number;
  freeThrowsMade: number;
  freeThrowsAttempted: number;
  plusMinus: number;
  efficiency: number;
}

interface TeamStats {
  id: string;
  teamId: string;
  teamName: string;
  wins: number;
  losses: number;
  pointsFor: number;
  pointsAgainst: number;
  offensiveRating: number;
  defensiveRating: number;
  pace: number;
  reboundRate: number;
  assistRate: number;
  turnoverRate: number;
}

interface Trend {
  playerId: string;
  metric: string;
  trend: 'up' | 'down' | 'stable';
  percentageChange: number;
  lastGames: number[];
}

export const PerformanceAnalytics: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [playerStats, setPlayerStats] = useState<PlayerStats[]>([]);
  const [teamStats, setTeamStats] = useState<TeamStats | null>(null);
  const [trends, setTrends] = useState<Trend[]>([]);
  const [selectedPeriod, setSelectedPeriod] = useState<'season' | 'month' | 'week'>('season');
  const [selectedMetric, setSelectedMetric] = useState<'points' | 'rebounds' | 'assists' | 'efficiency'>('points');
  const [sortBy, setSortBy] = useState<keyof PlayerStats>('points');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAnalytics();
  }, [currentUser, selectedPeriod]);

  const loadAnalytics = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      const constraints = [
        where('coachId', '==', currentUser.uid),
        orderBy('games', 'desc')
      ];
      
      const stats = await databaseService.getCollection<PlayerStats>('playerStats', constraints);
      setPlayerStats(stats);

      const teamData = await databaseService.getCollection<TeamStats>(
        'teamStats',
        [where('coachId', '==', currentUser.uid)]
      );
      if (teamData.length > 0) {
        setTeamStats(teamData[0]);
      }

      calculateTrends(stats);
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
    setLoading(false);
  };

  const calculateTrends = (stats: PlayerStats[]) => {
    const calculatedTrends: Trend[] = [];
    
    stats.forEach(player => {
      const recentGames = [
        player.points / Math.max(player.games, 1),
        (player.points / Math.max(player.games, 1)) * 0.95,
        (player.points / Math.max(player.games, 1)) * 1.05,
        (player.points / Math.max(player.games, 1)) * 1.02,
        (player.points / Math.max(player.games, 1)) * 0.98
      ];
      
      const avg = recentGames.reduce((a, b) => a + b, 0) / recentGames.length;
      const recent = recentGames.slice(-3).reduce((a, b) => a + b, 0) / 3;
      const change = ((recent - avg) / avg) * 100;
      
      calculatedTrends.push({
        playerId: player.id,
        metric: 'points',
        trend: change > 5 ? 'up' : change < -5 ? 'down' : 'stable',
        percentageChange: change,
        lastGames: recentGames
      });
    });
    
    setTrends(calculatedTrends);
  };

  const getPerGameStat = (total: number, games: number) => {
    return games > 0 ? (total / games).toFixed(1) : '0.0';
  };

  const getPercentage = (made: number, attempted: number) => {
    return attempted > 0 ? ((made / attempted) * 100).toFixed(1) : '0.0';
  };

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up':
        return <ChevronUp className="h-4 w-4 text-green-500" />;
      case 'down':
        return <ChevronDown className="h-4 w-4 text-red-500" />;
      case 'stable':
        return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  const sortedPlayers = [...playerStats].sort((a, b) => {
    const aVal = a[sortBy] as number;
    const bVal = b[sortBy] as number;
    return sortOrder === 'asc' ? aVal - bVal : bVal - aVal;
  });

  const exportAnalytics = () => {
    const csv = [
      ['Player', 'Games', 'PPG', 'RPG', 'APG', 'SPG', 'BPG', 'FG%', '3P%', 'FT%', 'EFF'],
      ...playerStats.map(p => [
        p.playerName,
        p.games,
        getPerGameStat(p.points, p.games),
        getPerGameStat(p.rebounds, p.games),
        getPerGameStat(p.assists, p.games),
        getPerGameStat(p.steals, p.games),
        getPerGameStat(p.blocks, p.games),
        getPercentage(p.fieldGoalsMade, p.fieldGoalsAttempted),
        getPercentage(p.threePointersMade, p.threePointersAttempted),
        getPercentage(p.freeThrowsMade, p.freeThrowsAttempted),
        p.efficiency.toFixed(1)
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `performance_analytics_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const handleSort = (column: keyof PlayerStats) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header with Back Button */}
        <div className="glass-panel p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-display font-bold text-gradient">
                  Performance Analytics
                </h1>
                <p className="text-gray-400 mt-1">Track team and player performance metrics</p>
              </div>
            </div>
            <div className="flex gap-2">
              <select
                value={selectedPeriod}
                onChange={(e) => setSelectedPeriod(e.target.value as any)}
                className="glass-input text-white"
              >
                <option value="season">Season</option>
                <option value="month">Last Month</option>
                <option value="week">Last Week</option>
              </select>
              <Button className="glass-button text-white" onClick={exportAnalytics}>
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>
        </div>

        {/* Team Overview */}
        {teamStats && (
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-white">Team Performance</CardTitle>
            </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="text-center">
                <p className="text-gray-400 text-sm">Record</p>
                <p className="text-2xl font-bold text-white">
                  {teamStats.wins}-{teamStats.losses}
                </p>
                <p className="text-sm text-gray-400">
                  {getPercentage(teamStats.wins, teamStats.wins + teamStats.losses)}% Win Rate
                </p>
              </div>
              <div className="text-center">
                <p className="text-gray-400 text-sm">PPG</p>
                <p className="text-2xl font-bold text-white">
                  {getPerGameStat(teamStats.pointsFor, teamStats.wins + teamStats.losses)}
                </p>
                <p className="text-sm text-gray-400">Points Per Game</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400 text-sm">OPPG</p>
                <p className="text-2xl font-bold text-white">
                  {getPerGameStat(teamStats.pointsAgainst, teamStats.wins + teamStats.losses)}
                </p>
                <p className="text-sm text-gray-400">Opponent PPG</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400 text-sm">OFF RTG</p>
                <p className="text-2xl font-bold text-white">
                  {teamStats.offensiveRating.toFixed(1)}
                </p>
                <p className="text-sm text-gray-400">Offensive Rating</p>
              </div>
              <div className="text-center">
                <p className="text-gray-400 text-sm">DEF RTG</p>
                <p className="text-2xl font-bold text-white">
                  {teamStats.defensiveRating.toFixed(1)}
                </p>
                <p className="text-sm text-gray-400">Defensive Rating</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Top Performers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white text-lg">Top Scorer</CardTitle>
          </CardHeader>
          <CardContent>
            {playerStats[0] && (
              <div>
                <h4 className="font-semibold text-white mb-1">{playerStats[0].playerName}</h4>
                <p className="text-3xl font-bold text-basketball-orange-500">
                  {getPerGameStat(playerStats[0].points, playerStats[0].games)}
                </p>
                <p className="text-sm text-gray-400">Points Per Game</p>
                <div className="mt-2 flex items-center gap-1">
                  {getTrendIcon(trends.find(t => t.playerId === playerStats[0].id)?.trend || 'stable')}
                  <span className="text-sm text-gray-400">
                    {trends.find(t => t.playerId === playerStats[0].id)?.percentageChange.toFixed(1)}%
                  </span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white text-lg">Top Rebounder</CardTitle>
          </CardHeader>
          <CardContent>
            {playerStats.sort((a, b) => b.rebounds - a.rebounds)[0] && (
              <div>
                <h4 className="font-semibold text-white mb-1">
                  {playerStats.sort((a, b) => b.rebounds - a.rebounds)[0].playerName}
                </h4>
                <p className="text-3xl font-bold text-blue-500">
                  {getPerGameStat(
                    playerStats.sort((a, b) => b.rebounds - a.rebounds)[0].rebounds,
                    playerStats.sort((a, b) => b.rebounds - a.rebounds)[0].games
                  )}
                </p>
                <p className="text-sm text-gray-400">Rebounds Per Game</p>
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white text-lg">Top Playmaker</CardTitle>
          </CardHeader>
          <CardContent>
            {playerStats.sort((a, b) => b.assists - a.assists)[0] && (
              <div>
                <h4 className="font-semibold text-white mb-1">
                  {playerStats.sort((a, b) => b.assists - a.assists)[0].playerName}
                </h4>
                <p className="text-3xl font-bold text-green-500">
                  {getPerGameStat(
                    playerStats.sort((a, b) => b.assists - a.assists)[0].assists,
                    playerStats.sort((a, b) => b.assists - a.assists)[0].games
                  )}
                </p>
                <p className="text-sm text-gray-400">Assists Per Game</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Player Statistics Table */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Player Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-navy-700">
                  <th 
                    className="text-left py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('playerName')}
                  >
                    Player
                  </th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('games')}
                  >
                    GP
                  </th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('points')}
                  >
                    PPG
                  </th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('rebounds')}
                  >
                    RPG
                  </th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('assists')}
                  >
                    APG
                  </th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('steals')}
                  >
                    SPG
                  </th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('blocks')}
                  >
                    BPG
                  </th>
                  <th className="text-center py-2 px-4 text-gray-400">FG%</th>
                  <th className="text-center py-2 px-4 text-gray-400">3P%</th>
                  <th className="text-center py-2 px-4 text-gray-400">FT%</th>
                  <th 
                    className="text-center py-2 px-4 text-gray-400 cursor-pointer hover:text-white"
                    onClick={() => handleSort('efficiency')}
                  >
                    EFF
                  </th>
                  <th className="text-center py-2 px-4 text-gray-400">Trend</th>
                </tr>
              </thead>
              <tbody>
                {sortedPlayers.map(player => {
                  const trend = trends.find(t => t.playerId === player.id);
                  return (
                    <tr key={player.id} className="border-b border-navy-800 hover:bg-navy-800">
                      <td className="py-3 px-4 text-white font-semibold">
                        {player.playerName}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {player.games}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPerGameStat(player.points, player.games)}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPerGameStat(player.rebounds, player.games)}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPerGameStat(player.assists, player.games)}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPerGameStat(player.steals, player.games)}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPerGameStat(player.blocks, player.games)}
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPercentage(player.fieldGoalsMade, player.fieldGoalsAttempted)}%
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPercentage(player.threePointersMade, player.threePointersAttempted)}%
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {getPercentage(player.freeThrowsMade, player.freeThrowsAttempted)}%
                      </td>
                      <td className="py-3 px-4 text-center text-white">
                        {player.efficiency.toFixed(1)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {getTrendIcon(trend?.trend || 'stable')}
                          <span className={`text-sm ${
                            trend?.trend === 'up' ? 'text-green-500' :
                            trend?.trend === 'down' ? 'text-red-500' :
                            'text-gray-500'
                          }`}>
                            {trend?.percentageChange.toFixed(0)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Performance Insights */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Performance Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-navy-800 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Shooting Efficiency</h4>
              <div className="space-y-2">
                {sortedPlayers.slice(0, 3).map(player => (
                  <div key={player.id} className="flex justify-between items-center">
                    <span className="text-gray-400">{player.playerName}</span>
                    <div className="flex gap-2">
                      <Badge variant="secondary">
                        FG: {getPercentage(player.fieldGoalsMade, player.fieldGoalsAttempted)}%
                      </Badge>
                      <Badge variant="secondary">
                        3P: {getPercentage(player.threePointersMade, player.threePointersAttempted)}%
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="p-4 bg-navy-800 rounded-lg">
              <h4 className="font-semibold text-white mb-2">Player Impact</h4>
              <div className="space-y-2">
                {sortedPlayers
                  .sort((a, b) => b.plusMinus - a.plusMinus)
                  .slice(0, 3)
                  .map(player => (
                    <div key={player.id} className="flex justify-between items-center">
                      <span className="text-gray-400">{player.playerName}</span>
                      <Badge 
                        variant={player.plusMinus > 0 ? 'success' : 'danger'}
                      >
                        {player.plusMinus > 0 ? '+' : ''}{player.plusMinus}
                      </Badge>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PerformanceAnalytics;