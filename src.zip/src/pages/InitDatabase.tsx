import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Database, CheckCircle, XCircle, AlertTriangle, Loader } from 'lucide-react';
import { initializeDatabase, TEST_CREDENTIALS } from '../scripts/initializeDatabase';

export const InitDatabase: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<string[]>([]);

  const handleInitialize = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    setProgress(['Starting database initialization...']);

    try {
      setProgress(prev => [...prev, 'Creating user accounts...']);
      setProgress(prev => [...prev, 'Setting up collections...']);
      setProgress(prev => [...prev, 'Generating test data...']);
      
      const dbResult = await initializeDatabase();
      
      setProgress(prev => [...prev, '✅ Database initialization complete!']);
      setResult(dbResult);
    } catch (err: any) {
      console.error('Initialization error:', err);
      setError(err.message || 'Failed to initialize database');
      setProgress(prev => [...prev, `❌ Error: ${err.message}`]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-violet-900 p-8">
      <div className="max-w-4xl mx-auto">
        <Card className="bg-gray-900/90 border-purple-500/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-3xl text-white flex items-center gap-3">
              <Database className="h-8 w-8 text-purple-400" />
              Database Initialization
            </CardTitle>
            <p className="text-gray-400 mt-2">
              Initialize the Firestore database with all required collections and test data
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Warning */}
            <div className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
                <div>
                  <p className="text-yellow-300 font-semibold">Warning</p>
                  <p className="text-gray-300 text-sm mt-1">
                    This will create test data in your Firebase project. Make sure you're connected to the correct project.
                  </p>
                </div>
              </div>
            </div>

            {/* Collections to Create */}
            <div className="space-y-3">
              <h3 className="text-white font-semibold">Collections to be created:</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {[
                  'users (4 roles)',
                  'teams (24)',
                  'players (240)',
                  'games (60)',
                  'seasons (2)',
                  'divisions (5)',
                  'venues (6)',
                  'standings (24)',
                  'emergencyContacts (50)',
                  'staff (30)',
                  'financials (20)',
                  'incidents'
                ].map((collection) => (
                  <Badge key={collection} className="bg-purple-500/20 text-purple-300 border-purple-500/50">
                    {collection}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Progress Log */}
            {progress.length > 0 && (
              <div className="bg-gray-800/50 rounded-lg p-4 max-h-60 overflow-y-auto">
                <h3 className="text-white font-semibold mb-2">Progress:</h3>
                <div className="space-y-1">
                  {progress.map((msg, index) => (
                    <p key={index} className="text-gray-300 text-sm font-mono">
                      {msg}
                    </p>
                  ))}
                </div>
              </div>
            )}

            {/* Results */}
            {result && (
              <div className="bg-green-500/10 border border-green-500/50 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-400 mt-0.5" />
                  <div className="space-y-3 flex-1">
                    <p className="text-green-300 font-semibold">Database Initialized Successfully!</p>
                    
                    <div className="space-y-2">
                      <p className="text-white font-semibold">Test Credentials:</p>
                      {result.credentials?.map((cred: any) => (
                        <div key={cred.email} className="bg-gray-800/50 rounded p-2">
                          <p className="text-gray-300 text-sm">
                            <span className="text-purple-400 font-semibold">{cred.role.toUpperCase()}:</span>
                          </p>
                          <p className="text-gray-400 text-xs mt-1">
                            Email: <span className="text-white font-mono">{cred.email}</span>
                          </p>
                          <p className="text-gray-400 text-xs">
                            Password: <span className="text-white font-mono">{cred.password}</span>
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Error */}
            {error && (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <XCircle className="h-5 w-5 text-red-400 mt-0.5" />
                  <div>
                    <p className="text-red-300 font-semibold">Initialization Failed</p>
                    <p className="text-gray-300 text-sm mt-1">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Action Button */}
            <div className="flex justify-center pt-4">
              <Button
                onClick={handleInitialize}
                disabled={loading}
                className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3"
              >
                {loading ? (
                  <>
                    <Loader className="h-5 w-5 mr-2 animate-spin" />
                    Initializing...
                  </>
                ) : (
                  <>
                    <Database className="h-5 w-5 mr-2" />
                    Initialize Database
                  </>
                )}
              </Button>
            </div>

            {/* Quick Test Links */}
            {result && (
              <div className="border-t border-gray-700 pt-4">
                <p className="text-gray-400 text-sm mb-3">Quick Links:</p>
                <div className="flex flex-wrap gap-2">
                  <a href="/login" className="text-purple-400 hover:text-purple-300 text-sm underline">
                    Login Page
                  </a>
                  <a href="/" className="text-purple-400 hover:text-purple-300 text-sm underline">
                    Public Homepage
                  </a>
                  <a href="/public/schedule" className="text-purple-400 hover:text-purple-300 text-sm underline">
                    Public Schedule
                  </a>
                  <a href="/public/standings" className="text-purple-400 hover:text-purple-300 text-sm underline">
                    Public Standings
                  </a>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default InitDatabase;