import React, { useState } from 'react';
import { useAuth } from '../AuthContext';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../firebase';

export const TestPage: React.FC = () => {
  const { currentUser } = useAuth();
  const [testResults, setTestResults] = useState<string[]>([]);
  const [email, setEmail] = useState('admin@gametriq.com');
  const [password, setPassword] = useState('Admin123!');

  const runTests = async () => {
    const results: string[] = [];
    
    // Test 1: Check if Firebase is initialized
    if (auth) {
      results.push('✅ Firebase Auth initialized');
    } else {
      results.push('❌ Firebase Auth not initialized');
    }
    
    // Test 2: Check current user
    if (currentUser) {
      results.push(`✅ User logged in: ${currentUser.email}`);
    } else {
      results.push('⚠️ No user logged in');
    }
    
    // Test 3: Try to login
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      results.push(`✅ Login successful: ${userCredential.user.email}`);
    } catch (error: any) {
      results.push(`❌ Login failed: ${error.message}`);
    }
    
    // Test 4: Check localStorage
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    results.push(`📦 LocalStorage - Token: ${token ? 'Present' : 'Missing'}, Role: ${role || 'None'}`);
    
    // Test 5: Check services
    try {
      const { AuthService } = await import('../services/AuthService');
      const authService = AuthService.getInstance();
      results.push('✅ AuthService loaded');
    } catch (error: any) {
      results.push(`❌ AuthService error: ${error.message}`);
    }
    
    try {
      const { databaseService } = await import('../services/DatabaseService');
      const status = databaseService.getConnectionStatus();
      results.push(`✅ DatabaseService: ${status ? 'Online' : 'Offline'}`);
    } catch (error: any) {
      results.push(`❌ DatabaseService error: ${error.message}`);
    }
    
    setTestResults(results);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-8">
      <h1 className="text-3xl font-bold mb-8">GameTriQ System Test</h1>
      
      <div className="mb-8 space-y-4">
        <div>
          <label className="block mb-2">Test Email:</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="px-4 py-2 bg-gray-800 rounded"
          />
        </div>
        <div>
          <label className="block mb-2">Test Password:</label>
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="px-4 py-2 bg-gray-800 rounded"
          />
        </div>
        <button
          onClick={runTests}
          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded font-semibold"
        >
          Run System Tests
        </button>
      </div>
      
      <div className="space-y-2">
        <h2 className="text-xl font-semibold mb-4">Test Results:</h2>
        {testResults.map((result, index) => (
          <div key={index} className="p-3 bg-gray-800 rounded">
            {result}
          </div>
        ))}
      </div>
      
      <div className="mt-8 p-4 bg-gray-800 rounded">
        <h3 className="font-semibold mb-2">Current User Info:</h3>
        <pre className="text-sm">
          {JSON.stringify(currentUser, null, 2)}
        </pre>
      </div>
    </div>
  );
};

export default TestPage;