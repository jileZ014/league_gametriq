import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Calendar, Clock, MapPin, Plus, Navigation, Eye } from 'lucide-react';

const Schedule: React.FC = () => {
  const navigate = useNavigate();
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [newEvent, setNewEvent] = useState({
    date: '',
    time: '',
    opponent: '',
    location: '',
    type: 'Practice',
    home: true
  });
  
  const [games, setGames] = useState([
    { 
      id: 1, 
      date: 'Tomorrow', 
      time: '3:00 PM', 
      opponent: 'Mesa Thunder', 
      location: 'Court A', 
      type: 'League Game',
      home: true 
    },
    { 
      id: 2, 
      date: 'Sat, Jan 25', 
      time: '1:00 PM', 
      opponent: 'Scottsdale Eagles', 
      location: 'Court B', 
      type: 'League Game',
      home: false 
    },
    { 
      id: 3, 
      date: 'Wed, Jan 29', 
      time: '5:30 PM', 
      opponent: 'Tempe Warriors', 
      location: 'Court A', 
      type: 'Tournament',
      home: true 
    },
    { 
      id: 4, 
      date: 'Sat, Feb 1', 
      time: '2:00 PM', 
      opponent: 'Chandler Knights', 
      location: 'Away Gym', 
      type: 'League Game',
      home: false 
    },
  ]);

  const handleAddEvent = () => {
    if (newEvent.date && newEvent.time) {
      const newGame = {
        id: games.length + 1,
        ...newEvent
      };
      setGames([...games, newGame]);
      setNewEvent({
        date: '',
        time: '',
        opponent: '',
        location: '',
        type: 'Practice',
        home: true
      });
      setShowAddEvent(false);
    }
  };

  const handleViewDetails = (gameId: number) => {
    // Navigate to game details page
    console.log('View details for game:', gameId);
  };

  const handleGetDirections = (location: string) => {
    // Open maps with location
    window.open(`https://maps.google.com/?q=${encodeURIComponent(location)}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-navy-950">
      <div className="glass-panel p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => navigate('/dashboard')}
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-display font-bold text-gradient">
                Game Schedule
              </h1>
              <p className="text-gray-400 mt-1">Upcoming Games & Practices</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowAddEvent(!showAddEvent)}
            className="glass-button bg-basketball-orange-500/20 hover:bg-basketball-orange-500/30 text-white"
          >
            <Plus className="h-5 w-5 mr-2" />
            Add Event
          </Button>
        </div>
      </div>

      {/* Add Event Form */}
      {showAddEvent && (
        <div className="glass-panel p-6 mb-6 max-w-7xl mx-auto">
          <h2 className="text-xl font-bold text-white mb-4">Add New Event</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Date</label>
              <input
                type="date"
                value={newEvent.date}
                onChange={(e) => setNewEvent({...newEvent, date: e.target.value})}
                className="glass-input w-full text-white"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Time</label>
              <input
                type="time"
                value={newEvent.time}
                onChange={(e) => setNewEvent({...newEvent, time: e.target.value})}
                className="glass-input w-full text-white"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Opponent/Event Name</label>
              <input
                type="text"
                value={newEvent.opponent}
                onChange={(e) => setNewEvent({...newEvent, opponent: e.target.value})}
                className="glass-input w-full text-white"
                placeholder="Enter opponent team or event name"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Location</label>
              <input
                type="text"
                value={newEvent.location}
                onChange={(e) => setNewEvent({...newEvent, location: e.target.value})}
                className="glass-input w-full text-white"
                placeholder="Enter venue or court"
              />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Event Type</label>
              <select
                value={newEvent.type}
                onChange={(e) => setNewEvent({...newEvent, type: e.target.value})}
                className="glass-input w-full text-white"
              >
                <option value="Practice">Practice</option>
                <option value="League Game">League Game</option>
                <option value="Tournament">Tournament</option>
                <option value="Scrimmage">Scrimmage</option>
              </select>
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-2">Home/Away</label>
              <select
                value={newEvent.home ? 'home' : 'away'}
                onChange={(e) => setNewEvent({...newEvent, home: e.target.value === 'home'})}
                className="glass-input w-full text-white"
              >
                <option value="home">Home</option>
                <option value="away">Away</option>
              </select>
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <Button
              onClick={() => setShowAddEvent(false)}
              variant="ghost"
              className="text-gray-400 hover:text-white"
            >
              Cancel
            </Button>
            <Button
              onClick={handleAddEvent}
              className="glass-button bg-green-500/20 hover:bg-green-500/30 text-white"
            >
              Save Event
            </Button>
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid gap-4">
          {games.map((game) => (
            <Card key={game.id} className="glass-panel hover:border-basketball-orange-500/50 transition-all">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <Badge 
                        className={game.home 
                          ? 'bg-green-500/20 text-green-400 border-green-500/50' 
                          : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50'
                        }
                      >
                        {game.home ? 'HOME' : 'AWAY'}
                      </Badge>
                      <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/50">
                        {game.type}
                      </Badge>
                    </div>
                    <h3 className="text-xl font-bold mb-2 text-white">
                      {game.home ? 'Your Team' : game.opponent} vs {game.home ? game.opponent : 'Your Team'}
                    </h3>
                    <div className="flex flex-wrap gap-4 text-gray-400">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-basketball-orange-400" />
                        {game.date}
                      </div>
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-2 text-basketball-orange-400" />
                        {game.time}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="h-4 w-4 mr-2 text-basketball-orange-400" />
                        {game.location}
                      </div>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button 
                      onClick={() => handleViewDetails(game.id)}
                      variant="ghost"
                      className="text-white hover:bg-white/10"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                    <Button 
                      onClick={() => handleGetDirections(game.location)}
                      className="glass-button bg-basketball-orange-500/20 hover:bg-basketball-orange-500/30 text-white"
                    >
                      <Navigation className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Schedule;