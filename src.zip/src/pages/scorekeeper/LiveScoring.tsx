import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  Play, Pause, RotateCcw, Save, AlertCircle,
  Plus, Minus, Clock, Users, Trophy, Target,
  ChevronUp, ChevronDown, Wifi, WifiOff, Volume2
} from 'lucide-react';
import { databaseService } from '../../services/DatabaseService';
import { useAuth } from '../../AuthContext';

interface Game {
  id: string;
  homeTeam: string;
  homeTeamId: string;
  awayTeam: string;
  awayTeamId: string;
  homeScore: number;
  awayScore: number;
  period: number;
  timeRemaining: string;
  status: 'scheduled' | 'in_progress' | 'halftime' | 'completed';
  venue: string;
  date: string;
  startTime?: string;
  endTime?: string;
}

interface Player {
  id: string;
  name: string;
  number: number;
  team: 'home' | 'away';
  points: number;
  fouls: number;
  isActive: boolean;
}

interface GameEvent {
  id: string;
  timestamp: string;
  period: number;
  timeRemaining: string;
  type: 'score' | 'foul' | 'timeout' | 'substitution' | 'period_end';
  team: 'home' | 'away';
  playerId?: string;
  playerName?: string;
  points?: number;
  description: string;
}

interface GameClock {
  minutes: number;
  seconds: number;
  isRunning: boolean;
  period: number;
}

export const LiveScoring: React.FC = () => {
  const { currentUser } = useAuth();
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [games, setGames] = useState<Game[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [events, setEvents] = useState<GameEvent[]>([]);
  const [clock, setClock] = useState<GameClock>({
    minutes: 10,
    seconds: 0,
    isRunning: false,
    period: 1
  });
  const [isOnline, setIsOnline] = useState(true);
  const [unsavedChanges, setUnsavedChanges] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const clockInterval = useRef<NodeJS.Timeout | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    loadGames();
    setupOfflineHandling();
    
    return () => {
      if (clockInterval.current) {
        clearInterval(clockInterval.current);
      }
    };
  }, []);

  useEffect(() => {
    if (clock.isRunning) {
      clockInterval.current = setInterval(() => {
        setClock(prev => {
          if (prev.seconds === 0) {
            if (prev.minutes === 0) {
              handlePeriodEnd();
              return { ...prev, isRunning: false };
            }
            return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
          }
          return { ...prev, seconds: prev.seconds - 1 };
        });
      }, 1000);
    } else {
      if (clockInterval.current) {
        clearInterval(clockInterval.current);
      }
    }
    
    return () => {
      if (clockInterval.current) {
        clearInterval(clockInterval.current);
      }
    };
  }, [clock.isRunning]);

  const setupOfflineHandling = () => {
    window.addEventListener('online', () => {
      setIsOnline(true);
      syncOfflineData();
    });
    
    window.addEventListener('offline', () => {
      setIsOnline(false);
    });
  };

  const loadGames = async () => {
    try {
      const today = new Date().toISOString().split('T')[0];
      const gamesData = await databaseService.getCollection<Game>(
        'games',
        [
          where('date', '==', today),
          where('status', 'in', ['scheduled', 'in_progress'])
        ]
      );
      setGames(gamesData);
    } catch (error) {
      console.error('Error loading games:', error);
    }
  };

  const loadGameDetails = async (game: Game) => {
    setSelectedGame(game);
    
    try {
      const [homePlayers, awayPlayers] = await Promise.all([
        databaseService.getCollection<Player>(
          'players',
          [where('teamId', '==', game.homeTeamId)]
        ),
        databaseService.getCollection<Player>(
          'players',
          [where('teamId', '==', game.awayTeamId)]
        )
      ]);
      
      setPlayers([
        ...homePlayers.map(p => ({ ...p, team: 'home' as const })),
        ...awayPlayers.map(p => ({ ...p, team: 'away' as const }))
      ]);
      
      const gameEvents = await databaseService.getCollection<GameEvent>(
        'gameEvents',
        [
          where('gameId', '==', game.id),
          orderBy('timestamp', 'desc')
        ]
      );
      setEvents(gameEvents);
    } catch (error) {
      console.error('Error loading game details:', error);
    }
  };

  const handleScoreChange = (team: 'home' | 'away', points: number) => {
    if (!selectedGame) return;
    
    const newScore = team === 'home' 
      ? selectedGame.homeScore + points
      : selectedGame.awayScore + points;
    
    if (newScore < 0) return;
    
    setSelectedGame({
      ...selectedGame,
      homeScore: team === 'home' ? newScore : selectedGame.homeScore,
      awayScore: team === 'away' ? newScore : selectedGame.awayScore
    });
    
    const event: GameEvent = {
      id: `event_${Date.now()}`,
      timestamp: new Date().toISOString(),
      period: clock.period,
      timeRemaining: `${clock.minutes}:${clock.seconds.toString().padStart(2, '0')}`,
      type: 'score',
      team,
      points,
      description: `${team === 'home' ? selectedGame.homeTeam : selectedGame.awayTeam} scores ${points} point${points > 1 ? 's' : ''}`
    };
    
    setEvents([event, ...events]);
    setUnsavedChanges(true);
    
    if (soundEnabled) {
      playSound('score');
    }
  };

  const handlePlayerScore = (player: Player, points: number) => {
    handleScoreChange(player.team, points);
    
    const updatedPlayers = players.map(p => 
      p.id === player.id 
        ? { ...p, points: p.points + points }
        : p
    );
    setPlayers(updatedPlayers);
    
    const event: GameEvent = {
      id: `event_${Date.now()}`,
      timestamp: new Date().toISOString(),
      period: clock.period,
      timeRemaining: `${clock.minutes}:${clock.seconds.toString().padStart(2, '0')}`,
      type: 'score',
      team: player.team,
      playerId: player.id,
      playerName: player.name,
      points,
      description: `#${player.number} ${player.name} scores ${points} point${points > 1 ? 's' : ''}`
    };
    
    setEvents([event, ...events]);
  };

  const handleFoul = (player: Player) => {
    const updatedPlayers = players.map(p => 
      p.id === player.id 
        ? { ...p, fouls: p.fouls + 1 }
        : p
    );
    setPlayers(updatedPlayers);
    
    const event: GameEvent = {
      id: `event_${Date.now()}`,
      timestamp: new Date().toISOString(),
      period: clock.period,
      timeRemaining: `${clock.minutes}:${clock.seconds.toString().padStart(2, '0')}`,
      type: 'foul',
      team: player.team,
      playerId: player.id,
      playerName: player.name,
      description: `Foul on #${player.number} ${player.name} (${player.fouls + 1} fouls)`
    };
    
    setEvents([event, ...events]);
    setUnsavedChanges(true);
  };

  const toggleClock = () => {
    setClock(prev => ({ ...prev, isRunning: !prev.isRunning }));
    
    if (!clock.isRunning && selectedGame) {
      setSelectedGame({ ...selectedGame, status: 'in_progress' });
    }
  };

  const resetClock = () => {
    setClock({
      minutes: 10,
      seconds: 0,
      isRunning: false,
      period: clock.period
    });
  };

  const handlePeriodEnd = () => {
    const event: GameEvent = {
      id: `event_${Date.now()}`,
      timestamp: new Date().toISOString(),
      period: clock.period,
      timeRemaining: '0:00',
      type: 'period_end',
      team: 'home',
      description: `End of Period ${clock.period}`
    };
    
    setEvents([event, ...events]);
    
    if (clock.period < 4) {
      setClock({
        minutes: 10,
        seconds: 0,
        isRunning: false,
        period: clock.period + 1
      });
      
      if (selectedGame) {
        setSelectedGame({ ...selectedGame, status: 'halftime' });
      }
    } else {
      handleGameEnd();
    }
    
    if (soundEnabled) {
      playSound('buzzer');
    }
  };

  const handleGameEnd = () => {
    if (!selectedGame) return;
    
    setSelectedGame({
      ...selectedGame,
      status: 'completed',
      endTime: new Date().toISOString()
    });
    
    saveGame();
  };

  const saveGame = async () => {
    if (!selectedGame) return;
    
    try {
      await databaseService.updateDocument('games', selectedGame.id, {
        homeScore: selectedGame.homeScore,
        awayScore: selectedGame.awayScore,
        status: selectedGame.status,
        period: clock.period,
        timeRemaining: `${clock.minutes}:${clock.seconds.toString().padStart(2, '0')}`,
        endTime: selectedGame.endTime
      });
      
      const eventBatch = events.map(event => ({
        type: 'create' as const,
        collection: 'gameEvents',
        id: event.id,
        data: { ...event, gameId: selectedGame.id }
      }));
      
      await databaseService.batchWrite(eventBatch);
      
      const playerStats = players.map(player => ({
        type: 'update' as const,
        collection: 'playerStats',
        id: player.id,
        data: {
          points: player.points,
          fouls: player.fouls,
          gamesPlayed: 1
        }
      }));
      
      await databaseService.batchWrite(playerStats);
      
      setUnsavedChanges(false);
      
      if (!isOnline) {
        localStorage.setItem(`game_${selectedGame.id}`, JSON.stringify({
          game: selectedGame,
          events,
          players,
          clock
        }));
      }
    } catch (error) {
      console.error('Error saving game:', error);
    }
  };

  const syncOfflineData = async () => {
    const keys = Object.keys(localStorage).filter(k => k.startsWith('game_'));
    
    for (const key of keys) {
      try {
        const data = JSON.parse(localStorage.getItem(key)!);
        await databaseService.updateDocument('games', data.game.id, data.game);
        localStorage.removeItem(key);
      } catch (error) {
        console.error('Error syncing offline data:', error);
      }
    }
  };

  const playSound = (type: 'score' | 'buzzer') => {
    if (!soundEnabled) return;
    
    const audio = new Audio(type === 'score' ? '/sounds/score.mp3' : '/sounds/buzzer.mp3');
    audio.play().catch(e => console.log('Audio play failed:', e));
  };

  if (!selectedGame) {
    return (
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-white">Select a Game to Score</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {games.map(game => (
            <Card 
              key={game.id} 
              variant="navy" 
              className="cursor-pointer hover:border-basketball-orange-500 transition-all"
              onClick={() => loadGameDetails(game)}
            >
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-4">
                  <Badge variant={game.status === 'in_progress' ? 'success' : 'secondary'}>
                    {game.status}
                  </Badge>
                  <span className="text-sm text-gray-400">{game.venue}</span>
                </div>
                <div className="text-center">
                  <div className="grid grid-cols-3 gap-4 items-center">
                    <div>
                      <p className="font-semibold text-white">{game.homeTeam}</p>
                      <p className="text-3xl font-bold text-white">{game.homeScore}</p>
                    </div>
                    <div className="text-gray-400">VS</div>
                    <div>
                      <p className="font-semibold text-white">{game.awayTeam}</p>
                      <p className="text-3xl font-bold text-white">{game.awayScore}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <Button variant="outline" size="sm" onClick={() => setSelectedGame(null)}>
          ← Back to Games
        </Button>
        <div className="flex items-center gap-4">
          <Badge variant={isOnline ? 'success' : 'warning'}>
            {isOnline ? <Wifi className="h-3 w-3 mr-1" /> : <WifiOff className="h-3 w-3 mr-1" />}
            {isOnline ? 'Online' : 'Offline'}
          </Badge>
          {unsavedChanges && (
            <Badge variant="warning">
              <AlertCircle className="h-3 w-3 mr-1" />
              Unsaved Changes
            </Badge>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSoundEnabled(!soundEnabled)}
          >
            <Volume2 className={`h-4 w-4 ${!soundEnabled && 'opacity-50'}`} />
          </Button>
          <Button variant="primary" size="sm" onClick={saveGame}>
            <Save className="h-4 w-4 mr-2" />
            Save Game
          </Button>
        </div>
      </div>

      {/* Game Clock */}
      <Card variant="navy">
        <CardContent className="p-6">
          <div className="text-center">
            <p className="text-gray-400 mb-2">Period {clock.period}</p>
            <div className="text-6xl font-bold text-white font-mono mb-4">
              {clock.minutes}:{clock.seconds.toString().padStart(2, '0')}
            </div>
            <div className="flex justify-center gap-2">
              <Button
                variant={clock.isRunning ? 'danger' : 'success'}
                onClick={toggleClock}
              >
                {clock.isRunning ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                {clock.isRunning ? 'Pause' : 'Start'}
              </Button>
              <Button variant="secondary" onClick={resetClock}>
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Score Board */}
      <div className="grid grid-cols-2 gap-4">
        <Card variant="navy">
          <CardHeader>
            <CardTitle className="text-white text-center">{selectedGame.homeTeam}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <p className="text-6xl font-bold text-white mb-4">{selectedGame.homeScore}</p>
              <div className="flex justify-center gap-2">
                <Button size="sm" variant="secondary" onClick={() => handleScoreChange('home', -1)}>
                  <Minus className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="primary" onClick={() => handleScoreChange('home', 1)}>
                  +1
                </Button>
                <Button size="sm" variant="primary" onClick={() => handleScoreChange('home', 2)}>
                  +2
                </Button>
                <Button size="sm" variant="primary" onClick={() => handleScoreChange('home', 3)}>
                  +3
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardHeader>
            <CardTitle className="text-white text-center">{selectedGame.awayTeam}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <p className="text-6xl font-bold text-white mb-4">{selectedGame.awayScore}</p>
              <div className="flex justify-center gap-2">
                <Button size="sm" variant="secondary" onClick={() => handleScoreChange('away', -1)}>
                  <Minus className="h-4 w-4" />
                </Button>
                <Button size="sm" variant="primary" onClick={() => handleScoreChange('away', 1)}>
                  +1
                </Button>
                <Button size="sm" variant="primary" onClick={() => handleScoreChange('away', 2)}>
                  +2
                </Button>
                <Button size="sm" variant="primary" onClick={() => handleScoreChange('away', 3)}>
                  +3
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Player Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card variant="navy">
          <CardHeader>
            <CardTitle className="text-white">{selectedGame.homeTeam} Players</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {players.filter(p => p.team === 'home').map(player => (
                <div key={player.id} className="flex justify-between items-center p-2 bg-navy-800 rounded">
                  <div>
                    <span className="text-white font-semibold">#{player.number} {player.name}</span>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="secondary">PTS: {player.points}</Badge>
                      <Badge variant={player.fouls >= 5 ? 'danger' : 'secondary'}>
                        FOULS: {player.fouls}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => handlePlayerScore(player, 2)}>
                      +2
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handlePlayerScore(player, 3)}>
                      +3
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleFoul(player)}>
                      Foul
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardHeader>
            <CardTitle className="text-white">{selectedGame.awayTeam} Players</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {players.filter(p => p.team === 'away').map(player => (
                <div key={player.id} className="flex justify-between items-center p-2 bg-navy-800 rounded">
                  <div>
                    <span className="text-white font-semibold">#{player.number} {player.name}</span>
                    <div className="flex gap-2 mt-1">
                      <Badge variant="secondary">PTS: {player.points}</Badge>
                      <Badge variant={player.fouls >= 5 ? 'danger' : 'secondary'}>
                        FOULS: {player.fouls}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={() => handlePlayerScore(player, 2)}>
                      +2
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handlePlayerScore(player, 3)}>
                      +3
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => handleFoul(player)}>
                      Foul
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Game Events */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Game Events</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-h-60 overflow-y-auto space-y-2">
            {events.map(event => (
              <div key={event.id} className="flex justify-between items-center p-2 bg-navy-800 rounded">
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">P{event.period} {event.timeRemaining}</Badge>
                  <span className="text-white">{event.description}</span>
                </div>
                <Badge variant={event.team === 'home' ? 'primary' : 'warning'}>
                  {event.team === 'home' ? selectedGame.homeTeam : selectedGame.awayTeam}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default LiveScoring;