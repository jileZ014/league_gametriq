import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, Save, Timer, AlertCircle, Check, 
  ChevronUp, ChevronDown, RefreshCw, Users,
  Trophy, Target, Activity, Clock, X, Plus, Minus
} from 'lucide-react';

interface PlayerStat {
  id: string;
  name: string;
  number: string;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  fouls: number;
  turnovers: number;
  fieldGoalsMade: number;
  fieldGoalsAttempted: number;
  threePointersMade: number;
  threePointersAttempted: number;
  freeThrowsMade: number;
  freeThrowsAttempted: number;
  isStarter: boolean;
  minutesPlayed: number;
  isOnCourt: boolean;
}

interface TeamStats {
  teamId: string;
  teamName: string;
  players: PlayerStat[];
  totalPoints: number;
  totalRebounds: number;
  totalAssists: number;
  totalFouls: number;
  timeouts: number;
}

interface GameData {
  homeTeam: TeamStats;
  awayTeam: TeamStats;
  quarter: number;
  timeRemaining: string;
  gameStatus: 'not_started' | 'in_progress' | 'halftime' | 'finished';
  lastSaved: Date | null;
}

const STAT_CATEGORIES = [
  { key: 'points', label: 'PTS', color: 'text-green-400' },
  { key: 'rebounds', label: 'REB', color: 'text-blue-400' },
  { key: 'assists', label: 'AST', color: 'text-purple-400' },
  { key: 'steals', label: 'STL', color: 'text-yellow-400' },
  { key: 'blocks', label: 'BLK', color: 'text-red-400' },
  { key: 'fouls', label: 'FLS', color: 'text-orange-400' },
  { key: 'turnovers', label: 'TO', color: 'text-gray-400' }
];

export const StatTracker: React.FC = () => {
  const navigate = useNavigate();
  const { gameId } = useParams();
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  const [unsavedChanges, setUnsavedChanges] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [selectedPlayer, setSelectedPlayer] = useState<{ team: 'home' | 'away', playerId: string } | null>(null);
  
  const [gameData, setGameData] = useState<GameData>({
    homeTeam: {
      teamId: '1',
      teamName: 'Phoenix Suns',
      players: [
        { id: '1', name: 'John Smith', number: '23', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '2', name: 'Mike Johnson', number: '12', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '3', name: 'David Lee', number: '5', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '4', name: 'Chris Brown', number: '8', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '5', name: 'Ryan Davis', number: '15', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '6', name: 'Kevin White', number: '21', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: false, minutesPlayed: 0, isOnCourt: false },
        { id: '7', name: 'Tom Wilson', number: '30', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: false, minutesPlayed: 0, isOnCourt: false },
        { id: '8', name: 'James Martin', number: '11', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: false, minutesPlayed: 0, isOnCourt: false }
      ],
      totalPoints: 0,
      totalRebounds: 0,
      totalAssists: 0,
      totalFouls: 0,
      timeouts: 3
    },
    awayTeam: {
      teamId: '2',
      teamName: 'Mesa Thunder',
      players: [
        { id: '9', name: 'Alex Turner', number: '1', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '10', name: 'Sam Roberts', number: '2', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '11', name: 'Paul Garcia', number: '3', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '12', name: 'Mark Anderson', number: '4', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '13', name: 'Steve Miller', number: '7', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: true, minutesPlayed: 0, isOnCourt: true },
        { id: '14', name: 'Joe Taylor', number: '10', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: false, minutesPlayed: 0, isOnCourt: false },
        { id: '15', name: 'Dan Clark', number: '14', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: false, minutesPlayed: 0, isOnCourt: false },
        { id: '16', name: 'Nick Young', number: '20', points: 0, rebounds: 0, assists: 0, steals: 0, blocks: 0, fouls: 0, turnovers: 0, fieldGoalsMade: 0, fieldGoalsAttempted: 0, threePointersMade: 0, threePointersAttempted: 0, freeThrowsMade: 0, freeThrowsAttempted: 0, isStarter: false, minutesPlayed: 0, isOnCourt: false }
      ],
      totalPoints: 0,
      totalRebounds: 0,
      totalAssists: 0,
      totalFouls: 0,
      timeouts: 3
    },
    quarter: 1,
    timeRemaining: '10:00',
    gameStatus: 'not_started',
    lastSaved: null
  });

  // Auto-save functionality
  useEffect(() => {
    if (autoSaveEnabled && unsavedChanges) {
      const timer = setTimeout(() => {
        handleSave();
      }, 30000); // Auto-save every 30 seconds

      return () => clearTimeout(timer);
    }
  }, [gameData, autoSaveEnabled, unsavedChanges]);

  const updateStat = (team: 'home' | 'away', playerId: string, stat: string, increment: number) => {
    setGameData(prev => {
      const newData = { ...prev };
      const teamData = team === 'home' ? newData.homeTeam : newData.awayTeam;
      const player = teamData.players.find(p => p.id === playerId);
      
      if (player) {
        (player as any)[stat] = Math.max(0, (player as any)[stat] + increment);
        
        // Update team totals
        if (stat === 'points') teamData.totalPoints = teamData.players.reduce((sum, p) => sum + p.points, 0);
        if (stat === 'rebounds') teamData.totalRebounds = teamData.players.reduce((sum, p) => sum + p.rebounds, 0);
        if (stat === 'assists') teamData.totalAssists = teamData.players.reduce((sum, p) => sum + p.assists, 0);
        if (stat === 'fouls') teamData.totalFouls = teamData.players.reduce((sum, p) => sum + p.fouls, 0);
      }
      
      setUnsavedChanges(true);
      return newData;
    });
  };

  const handleSave = async () => {
    setSaveStatus('saving');
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setGameData(prev => ({
        ...prev,
        lastSaved: new Date()
      }));
      
      setSaveStatus('saved');
      setUnsavedChanges(false);
      
      setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (error) {
      setSaveStatus('error');
      console.error('Error saving game data:', error);
    }
  };

  const handleFinalizeGame = () => {
    if (unsavedChanges) {
      if (!confirm('You have unsaved changes. Save before finalizing?')) {
        return;
      }
      handleSave();
    }
    
    const homeScore = gameData.homeTeam.totalPoints;
    const awayScore = gameData.awayTeam.totalPoints;
    
    if (homeScore === awayScore) {
      alert('Game cannot end in a tie. Please verify the scores.');
      return;
    }
    
    if (confirm(`Finalize game?\n${gameData.homeTeam.teamName}: ${homeScore}\n${gameData.awayTeam.teamName}: ${awayScore}`)) {
      setGameData(prev => ({ ...prev, gameStatus: 'finished' }));
      handleSave();
    }
  };

  const QuickStatButtons = ({ team, playerId }: { team: 'home' | 'away', playerId: string }) => (
    <div className="grid grid-cols-7 gap-1">
      {STAT_CATEGORIES.map(({ key, label, color }) => (
        <div key={key} className="text-center">
          <div className={`text-xs ${color} mb-1`}>{label}</div>
          <div className="flex flex-col gap-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={() => updateStat(team, playerId, key, 1)}
              className="h-6 w-full text-white hover:bg-green-500/20 px-1"
            >
              <Plus className="h-3 w-3" />
            </Button>
            <div className="text-sm font-bold text-white">
              {(gameData[team === 'home' ? 'homeTeam' : 'awayTeam'].players.find(p => p.id === playerId) as any)?.[key] || 0}
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => updateStat(team, playerId, key, -1)}
              className="h-6 w-full text-white hover:bg-red-500/20 px-1"
            >
              <Minus className="h-3 w-3" />
            </Button>
          </div>
        </div>
      ))}
    </div>
  );

  const TeamScoreboard = ({ team, side }: { team: TeamStats, side: 'home' | 'away' }) => (
    <Card className="glass-panel">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white flex items-center">
            <Users className="h-5 w-5 mr-2 text-basketball-orange-400" />
            {team.teamName}
          </CardTitle>
          <div className="flex items-center gap-4">
            <Badge className="bg-basketball-orange-500/20 text-basketball-orange-400 text-2xl px-4 py-2">
              {team.totalPoints}
            </Badge>
            <Badge className="bg-purple-500/20 text-purple-400">
              TO: {team.timeouts}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {team.players.map(player => (
            <div 
              key={player.id} 
              className={`p-3 rounded-lg transition-all ${
                player.isOnCourt ? 'bg-green-500/10 border border-green-500/30' : 'bg-gray-800/50'
              } ${selectedPlayer?.playerId === player.id ? 'ring-2 ring-basketball-orange-500' : ''}`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <Badge className="bg-gray-700 text-white min-w-[40px] text-center">
                    #{player.number}
                  </Badge>
                  <div>
                    <div className="font-semibold text-white">
                      {player.name}
                      {player.isStarter && <span className="ml-2 text-xs text-yellow-400">★</span>}
                    </div>
                    <div className="text-xs text-gray-400">
                      {player.isOnCourt ? 'On Court' : 'Bench'}
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => setSelectedPlayer({ team: side, playerId: player.id })}
                  className={`text-white ${selectedPlayer?.playerId === player.id ? 'bg-basketball-orange-500/20' : 'hover:bg-white/10'}`}
                >
                  {selectedPlayer?.playerId === player.id ? 'Selected' : 'Select'}
                </Button>
              </div>
              
              {selectedPlayer?.playerId === player.id && (
                <div className="mt-3 pt-3 border-t border-gray-700">
                  <QuickStatButtons team={side} playerId={player.id} />
                </div>
              )}
              
              {/* Stats Summary */}
              <div className="flex justify-between text-xs text-gray-400 mt-2 pt-2 border-t border-gray-800">
                <span>PTS: {player.points}</span>
                <span>REB: {player.rebounds}</span>
                <span>AST: {player.assists}</span>
                <span>FLS: {player.fouls}</span>
              </div>
            </div>
          ))}
        </div>
        
        {/* Team Totals */}
        <div className="mt-4 pt-4 border-t border-gray-700">
          <div className="grid grid-cols-4 gap-2 text-center">
            <div>
              <div className="text-xs text-gray-400">Points</div>
              <div className="text-lg font-bold text-white">{team.totalPoints}</div>
            </div>
            <div>
              <div className="text-xs text-gray-400">Rebounds</div>
              <div className="text-lg font-bold text-white">{team.totalRebounds}</div>
            </div>
            <div>
              <div className="text-xs text-gray-400">Assists</div>
              <div className="text-lg font-bold text-white">{team.totalAssists}</div>
            </div>
            <div>
              <div className="text-xs text-gray-400">Fouls</div>
              <div className="text-lg font-bold text-white">{team.totalFouls}</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      {/* Header */}
      <div className="glass-panel p-6 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              onClick={() => navigate('/dashboard')}
              variant="ghost"
              className="text-white hover:bg-white/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-display font-bold text-gradient">
                Stat Tracker - Scorebook View
              </h1>
              <p className="text-gray-400 mt-1">Enter stats for both teams on one screen</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            {/* Auto-save indicator */}
            <div className="flex items-center gap-2">
              <label className="flex items-center gap-2 text-sm text-gray-400">
                <input
                  type="checkbox"
                  checked={autoSaveEnabled}
                  onChange={(e) => setAutoSaveEnabled(e.target.checked)}
                  className="rounded border-gray-600"
                />
                Auto-save
              </label>
              {autoSaveEnabled && (
                <Badge className="bg-green-500/20 text-green-400 text-xs">
                  Every 30s
                </Badge>
              )}
            </div>
            
            {/* Save Status */}
            {saveStatus === 'saving' && (
              <div className="flex items-center gap-2 text-yellow-400">
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span className="text-sm">Saving...</span>
              </div>
            )}
            {saveStatus === 'saved' && (
              <div className="flex items-center gap-2 text-green-400">
                <Check className="h-4 w-4" />
                <span className="text-sm">Saved</span>
              </div>
            )}
            {saveStatus === 'error' && (
              <div className="flex items-center gap-2 text-red-400">
                <AlertCircle className="h-4 w-4" />
                <span className="text-sm">Save failed</span>
              </div>
            )}
            
            {/* Manual Save Button */}
            <Button
              onClick={handleSave}
              disabled={!unsavedChanges || saveStatus === 'saving'}
              className={`glass-button ${
                unsavedChanges 
                  ? 'bg-green-500/20 hover:bg-green-500/30 text-white' 
                  : 'bg-gray-700/20 text-gray-500'
              }`}
            >
              <Save className="h-4 w-4 mr-2" />
              Save
              {unsavedChanges && <span className="ml-1 text-xs">(unsaved)</span>}
            </Button>
          </div>
        </div>
      </div>

      {/* Game Info Bar */}
      <div className="glass-panel p-4 mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div>
              <span className="text-gray-400 text-sm">Quarter</span>
              <div className="text-2xl font-bold text-white">Q{gameData.quarter}</div>
            </div>
            <div>
              <span className="text-gray-400 text-sm">Time</span>
              <div className="text-2xl font-bold text-white">{gameData.timeRemaining}</div>
            </div>
            <Badge className={`
              ${gameData.gameStatus === 'not_started' ? 'bg-gray-500/20 text-gray-400' : ''}
              ${gameData.gameStatus === 'in_progress' ? 'bg-green-500/20 text-green-400' : ''}
              ${gameData.gameStatus === 'halftime' ? 'bg-yellow-500/20 text-yellow-400' : ''}
              ${gameData.gameStatus === 'finished' ? 'bg-red-500/20 text-red-400' : ''}
            `}>
              {gameData.gameStatus.replace('_', ' ').toUpperCase()}
            </Badge>
          </div>
          
          <div className="flex items-center gap-4">
            {gameData.lastSaved && (
              <div className="text-xs text-gray-400">
                Last saved: {gameData.lastSaved.toLocaleTimeString()}
              </div>
            )}
            <Button
              onClick={handleFinalizeGame}
              disabled={gameData.gameStatus === 'finished'}
              className="glass-button bg-red-500/20 hover:bg-red-500/30 text-white"
            >
              <Trophy className="h-4 w-4 mr-2" />
              Finalize Game
            </Button>
          </div>
        </div>
      </div>

      {/* Main Scoreboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <TeamScoreboard team={gameData.homeTeam} side="home" />
        <TeamScoreboard team={gameData.awayTeam} side="away" />
      </div>

      {/* Instructions */}
      <div className="glass-panel p-4 mt-6">
        <div className="flex items-start gap-2">
          <AlertCircle className="h-5 w-5 text-yellow-400 mt-0.5" />
          <div className="text-sm text-gray-400">
            <p className="font-semibold text-white mb-1">Quick Instructions:</p>
            <ul className="space-y-1">
              <li>• Click "Select" on any player to enter their stats</li>
              <li>• Use the + and - buttons to increment/decrement stats</li>
              <li>• Green border indicates players on court</li>
              <li>• Stats auto-save every 30 seconds when enabled</li>
              <li>• Click "Finalize Game" when complete to lock in final scores</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatTracker;