import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Calendar, MapPin, Trophy, TrendingUp } from 'lucide-react';
import { db } from '../firebase';
import { collection, query, orderBy, getDocs, onSnapshot } from 'firebase/firestore';

interface Game {
  id: string;
  home_team_id: string;
  away_team_id: string;
  home_score: number;
  away_score: number;
  game_date: string;
  venue: string;
  status: string;
  home_team?: { name: string; wins?: number; losses?: number };
  away_team?: { name: string };
}

interface Team {
  id: string;
  name: string;
  division: string;
  wins: number;
  losses: number;
}

const PublicSchedule: React.FC = () => {
  const [games, setGames] = useState<Game[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPublicData();
  }, []);

  const loadPublicData = async () => {
    setLoading(true);
    
    try {
      // Load games from Firestore (orderBy removed to prevent index errors)
      const gamesQuery = query(
        collection(db, 'games')
      );
      
      const gamesSnapshot = await getDocs(gamesQuery);
      const gamesData = gamesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      // Mock data for now - replace with real data when Firestore is populated
      const mockGames: Game[] = [
        {
          id: '1',
          home_team_id: 'team1',
          away_team_id: 'team2',
          home_team: { name: 'Lakers', wins: 8, losses: 2 },
          away_team: { name: 'Warriors' },
          game_date: new Date().toISOString(),
          location: 'Court A',
          home_score: 85,
          away_score: 78,
          status: 'completed'
        },
        {
          id: '2',
          home_team_id: 'team3',
          away_team_id: 'team4',
          home_team: { name: 'Celtics', wins: 7, losses: 3 },
          away_team: { name: 'Bulls' },
          game_date: new Date(Date.now() + 86400000).toISOString(),
          location: 'Court B',
          home_score: null,
          away_score: null,
          status: 'scheduled'
        }
      ];
      
      setGames(gamesData.length > 0 ? gamesData as Game[] : mockGames);

      // Load teams/standings (orderBy removed to prevent index errors)
      const teamsQuery = query(
        collection(db, 'teams')
      );
      
      const teamsSnapshot = await getDocs(teamsQuery);
      const teamsData = teamsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      
      // Mock data for standings
      const mockTeams: Team[] = [
        { id: 'team1', name: 'Lakers', wins: 8, losses: 2 },
        { id: 'team3', name: 'Celtics', wins: 7, losses: 3 },
        { id: 'team5', name: 'Heat', wins: 6, losses: 4 },
        { id: 'team2', name: 'Warriors', wins: 5, losses: 5 },
        { id: 'team4', name: 'Bulls', wins: 3, losses: 7 }
      ];
      
      setTeams(teamsData.length > 0 ? teamsData as Team[] : mockTeams);
    } catch (error) {
      console.error('Error loading public data:', error);
    }
    
    setLoading(false);
  };

  const getWinPercentage = (wins: number, losses: number) => {
    const total = wins + losses;
    if (total === 0) return '0';
    return ((wins / total) * 100).toFixed(0);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'live':
      case 'in_progress':
        return <Badge variant="game-live" className="animate-pulse">LIVE</Badge>;
      case 'completed':
        return <Badge variant="secondary">FINAL</Badge>;
      default:
        return <Badge variant="outline">UPCOMING</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-basketball-orange-500 to-basketball-orange-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-5xl font-bold mb-2">GameTriq League</h1>
            <p className="text-xl text-basketball-orange-100">Indoor Basketball League Management</p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading league data...</p>
          </div>
        ) : (
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Game Schedule */}
            <div>
              <Card className="shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center text-2xl">
                    <Calendar className="h-6 w-6 mr-2 text-basketball-orange-500" />
                    Game Schedule
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4 max-h-[600px] overflow-y-auto">
                    {games.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">No games scheduled</p>
                    ) : (
                      games.map(game => (
                        <div key={game.id} className="border-b pb-4 last:border-0">
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-semibold text-lg">
                                  {game.home_team?.name || 'TBD'}
                                </span>
                                {(game.status === 'completed' || game.status === 'in_progress') && (
                                  <span className="text-2xl font-bold text-basketball-orange-500">
                                    {game.home_score}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="font-semibold text-lg">
                                  {game.away_team?.name || 'TBD'}
                                </span>
                                {(game.status === 'completed' || game.status === 'in_progress') && (
                                  <span className="text-2xl font-bold text-basketball-orange-500">
                                    {game.away_score}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="ml-4">
                              {getStatusBadge(game.status)}
                            </div>
                          </div>
                          <div className="flex items-center text-sm text-gray-600 space-x-4">
                            <div className="flex items-center">
                              <Calendar className="h-3 w-3 mr-1" />
                              {new Date(game.game_date).toLocaleDateString()}
                            </div>
                            <div className="flex items-center">
                              <MapPin className="h-3 w-3 mr-1" />
                              {game.venue || 'Indoor Court 1'}
                            </div>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Standings */}
            <div>
              <Card className="shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center text-2xl">
                    <Trophy className="h-6 w-6 mr-2 text-basketball-orange-500" />
                    League Standings
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b-2">
                          <th className="text-left pb-3">Rank</th>
                          <th className="text-left pb-3">Team</th>
                          <th className="text-center pb-3">W</th>
                          <th className="text-center pb-3">L</th>
                          <th className="text-center pb-3">PCT</th>
                        </tr>
                      </thead>
                      <tbody>
                        {teams.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="text-center py-8 text-gray-500">
                              No teams registered
                            </td>
                          </tr>
                        ) : (
                          teams.map((team, index) => (
                            <tr key={team.id} className="border-b hover:bg-gray-50">
                              <td className="py-3">
                                <span className="font-bold text-gray-600">
                                  {index + 1}
                                </span>
                              </td>
                              <td className="py-3">
                                <div>
                                  <span className="font-semibold">{team.name}</span>
                                  <span className="ml-2 text-xs text-gray-500">
                                    Div {team.division}
                                  </span>
                                </div>
                              </td>
                              <td className="text-center py-3 font-semibold text-green-600">
                                {team.wins || 0}
                              </td>
                              <td className="text-center py-3 font-semibold text-red-600">
                                {team.losses || 0}
                              </td>
                              <td className="text-center py-3">
                                <Badge variant="outline">
                                  {getWinPercentage(team.wins || 0, team.losses || 0)}%
                                </Badge>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <Card className="mt-6 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-basketball-orange-500" />
                    League Stats
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-gray-50 rounded">
                      <p className="text-3xl font-bold text-basketball-orange-500">
                        {teams.length}
                      </p>
                      <p className="text-sm text-gray-600">Active Teams</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded">
                      <p className="text-3xl font-bold text-basketball-orange-500">
                        {games.filter(g => g.status === 'completed').length}
                      </p>
                      <p className="text-sm text-gray-600">Games Played</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded">
                      <p className="text-3xl font-bold text-basketball-orange-500">
                        {games.filter(g => g.status === 'scheduled').length}
                      </p>
                      <p className="text-sm text-gray-600">Upcoming Games</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 rounded">
                      <p className="text-3xl font-bold text-basketball-orange-500">
                        Indoor
                      </p>
                      <p className="text-sm text-gray-600">All Games</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-12 py-6 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-sm">© 2024 GameTriq League Management System</p>
          <p className="text-xs mt-1 text-gray-400">Indoor Basketball League Platform</p>
        </div>
      </footer>
    </div>
  );
};

export default PublicSchedule;