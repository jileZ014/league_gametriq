import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Activity, Clock, MapPin, Plus, Minus } from 'lucide-react';
import { db } from '../firebase';
import { doc, getDoc, updateDoc, onSnapshot, collection, getDocs, query, orderBy, limit } from 'firebase/firestore';

interface Game {
  id: string;
  homeTeam: string;
  awayTeam: string;
  homeScore: number;
  awayScore: number;
  date: string;
  time: string;
  location: string;
  status: 'scheduled' | 'in_progress' | 'completed';
  period?: number;
  timeRemaining?: string;
}

const LiveScoring: React.FC = () => {
  const { gameId } = useParams();
  const navigate = useNavigate();
  const [game, setGame] = useState<Game | null>(null);
  const [loading, setLoading] = useState(true);
  const [quarter, setQuarter] = useState(1);
  const [timeRemaining, setTimeRemaining] = useState('12:00');
  const [isClockRunning, setIsClockRunning] = useState(false);

  useEffect(() => {
    if (gameId) {
      loadGame();
      subscribeToGameUpdates();
    } else {
      // Load first available game or show demo
      loadDemoGame();
    }
  }, [gameId]);

  const loadDemoGame = async () => {
    // Try to load a real game first
    try {
      // orderBy removed to prevent index errors
      const gamesQuery = query(collection(db, 'games'), limit(1));
      const snapshot = await getDocs(gamesQuery);
      
      if (!snapshot.empty) {
        const gameDoc = snapshot.docs[0];
        setGame({
          id: gameDoc.id,
          ...gameDoc.data()
        } as Game);
      } else {
        // Show demo game
        setGame({
          id: 'demo',
          homeTeam: 'Phoenix Thunder',
          awayTeam: 'Mesa Lightning',
          homeScore: 45,
          awayScore: 42,
          date: new Date().toISOString().split('T')[0],
          time: '7:00 PM',
          location: 'Legacy Sports Complex',
          status: 'in_progress',
          period: 2,
          timeRemaining: '5:24'
        });
      }
    } catch (error) {
      console.error('Error loading games:', error);
      // Show demo game on error
      setGame({
        id: 'demo',
        homeTeam: 'Phoenix Thunder',
        awayTeam: 'Mesa Lightning',
        homeScore: 45,
        awayScore: 42,
        date: new Date().toISOString().split('T')[0],
        time: '7:00 PM',
        location: 'Legacy Sports Complex',
        status: 'in_progress',
        period: 2,
        timeRemaining: '5:24'
      });
    }
    setLoading(false);
  };

  const loadGame = async () => {
    if (!gameId) return;
    
    setLoading(true);
    try {
      const gameDoc = await getDoc(doc(db, 'games', gameId));
      
      if (gameDoc.exists()) {
        const gameData = gameDoc.data() as Game;
        setGame({
          id: gameDoc.id,
          ...gameData
        });
        setQuarter(gameData.period || 1);
        setTimeRemaining(gameData.timeRemaining || '12:00');
      } else {
        console.error('Game not found');
        loadDemoGame();
      }
    } catch (error) {
      console.error('Error loading game:', error);
      loadDemoGame();
    }
    setLoading(false);
  };

  const subscribeToGameUpdates = () => {
    if (!gameId || gameId === 'demo') return;
    
    const unsubscribe = onSnapshot(doc(db, 'games', gameId), (doc) => {
      if (doc.exists()) {
        const gameData = doc.data() as Game;
        setGame({
          id: doc.id,
          ...gameData
        });
        setQuarter(gameData.period || 1);
        setTimeRemaining(gameData.timeRemaining || '12:00');
      }
    });

    return unsubscribe;
  };

  const updateScore = async (team: 'home' | 'away', delta: number) => {
    if (!game || game.id === 'demo') {
      // For demo, just update local state
      if (team === 'home') {
        setGame(prev => prev ? {...prev, homeScore: Math.max(0, prev.homeScore + delta)} : prev);
      } else {
        setGame(prev => prev ? {...prev, awayScore: Math.max(0, prev.awayScore + delta)} : prev);
      }
      return;
    }
    
    try {
      const newScore = team === 'home' 
        ? Math.max(0, game.homeScore + delta)
        : Math.max(0, game.awayScore + delta);
      
      await updateDoc(doc(db, 'games', game.id), {
        [team === 'home' ? 'homeScore' : 'awayScore']: newScore,
        status: 'in_progress',
        period: quarter,
        timeRemaining
      });
    } catch (error) {
      console.error('Error updating score:', error);
    }
  };

  const updateQuarter = async (newQuarter: number) => {
    if (!game || game.id === 'demo') {
      setQuarter(newQuarter);
      return;
    }
    
    try {
      await updateDoc(doc(db, 'games', game.id), {
        period: newQuarter,
        timeRemaining: '12:00'
      });
      setQuarter(newQuarter);
      setTimeRemaining('12:00');
    } catch (error) {
      console.error('Error updating quarter:', error);
    }
  };

  const endGame = async () => {
    if (!game || game.id === 'demo') {
      setGame(prev => prev ? {...prev, status: 'completed'} : prev);
      return;
    }
    
    try {
      await updateDoc(doc(db, 'games', game.id), {
        status: 'completed',
        period: 4,
        timeRemaining: '0:00'
      });
    } catch (error) {
      console.error('Error ending game:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <Card variant="navy">
          <CardContent className="p-8">
            <p className="text-red-400">Game not found</p>
            <Button onClick={() => navigate('/dashboard')} variant="primary" className="mt-4">
              Back to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-950">
      <header className="bg-gradient-navy border-b border-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-navy-800"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-2xl font-display font-bold text-white">Live Scoring</h1>
                <p className="text-gray-400">{game.location}</p>
              </div>
            </div>
            <Badge variant={game.status === 'in_progress' ? 'game-live' : 'secondary'}>
              {game.status === 'in_progress' ? 'LIVE' : game.status.toUpperCase()}
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Score Display */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          {/* Home Team */}
          <Card variant="navy">
            <CardHeader>
              <CardTitle className="text-center text-white">{game.homeTeam}</CardTitle>
              <p className="text-center text-gray-400">HOME</p>
            </CardHeader>
            <CardContent>
              <div className="text-5xl font-bold text-center text-white mb-4">
                {game.homeScore}
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => updateScore('home', -1)}
                  variant="destructive"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <Button
                  onClick={() => updateScore('home', 1)}
                  variant="primary"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Plus className="h-4 w-4 mr-1" /> 1
                </Button>
                <Button
                  onClick={() => updateScore('home', 2)}
                  variant="primary"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Plus className="h-4 w-4 mr-1" /> 2
                </Button>
                <Button
                  onClick={() => updateScore('home', 3)}
                  variant="primary"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Plus className="h-4 w-4 mr-1" /> 3
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Game Info */}
          <Card variant="navy">
            <CardHeader>
              <CardTitle className="text-center text-white">Game Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <p className="text-gray-400">Quarter</p>
                <p className="text-3xl font-bold text-white">Q{quarter}</p>
              </div>
              <div className="text-center mb-4">
                <p className="text-gray-400">Time</p>
                <p className="text-2xl font-bold text-white">{timeRemaining}</p>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => setIsClockRunning(!isClockRunning)}
                  variant={isClockRunning ? "destructive" : "primary"}
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  {isClockRunning ? 'Pause' : 'Start'}
                </Button>
                <Button
                  onClick={() => updateQuarter(Math.min(4, quarter + 1))}
                  variant="secondary"
                  className="flex-1"
                  disabled={game.status === 'completed' || quarter >= 4}
                >
                  Next Q
                </Button>
              </div>
              {quarter >= 4 && game.status === 'in_progress' && (
                <Button
                  onClick={endGame}
                  variant="primary"
                  className="w-full mt-2"
                >
                  End Game
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Away Team */}
          <Card variant="navy">
            <CardHeader>
              <CardTitle className="text-center text-white">{game.awayTeam}</CardTitle>
              <p className="text-center text-gray-400">AWAY</p>
            </CardHeader>
            <CardContent>
              <div className="text-5xl font-bold text-center text-white mb-4">
                {game.awayScore}
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={() => updateScore('away', -1)}
                  variant="destructive"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <Button
                  onClick={() => updateScore('away', 1)}
                  variant="primary"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Plus className="h-4 w-4 mr-1" /> 1
                </Button>
                <Button
                  onClick={() => updateScore('away', 2)}
                  variant="primary"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Plus className="h-4 w-4 mr-1" /> 2
                </Button>
                <Button
                  onClick={() => updateScore('away', 3)}
                  variant="primary"
                  className="flex-1"
                  disabled={game.status === 'completed'}
                >
                  <Plus className="h-4 w-4 mr-1" /> 3
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Game Summary */}
        {game.status === 'completed' && (
          <Card variant="navy">
            <CardHeader>
              <CardTitle className="text-center text-white">Game Complete</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center">
                <p className="text-2xl font-bold text-white mb-2">
                  Final Score: {game.homeTeam} {game.homeScore} - {game.awayScore} {game.awayTeam}
                </p>
                <p className="text-lg text-basketball-orange-500">
                  {game.homeScore > game.awayScore ? game.homeTeam : game.awayTeam} Wins!
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
};

export default LiveScoring;