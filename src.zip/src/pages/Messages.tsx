import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, MessageSquare, Send, Users, User } from 'lucide-react';
import { useAuth } from '../AuthContext';
import { db } from '../firebase';
import { collection, addDoc, query, orderBy, limit, onSnapshot, where, getDocs } from 'firebase/firestore';

interface Message {
  id: string;
  sender_id: string;
  sender_name: string;
  recipient_id?: string;
  team_id?: string;
  message: string;
  created_at: string;
  chat_type: 'direct' | 'team' | 'group';
}

const Messages: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [selectedChat, setSelectedChat] = useState(0);
  const [newMessage, setNewMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(false);

  const chats = [
    { id: '0', name: 'Team Chat', type: 'team' as const, unread: 0, lastMessage: 'Loading...' },
    { id: '1', name: 'Coach Thompson', type: 'direct' as const, unread: 0, lastMessage: 'Loading...' },
    { id: '2', name: 'Parents Group', type: 'group' as const, unread: 0, lastMessage: 'Loading...' },
  ];

  useEffect(() => {
    if (currentUser) {
      loadMessages();
    }
  }, [selectedChat, currentUser]);

  useEffect(() => {
    if (!currentUser) return;
    
    const unsubscribe = subscribeToMessages(
      chats[selectedChat].type,
      chats[selectedChat].id,
      (newMsg) => {
        setMessages(prev => [...prev, newMsg]);
      }
    );

    return unsubscribe;
  }, [selectedChat, currentUser]);

  const loadMessages = async () => {
    setLoading(true);
    const data = await getMessages(chats[selectedChat].type, chats[selectedChat].id);
    setMessages(data);
    setLoading(false);
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !currentUser) return;

    await sendMessage(
      currentUser.uid,
      currentUser.displayName || 'User',
      newMessage,
      chats[selectedChat].type,
      chats[selectedChat].type === 'direct' ? chats[selectedChat].id : undefined,
      chats[selectedChat].type === 'team' ? 'a1111111-1111-1111-1111-111111111111' : undefined
    );

    setNewMessage('');
    await loadMessages();
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900">
      <header className="bg-gradient-to-r from-basketball-orange-500 to-basketball-orange-600 text-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-white/20"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Button>
              <div>
                <h1 className="text-2xl font-bold">Team Messages</h1>
                <p className="text-basketball-orange-100">Stay connected with your team</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Conversations</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {chats.map((chat) => (
                  <div
                    key={chat.id}
                    onClick={() => setSelectedChat(chat.id)}
                    className={`p-4 border-b cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800 ${
                      selectedChat === chat.id ? 'bg-basketball-orange-50 dark:bg-basketball-orange-900/20' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center space-x-2">
                        {chat.type === 'group' ? (
                          <Users className="h-5 w-5 text-gray-500" />
                        ) : (
                          <User className="h-5 w-5 text-gray-500" />
                        )}
                        <span className="font-semibold">{chat.name}</span>
                      </div>
                      {chat.unread > 0 && (
                        <Badge className="bg-basketball-orange-500">{chat.unread}</Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="h-[600px] flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  {chats[selectedChat].name}
                </CardTitle>
              </CardHeader>
              <CardContent className="flex-1 overflow-y-auto">
                {loading ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Loading messages...</p>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-500">No messages yet. Start the conversation!</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((msg) => {
                      const isYou = msg.sender_id === currentUser?.uid;
                      return (
                        <div key={msg.id} className={`flex ${isYou ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-xs lg:max-w-md ${
                            isYou
                              ? 'bg-basketball-orange-500 text-white' 
                              : 'bg-gray-200 dark:bg-gray-700'
                          } rounded-lg p-3`}>
                            <div className="flex items-center justify-between mb-1">
                              <span className="font-semibold text-sm">{msg.sender_name}</span>
                              <span className="text-xs opacity-75">
                                {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                            <p>{msg.message}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
              <div className="p-4 border-t">
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type a message..."
                    className="flex-1 p-2 border rounded-lg"
                  />
                  <Button 
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    className="bg-basketball-orange-500 hover:bg-basketball-orange-600"
                  >
                    <Send className="h-5 w-5" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Messages;