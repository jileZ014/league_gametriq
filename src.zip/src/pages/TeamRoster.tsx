import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, Users, UserPlus, Edit, Trash2 } from 'lucide-react';
import { db } from '../firebase';
import { collection, query, getDocs, addDoc, deleteDoc, doc, where, orderBy } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

interface Player {
  id: string;
  name: string;
  jersey: number;
  position: string;
  height?: string;
  grade?: string;
  teamId: string;
}

const TeamRoster: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [players, setPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(false);
  const [teamId, setTeamId] = useState<string | null>(null);
  const [teamName, setTeamName] = useState('Phoenix Suns');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPlayer, setNewPlayer] = useState({ 
    name: '', 
    jersey: '', 
    position: '', 
    height: '', 
    grade: '' 
  });

  useEffect(() => {
    loadTeamAndPlayers();
  }, [currentUser]);

  const getDemoPlayers = (): Player[] => {
    return [
      { id: '1', name: 'Michael Johnson', jersey: 23, position: 'Guard', height: "6'2\"", grade: '12th', teamId: 'demo' },
      { id: '2', name: 'David Chen', jersey: 10, position: 'Forward', height: "6'5\"", grade: '11th', teamId: 'demo' },
      { id: '3', name: 'Marcus Williams', jersey: 5, position: 'Center', height: "6'8\"", grade: '12th', teamId: 'demo' },
      { id: '4', name: 'James Rodriguez', jersey: 15, position: 'Guard', height: "5'11\"", grade: '10th', teamId: 'demo' },
      { id: '5', name: 'Tyler Anderson', jersey: 22, position: 'Forward', height: "6'4\"", grade: '11th', teamId: 'demo' },
    ];
  };

  const loadTeamAndPlayers = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      // Load teams from Firestore (orderBy removed to prevent index errors)
      const teamsQuery = query(collection(db, 'teams'));
      const teamsSnapshot = await getDocs(teamsQuery);
      
      if (!teamsSnapshot.empty) {
        const firstTeam = teamsSnapshot.docs[0];
        const teamData = firstTeam.data();
        setTeamId(firstTeam.id);
        setTeamName(teamData.name || 'Phoenix Suns');
        
        // Load players for this team (orderBy removed to prevent index errors)
        const playersQuery = query(
          collection(db, 'players'),
          where('teamId', '==', firstTeam.id)
        );
        const playersSnapshot = await getDocs(playersQuery);
        
        const playersData = playersSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        } as Player));
        
        setPlayers(playersData.length > 0 ? playersData : getDemoPlayers());
      } else {
        // No teams found, show demo data
        setPlayers(getDemoPlayers());
      }
    } catch (error) {
      console.error('Error loading team data:', error);
      // Show demo data on error
      setPlayers(getDemoPlayers());
    }
    setLoading(false);
  };

  const handleAddPlayer = async () => {
    if (!newPlayer.name || !teamId) return;
    
    setLoading(true);
    try {
      const playerData = {
        name: newPlayer.name,
        jersey: newPlayer.jersey ? parseInt(newPlayer.jersey) : 0,
        position: newPlayer.position || 'Player',
        height: newPlayer.height || '',
        grade: newPlayer.grade || '',
        teamId: teamId,
        createdAt: new Date().toISOString(),
        createdBy: currentUser?.uid
      };
      
      const docRef = await addDoc(collection(db, 'players'), playerData);
      
      // Reload players
      await loadTeamAndPlayers();
      
      // Reset form
      setNewPlayer({ name: '', jersey: '', position: '', height: '', grade: '' });
      setShowAddForm(false);
    } catch (error) {
      console.error('Error adding player:', error);
    }
    setLoading(false);
  };

  const handleDeletePlayer = async (playerId: string) => {
    if (window.confirm('Are you sure you want to remove this player?')) {
      setLoading(true);
      try {
        await deleteDoc(doc(db, 'players', playerId));
        await loadTeamAndPlayers();
      } catch (error) {
        console.error('Error deleting player:', error);
      }
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-navy-950">
      <header className="bg-gradient-navy border-b border-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-navy-800"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Button>
              <div>
                <h1 className="text-2xl font-display font-bold text-white">Team Roster</h1>
                <p className="text-gray-400">{teamName} - 2024 Season</p>
              </div>
            </div>
            {currentUser?.role === 'coach' && (
              <Button 
                onClick={() => setShowAddForm(true)}
                variant="primary"
              >
                <UserPlus className="h-5 w-5 mr-2" />
                Add Player
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showAddForm && (
          <Card variant="navy" className="mb-6">
            <CardHeader>
              <CardTitle className="text-white">Add New Player</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input
                  type="text"
                  placeholder="Player Name *"
                  value={newPlayer.name}
                  onChange={(e) => setNewPlayer({...newPlayer, name: e.target.value})}
                  className="p-2 rounded bg-navy-800 border border-navy-700 text-white placeholder-gray-400"
                  required
                />
                <input
                  type="number"
                  placeholder="Jersey Number"
                  value={newPlayer.jersey}
                  onChange={(e) => setNewPlayer({...newPlayer, jersey: e.target.value})}
                  className="p-2 rounded bg-navy-800 border border-navy-700 text-white placeholder-gray-400"
                />
                <select
                  value={newPlayer.position}
                  onChange={(e) => setNewPlayer({...newPlayer, position: e.target.value})}
                  className="p-2 rounded bg-navy-800 border border-navy-700 text-white"
                >
                  <option value="">Select Position</option>
                  <option value="Guard">Guard</option>
                  <option value="Forward">Forward</option>
                  <option value="Center">Center</option>
                </select>
                <input
                  type="text"
                  placeholder="Height (e.g., 6'2)"
                  value={newPlayer.height}
                  onChange={(e) => setNewPlayer({...newPlayer, height: e.target.value})}
                  className="p-2 rounded bg-navy-800 border border-navy-700 text-white placeholder-gray-400"
                />
                <input
                  type="text"
                  placeholder="Grade"
                  value={newPlayer.grade}
                  onChange={(e) => setNewPlayer({...newPlayer, grade: e.target.value})}
                  className="p-2 rounded bg-navy-800 border border-navy-700 text-white placeholder-gray-400"
                />
              </div>
              <div className="flex gap-2 mt-4">
                <Button onClick={handleAddPlayer} variant="primary" disabled={loading}>
                  {loading ? 'Adding...' : 'Add Player'}
                </Button>
                <Button onClick={() => setShowAddForm(false)} variant="outline">
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading && players.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500 mx-auto"></div>
              <p className="text-gray-400 mt-4">Loading players...</p>
            </div>
          ) : players.length === 0 ? (
            <div className="col-span-full text-center py-12">
              <Users className="h-16 w-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">No players on the roster yet.</p>
              {currentUser?.role === 'coach' && (
                <Button onClick={() => setShowAddForm(true)} variant="primary" className="mt-4">
                  Add First Player
                </Button>
              )}
            </div>
          ) : (
            players.map((player) => (
              <Card key={player.id} variant="navy">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gradient-orange rounded-full flex items-center justify-center">
                        <span className="text-2xl font-bold text-white">
                          {player.jersey || '#'}
                        </span>
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold text-white">{player.name}</h3>
                        <Badge variant="secondary">{player.position || 'Player'}</Badge>
                      </div>
                    </div>
                    {currentUser?.role === 'coach' && !player.id.startsWith('demo') && (
                      <Button
                        onClick={() => handleDeletePlayer(player.id)}
                        variant="ghost"
                        size="sm"
                        className="text-red-400 hover:bg-red-900/20"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    {player.height && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Height:</span>
                        <span className="text-white">{player.height}</span>
                      </div>
                    )}
                    {player.grade && (
                      <div className="flex justify-between">
                        <span className="text-gray-400">Grade:</span>
                        <span className="text-white">{player.grade}</span>
                      </div>
                    )}
                    <div className="flex justify-between">
                      <span className="text-gray-400">PPG:</span>
                      <span className="text-white">{Math.floor(Math.random() * 20 + 5)}.{Math.floor(Math.random() * 10)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">RPG:</span>
                      <span className="text-white">{Math.floor(Math.random() * 10 + 2)}.{Math.floor(Math.random() * 10)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">APG:</span>
                      <span className="text-white">{Math.floor(Math.random() * 8 + 1)}.{Math.floor(Math.random() * 10)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
};

export default TeamRoster;