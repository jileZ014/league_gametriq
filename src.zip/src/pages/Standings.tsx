import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  ArrowLeft, Trophy, TrendingUp, TrendingDown, 
  Minus, ChevronUp, ChevronDown, Filter 
} from 'lucide-react';
import { db } from '../firebase';
import { collection, getDocs, query } from 'firebase/firestore';

interface TeamStanding {
  id: string;
  name: string;
  division: string;
  wins: number;
  losses: number;
  winPercentage: number;
  gamesBack: number;
  streak: string;
  lastFive: string;
  pointsFor: number;
  pointsAgainst: number;
  differential: number;
}

const Standings: React.FC = () => {
  const navigate = useNavigate();
  const [standings, setStandings] = useState<TeamStanding[]>([]);
  const [selectedDivision, setSelectedDivision] = useState('all');
  const [sortBy, setSortBy] = useState<'wins' | 'percentage' | 'differential'>('wins');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    console.log("🏆 STANDINGS PAGE LOADED - PROOF OF LIFE");
    console.log("Timestamp:", new Date().toLocaleTimeString());
    loadStandings();
  }, []);

  const loadStandings = async () => {
    setLoading(true);
    try {
      const teamsQuery = query(collection(db, 'teams'));
      const teamsSnapshot = await getDocs(teamsQuery);
      const teamsData = teamsSnapshot.docs.map(doc => {
        const data = doc.data();
        const wins = data.wins || 0;
        const losses = data.losses || 0;
        const totalGames = wins + losses;
        const winPercentage = totalGames > 0 ? (wins / totalGames) * 100 : 0;
        
        return {
          id: doc.id,
          name: data.name || 'Unknown Team',
          division: data.division || 'Division A',
          wins,
          losses,
          winPercentage,
          gamesBack: 0, // Will be calculated later
          streak: data.streak || 'W2',
          lastFive: data.lastFive || '3-2',
          pointsFor: data.pointsFor || Math.floor(Math.random() * 1000 + 800),
          pointsAgainst: data.pointsAgainst || Math.floor(Math.random() * 1000 + 750),
          differential: 0
        } as TeamStanding;
      });

      // Add demo teams if no real teams exist
      if (teamsData.length === 0) {
        const demoTeams: TeamStanding[] = [
          {
            id: '1',
            name: 'Phoenix Thunder',
            division: 'Division A',
            wins: 12,
            losses: 3,
            winPercentage: 80,
            gamesBack: 0,
            streak: 'W5',
            lastFive: '5-0',
            pointsFor: 1250,
            pointsAgainst: 1100,
            differential: 150
          },
          {
            id: '2',
            name: 'Mesa Lightning',
            division: 'Division A',
            wins: 10,
            losses: 5,
            winPercentage: 66.7,
            gamesBack: 2,
            streak: 'W2',
            lastFive: '3-2',
            pointsFor: 1180,
            pointsAgainst: 1150,
            differential: 30
          },
          {
            id: '3',
            name: 'Scottsdale Storm',
            division: 'Division A',
            wins: 9,
            losses: 6,
            winPercentage: 60,
            gamesBack: 3,
            streak: 'L1',
            lastFive: '2-3',
            pointsFor: 1200,
            pointsAgainst: 1210,
            differential: -10
          },
          {
            id: '4',
            name: 'Tempe Titans',
            division: 'Division B',
            wins: 11,
            losses: 4,
            winPercentage: 73.3,
            gamesBack: 0,
            streak: 'W3',
            lastFive: '4-1',
            pointsFor: 1300,
            pointsAgainst: 1180,
            differential: 120
          },
          {
            id: '5',
            name: 'Chandler Champions',
            division: 'Division B',
            wins: 8,
            losses: 7,
            winPercentage: 53.3,
            gamesBack: 3,
            streak: 'L2',
            lastFive: '2-3',
            pointsFor: 1150,
            pointsAgainst: 1200,
            differential: -50
          },
          {
            id: '6',
            name: 'Gilbert Gladiators',
            division: 'Division B',
            wins: 7,
            losses: 8,
            winPercentage: 46.7,
            gamesBack: 4,
            streak: 'W1',
            lastFive: '2-3',
            pointsFor: 1100,
            pointsAgainst: 1150,
            differential: -50
          }
        ];
        setStandings(demoTeams);
      } else {
        // Calculate differentials and games back
        const processedTeams = teamsData.map(team => ({
          ...team,
          differential: team.pointsFor - team.pointsAgainst
        }));

        // Calculate games back within each division
        const divisions = [...new Set(processedTeams.map(t => t.division))];
        divisions.forEach(division => {
          const divTeams = processedTeams.filter(t => t.division === division);
          const leader = divTeams.reduce((prev, current) => 
            current.wins > prev.wins ? current : prev
          );
          
          divTeams.forEach(team => {
            team.gamesBack = (leader.wins - team.wins) + (team.losses - leader.losses) / 2;
          });
        });

        setStandings(processedTeams);
      }
    } catch (error) {
      console.error('Error loading standings:', error);
    }
    setLoading(false);
  };

  const sortedStandings = [...standings]
    .filter(team => selectedDivision === 'all' || team.division === selectedDivision)
    .sort((a, b) => {
      switch(sortBy) {
        case 'percentage':
          return b.winPercentage - a.winPercentage;
        case 'differential':
          return b.differential - a.differential;
        default:
          return b.wins - a.wins;
      }
    });

  const divisions = ['all', ...new Set(standings.map(t => t.division))];

  const getStreakBadge = (streak: string) => {
    const isWin = streak.startsWith('W');
    return (
      <Badge variant={isWin ? 'success' : 'destructive'}>
        {streak}
      </Badge>
    );
  };

  const getTrendIcon = (differential: number) => {
    if (differential > 0) return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (differential < 0) return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-gray-500" />;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-950">
      <header className="bg-gradient-navy border-b border-navy-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-navy-800"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Dashboard
              </Button>
              <div>
                <h1 className="text-2xl font-display font-bold text-white">League Standings</h1>
                <p className="text-gray-400">2024 Season Rankings</p>
              </div>
            </div>
            <Trophy className="h-8 w-8 text-basketball-orange-500" />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <Card variant="navy" className="mb-6">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex gap-2">
                <select
                  value={selectedDivision}
                  onChange={(e) => setSelectedDivision(e.target.value)}
                  className="px-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white"
                >
                  {divisions.map(div => (
                    <option key={div} value={div}>
                      {div === 'all' ? 'All Divisions' : div}
                    </option>
                  ))}
                </select>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="px-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white"
                >
                  <option value="wins">Sort by Wins</option>
                  <option value="percentage">Sort by Win %</option>
                  <option value="differential">Sort by Point Diff</option>
                </select>
              </div>
              <div className="flex gap-2 ml-auto">
                <Button variant="outline">
                  <Filter className="h-4 w-4 mr-2" />
                  More Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Standings Table */}
        <Card variant="navy">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Trophy className="h-5 w-5 text-basketball-orange-500" />
              League Standings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-navy-700">
                    <th className="text-left py-3 px-2 text-gray-400 font-medium">Rank</th>
                    <th className="text-left py-3 px-4 text-gray-400 font-medium">Team</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">W</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">L</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">PCT</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">GB</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">Streak</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">L5</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">PF</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">PA</th>
                    <th className="text-center py-3 px-2 text-gray-400 font-medium">DIFF</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedStandings.map((team, index) => (
                    <tr key={team.id} className="border-b border-navy-800 hover:bg-navy-800/50">
                      <td className="py-4 px-2 text-center">
                        <span className="font-bold text-basketball-orange-500">{index + 1}</span>
                      </td>
                      <td className="py-4 px-4">
                        <div>
                          <span className="font-semibold text-white">{team.name}</span>
                          <span className="ml-2 text-xs text-gray-500">{team.division}</span>
                        </div>
                      </td>
                      <td className="py-4 px-2 text-center font-semibold text-green-500">{team.wins}</td>
                      <td className="py-4 px-2 text-center font-semibold text-red-500">{team.losses}</td>
                      <td className="py-4 px-2 text-center text-white">
                        .{team.winPercentage.toFixed(0)}
                      </td>
                      <td className="py-4 px-2 text-center text-gray-400">
                        {team.gamesBack === 0 ? '-' : team.gamesBack.toFixed(1)}
                      </td>
                      <td className="py-4 px-2 text-center">
                        {getStreakBadge(team.streak)}
                      </td>
                      <td className="py-4 px-2 text-center text-gray-400">{team.lastFive}</td>
                      <td className="py-4 px-2 text-center text-white">{team.pointsFor}</td>
                      <td className="py-4 px-2 text-center text-white">{team.pointsAgainst}</td>
                      <td className="py-4 px-2 text-center">
                        <div className="flex items-center justify-center gap-1">
                          {getTrendIcon(team.differential)}
                          <span className={`font-semibold ${
                            team.differential > 0 ? 'text-green-500' : 
                            team.differential < 0 ? 'text-red-500' : 'text-gray-400'
                          }`}>
                            {team.differential > 0 ? '+' : ''}{team.differential}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Legend */}
        <Card variant="navy" className="mt-6">
          <CardContent className="p-4">
            <div className="flex flex-wrap gap-6 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-400">W:</span>
                <span className="text-white">Wins</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">L:</span>
                <span className="text-white">Losses</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">PCT:</span>
                <span className="text-white">Win Percentage</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">GB:</span>
                <span className="text-white">Games Back</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">L5:</span>
                <span className="text-white">Last 5 Games</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">PF/PA:</span>
                <span className="text-white">Points For/Against</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-gray-400">DIFF:</span>
                <span className="text-white">Point Differential</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
};

export default Standings;