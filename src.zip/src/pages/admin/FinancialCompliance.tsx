import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  DollarSign, FileCheck, AlertTriangle, CheckCircle,
  Download, TrendingUp, TrendingDown, Calendar,
  User, Shield, Clock, Mail, Phone, Search
} from 'lucide-react';
import { databaseService } from '../../services/DatabaseService';
import { where, orderBy } from 'firebase/firestore';

interface Payment {
  id: string;
  playerId: string;
  playerName: string;
  teamId: string;
  teamName: string;
  amount: number;
  type: 'registration' | 'uniform' | 'tournament' | 'other';
  status: 'paid' | 'pending' | 'overdue' | 'refunded';
  dueDate: string;
  paidDate?: string;
  method?: 'cash' | 'check' | 'card' | 'online';
  receiptNumber?: string;
}

interface Compliance {
  id: string;
  playerId: string;
  playerName: string;
  teamId: string;
  teamName: string;
  medicalClearance: boolean;
  medicalExpiry?: string;
  waiverSigned: boolean;
  waiverDate?: string;
  backgroundCheck?: boolean;
  backgroundCheckDate?: string;
  insuranceVerified: boolean;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
}

interface FinancialSummary {
  totalRevenue: number;
  totalPending: number;
  totalOverdue: number;
  collectionRate: number;
  monthlyRevenue: { month: string; amount: number }[];
}

export const FinancialCompliance: React.FC = () => {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [compliance, setCompliance] = useState<Compliance[]>([]);
  const [summary, setSummary] = useState<FinancialSummary | null>(null);
  const [activeTab, setActiveTab] = useState<'financial' | 'compliance'>('financial');
  const [filter, setFilter] = useState<'all' | 'pending' | 'overdue'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [paymentsData, complianceData] = await Promise.all([
        databaseService.getCollection<Payment>('payments', [orderBy('dueDate', 'desc')]),
        databaseService.getCollection<Compliance>('compliance', [orderBy('playerName', 'asc')])
      ]);
      
      setPayments(paymentsData);
      setCompliance(complianceData);
      
      calculateSummary(paymentsData);
    } catch (error) {
      console.error('Error loading financial/compliance data:', error);
    }
    setLoading(false);
  };

  const calculateSummary = (paymentsData: Payment[]) => {
    const totalRevenue = paymentsData
      .filter(p => p.status === 'paid')
      .reduce((sum, p) => sum + p.amount, 0);
    
    const totalPending = paymentsData
      .filter(p => p.status === 'pending')
      .reduce((sum, p) => sum + p.amount, 0);
    
    const totalOverdue = paymentsData
      .filter(p => p.status === 'overdue')
      .reduce((sum, p) => sum + p.amount, 0);
    
    const totalExpected = totalRevenue + totalPending + totalOverdue;
    const collectionRate = totalExpected > 0 ? (totalRevenue / totalExpected) * 100 : 0;

    const monthlyRevenue: { [key: string]: number } = {};
    paymentsData
      .filter(p => p.status === 'paid' && p.paidDate)
      .forEach(p => {
        const month = new Date(p.paidDate!).toLocaleDateString('en-US', { 
          year: 'numeric', 
          month: 'short' 
        });
        monthlyRevenue[month] = (monthlyRevenue[month] || 0) + p.amount;
      });

    setSummary({
      totalRevenue,
      totalPending,
      totalOverdue,
      collectionRate,
      monthlyRevenue: Object.entries(monthlyRevenue)
        .map(([month, amount]) => ({ month, amount }))
        .slice(-6)
    });
  };

  const handleSendReminder = async (payment: Payment) => {
    console.log('Sending reminder for payment:', payment.id);
  };

  const handleMarkPaid = async (paymentId: string) => {
    try {
      await databaseService.updateDocument('payments', paymentId, {
        status: 'paid',
        paidDate: new Date().toISOString()
      });
      await loadData();
    } catch (error) {
      console.error('Error marking payment as paid:', error);
    }
  };

  const handleApproveCompliance = async (complianceId: string, field: string) => {
    try {
      const updates: any = {};
      updates[field] = true;
      if (field === 'medicalClearance') {
        updates.medicalExpiry = new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString();
      }
      if (field === 'waiverSigned') {
        updates.waiverDate = new Date().toISOString();
      }
      
      await databaseService.updateDocument('compliance', complianceId, updates);
      await loadData();
    } catch (error) {
      console.error('Error updating compliance:', error);
    }
  };

  const exportFinancialReport = () => {
    const csv = [
      ['Player', 'Team', 'Type', 'Amount', 'Status', 'Due Date', 'Paid Date', 'Method'],
      ...payments.map(p => [
        p.playerName,
        p.teamName,
        p.type,
        p.amount,
        p.status,
        p.dueDate,
        p.paidDate || '',
        p.method || ''
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `financial_report_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const exportComplianceReport = () => {
    const csv = [
      ['Player', 'Team', 'Medical', 'Medical Expiry', 'Waiver', 'Insurance', 'Emergency Contact'],
      ...compliance.map(c => [
        c.playerName,
        c.teamName,
        c.medicalClearance ? 'Yes' : 'No',
        c.medicalExpiry || '',
        c.waiverSigned ? 'Yes' : 'No',
        c.insuranceVerified ? 'Yes' : 'No',
        c.emergencyContact.name + ' - ' + c.emergencyContact.phone
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compliance_report_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const filteredPayments = payments.filter(payment => {
    const matchesFilter = filter === 'all' || 
      (filter === 'pending' && payment.status === 'pending') ||
      (filter === 'overdue' && payment.status === 'overdue');
    const matchesSearch = payment.playerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          payment.teamName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const filteredCompliance = compliance.filter(item => {
    return item.playerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
           item.teamName.toLowerCase().includes(searchTerm.toLowerCase());
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Financial & Compliance</h2>
        <div className="flex gap-2">
          <Button
            variant={activeTab === 'financial' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('financial')}
          >
            Financial
          </Button>
          <Button
            variant={activeTab === 'compliance' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setActiveTab('compliance')}
          >
            Compliance
          </Button>
        </div>
      </div>

      {/* Financial Summary */}
      {activeTab === 'financial' && summary && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card variant="navy">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Total Revenue</p>
                    <p className="text-3xl font-bold text-white">
                      ${summary.totalRevenue.toLocaleString()}
                    </p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>

            <Card variant="navy">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Pending</p>
                    <p className="text-3xl font-bold text-white">
                      ${summary.totalPending.toLocaleString()}
                    </p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-500" />
                </div>
              </CardContent>
            </Card>

            <Card variant="navy">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Overdue</p>
                    <p className="text-3xl font-bold text-white">
                      ${summary.totalOverdue.toLocaleString()}
                    </p>
                  </div>
                  <AlertTriangle className="h-8 w-8 text-red-500" />
                </div>
              </CardContent>
            </Card>

            <Card variant="navy">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-400 text-sm">Collection Rate</p>
                    <p className="text-3xl font-bold text-white">
                      {summary.collectionRate.toFixed(1)}%
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Monthly Revenue Chart */}
          {summary.monthlyRevenue.length > 0 && (
            <Card variant="navy">
              <CardHeader>
                <CardTitle className="text-white">Monthly Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-end gap-2 h-40">
                  {summary.monthlyRevenue.map((month, index) => {
                    const maxAmount = Math.max(...summary.monthlyRevenue.map(m => m.amount));
                    const height = (month.amount / maxAmount) * 100;
                    return (
                      <div key={index} className="flex-1 flex flex-col items-center">
                        <div 
                          className="w-full bg-basketball-orange-500 rounded-t"
                          style={{ height: `${height}%` }}
                        />
                        <p className="text-xs text-gray-400 mt-2">{month.month}</p>
                        <p className="text-xs text-white">${month.amount}</p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </>
      )}

      {/* Search and Filter */}
      <Card variant="navy">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search player or team..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white placeholder-gray-400"
              />
            </div>
            {activeTab === 'financial' && (
              <div className="flex gap-2">
                {(['all', 'pending', 'overdue'] as const).map(status => (
                  <Button
                    key={status}
                    size="sm"
                    variant={filter === status ? 'primary' : 'outline'}
                    onClick={() => setFilter(status)}
                  >
                    {status.charAt(0).toUpperCase() + status.slice(1)}
                  </Button>
                ))}
              </div>
            )}
            <Button
              variant="secondary"
              size="sm"
              onClick={activeTab === 'financial' ? exportFinancialReport : exportComplianceReport}
            >
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Financial Tab Content */}
      {activeTab === 'financial' && (
        <div className="space-y-4">
          {filteredPayments.map(payment => (
            <Card key={payment.id} variant="navy">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold text-white">{payment.playerName}</h3>
                      <Badge variant={
                        payment.status === 'paid' ? 'success' :
                        payment.status === 'overdue' ? 'danger' :
                        'warning'
                      }>
                        {payment.status}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-gray-400">Team</p>
                        <p className="text-white">{payment.teamName}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Type</p>
                        <p className="text-white capitalize">{payment.type}</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Due Date</p>
                        <p className="text-white">
                          {new Date(payment.dueDate).toLocaleDateString()}
                        </p>
                      </div>
                      {payment.paidDate && (
                        <div>
                          <p className="text-gray-400">Paid Date</p>
                          <p className="text-white">
                            {new Date(payment.paidDate).toLocaleDateString()}
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-white">${payment.amount}</p>
                    <div className="flex gap-2 mt-3">
                      {payment.status !== 'paid' && (
                        <>
                          <Button
                            size="sm"
                            variant="success"
                            onClick={() => handleMarkPaid(payment.id)}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Mark Paid
                          </Button>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => handleSendReminder(payment)}
                          >
                            <Mail className="h-4 w-4 mr-1" />
                            Reminder
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Compliance Tab Content */}
      {activeTab === 'compliance' && (
        <div className="space-y-4">
          {filteredCompliance.map(item => (
            <Card key={item.id} variant="navy">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-lg font-semibold text-white mb-1">{item.playerName}</h3>
                    <p className="text-sm text-gray-400 mb-4">Team: {item.teamName}</p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Medical Clearance</p>
                        <div className="flex items-center gap-2">
                          {item.medicalClearance ? (
                            <Badge variant="success">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Valid
                            </Badge>
                          ) : (
                            <Badge variant="danger">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Required
                            </Badge>
                          )}
                        </div>
                        {item.medicalExpiry && (
                          <p className="text-xs text-gray-500 mt-1">
                            Expires: {new Date(item.medicalExpiry).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Waiver</p>
                        <div className="flex items-center gap-2">
                          {item.waiverSigned ? (
                            <Badge variant="success">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Signed
                            </Badge>
                          ) : (
                            <Badge variant="danger">
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Missing
                            </Badge>
                          )}
                        </div>
                        {item.waiverDate && (
                          <p className="text-xs text-gray-500 mt-1">
                            {new Date(item.waiverDate).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Insurance</p>
                        <div className="flex items-center gap-2">
                          {item.insuranceVerified ? (
                            <Badge variant="success">
                              <CheckCircle className="h-3 w-3 mr-1" />
                              Verified
                            </Badge>
                          ) : (
                            <Badge variant="warning">
                              <Clock className="h-3 w-3 mr-1" />
                              Pending
                            </Badge>
                          )}
                        </div>
                      </div>
                      
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Emergency Contact</p>
                        <p className="text-xs text-white">{item.emergencyContact.name}</p>
                        <p className="text-xs text-gray-500">{item.emergencyContact.phone}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col gap-2">
                    {!item.medicalClearance && (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => handleApproveCompliance(item.id, 'medicalClearance')}
                      >
                        <FileCheck className="h-4 w-4 mr-1" />
                        Approve Medical
                      </Button>
                    )}
                    {!item.waiverSigned && (
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => handleApproveCompliance(item.id, 'waiverSigned')}
                      >
                        <FileCheck className="h-4 w-4 mr-1" />
                        Mark Waiver
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default FinancialCompliance;