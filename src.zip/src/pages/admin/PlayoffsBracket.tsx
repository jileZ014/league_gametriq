import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, Trophy, Award, Users, Calendar, 
  ChevronRight, Play, RefreshCw, Save, Download
} from 'lucide-react';
import { db } from '../../firebase';
import { collection, query, where, getDocs, orderBy, limit } from 'firebase/firestore';

interface Team {
  id: string;
  name: string;
  division: string;
  wins: number;
  losses: number;
  seed?: number;
}

interface BracketGame {
  id: string;
  round: number;
  position: number;
  team1: Team | null;
  team2: Team | null;
  winner: Team | null;
  score1?: number;
  score2?: number;
  date?: string;
  time?: string;
  venue?: string;
}

export const PlayoffsBracket: React.FC = () => {
  const navigate = useNavigate();
  const [selectedDivision, setSelectedDivision] = useState<string>('');
  const [divisions, setDivisions] = useState<string[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [bracketGames, setBracketGames] = useState<BracketGame[]>([]);
  const [bracketType, setBracketType] = useState<'single' | 'double'>('single');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDivisions();
  }, []);

  useEffect(() => {
    if (selectedDivision) {
      loadTeamsAndStandings();
    }
  }, [selectedDivision]);

  const loadDivisions = async () => {
    try {
      const teamsSnapshot = await getDocs(collection(db, 'teams'));
      const divs = [...new Set(teamsSnapshot.docs.map(doc => doc.data().division))].filter(Boolean);
      setDivisions(divs);
      if (divs.length > 0) {
        setSelectedDivision(divs[0]);
      }
      setLoading(false);
    } catch (error) {
      console.error('Error loading divisions:', error);
      setLoading(false);
    }
  };

  const loadTeamsAndStandings = async () => {
    try {
      const q = query(
        collection(db, 'teams'),
        where('division', '==', selectedDivision)
      );
      const snapshot = await getDocs(q);
      
      const teamsData = snapshot.docs
        .map(doc => ({
          id: doc.id,
          ...doc.data()
        } as Team))
        .sort((a, b) => {
          const aWinPct = a.wins / (a.wins + a.losses || 1);
          const bWinPct = b.wins / (b.wins + b.losses || 1);
          return bWinPct - aWinPct;
        })
        .slice(0, 8) // Top 8 teams for playoffs
        .map((team, index) => ({ ...team, seed: index + 1 }));
      
      setTeams(teamsData);
      generateBracket(teamsData);
    } catch (error) {
      console.error('Error loading teams:', error);
    }
  };

  const generateBracket = (teamsData: Team[]) => {
    const games: BracketGame[] = [];
    
    // First round (Quarter-finals for 8 teams)
    if (teamsData.length >= 8) {
      games.push(
        { id: 'qf1', round: 1, position: 1, team1: teamsData[0], team2: teamsData[7], winner: null },
        { id: 'qf2', round: 1, position: 2, team1: teamsData[3], team2: teamsData[4], winner: null },
        { id: 'qf3', round: 1, position: 3, team1: teamsData[2], team2: teamsData[5], winner: null },
        { id: 'qf4', round: 1, position: 4, team1: teamsData[1], team2: teamsData[6], winner: null }
      );
      
      // Semi-finals
      games.push(
        { id: 'sf1', round: 2, position: 1, team1: null, team2: null, winner: null },
        { id: 'sf2', round: 2, position: 2, team1: null, team2: null, winner: null }
      );
      
      // Finals
      games.push(
        { id: 'f1', round: 3, position: 1, team1: null, team2: null, winner: null }
      );
    }
    
    setBracketGames(games);
  };

  const saveBracket = async () => {
    // Save bracket to database
    alert('Playoff bracket saved successfully!');
  };

  const exportBracket = () => {
    // Export bracket as PDF or image
    alert('Bracket export feature coming soon!');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glass-panel p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-display font-bold text-gradient">
                  Playoffs Bracket System
                </h1>
                <p className="text-gray-400 mt-1">Manage tournament brackets and seeding</p>
              </div>
            </div>
            <div className="h-12 w-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center">
              <Trophy className="h-8 w-8 text-white" />
            </div>
          </div>
        </div>

        {/* Configuration */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white">Bracket Configuration</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Division</label>
                <select
                  value={selectedDivision}
                  onChange={(e) => setSelectedDivision(e.target.value)}
                  className="glass-input w-full text-white"
                >
                  {divisions.map(div => (
                    <option key={div} value={div}>{div}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Bracket Type</label>
                <select
                  value={bracketType}
                  onChange={(e) => setBracketType(e.target.value as 'single' | 'double')}
                  className="glass-input w-full text-white"
                >
                  <option value="single">Single Elimination</option>
                  <option value="double">Double Elimination</option>
                </select>
              </div>
              <div className="flex items-end gap-2">
                <Button
                  onClick={() => generateBracket(teams)}
                  className="glass-button text-white"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Regenerate
                </Button>
                <Button
                  onClick={saveBracket}
                  className="glass-button bg-green-500/20 hover:bg-green-500/30 text-white"
                >
                  <Save className="h-4 w-4 mr-2" />
                  Save
                </Button>
                <Button
                  onClick={exportBracket}
                  className="glass-button text-white"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Seeding */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Award className="h-5 w-5 mr-2" />
              Tournament Seeding
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {teams.map(team => (
                <div key={team.id} className="flex items-center justify-between p-3 glass-panel">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center text-white font-bold">
                      {team.seed}
                    </div>
                    <div>
                      <p className="text-white font-medium">{team.name}</p>
                      <p className="text-sm text-gray-400">
                        Record: {team.wins}-{team.losses}
                      </p>
                    </div>
                  </div>
                  <Badge className="glass-badge border-green-500/50">
                    Seed #{team.seed}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Bracket Visualization */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white">Tournament Bracket</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <div className="min-w-[800px] p-4">
                {/* Simple bracket visualization */}
                <div className="grid grid-cols-4 gap-8">
                  {/* Quarter Finals */}
                  <div className="space-y-8">
                    <h3 className="text-white font-semibold mb-4">Quarter Finals</h3>
                    {bracketGames.filter(g => g.round === 1).map(game => (
                      <div key={game.id} className="glass-panel p-3">
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-white text-sm">
                              {game.team1?.name || 'TBD'}
                            </span>
                            <Badge className="text-xs">{game.team1?.seed}</Badge>
                          </div>
                          <div className="border-t border-gray-700"></div>
                          <div className="flex justify-between items-center">
                            <span className="text-white text-sm">
                              {game.team2?.name || 'TBD'}
                            </span>
                            <Badge className="text-xs">{game.team2?.seed}</Badge>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Semi Finals */}
                  <div className="space-y-8">
                    <h3 className="text-white font-semibold mb-4">Semi Finals</h3>
                    <div className="mt-16">
                      {bracketGames.filter(g => g.round === 2).map(game => (
                        <div key={game.id} className="glass-panel p-3 mb-32">
                          <div className="space-y-2">
                            <div className="text-white text-sm">Winner QF1</div>
                            <div className="border-t border-gray-700"></div>
                            <div className="text-white text-sm">Winner QF2</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Finals */}
                  <div className="space-y-8">
                    <h3 className="text-white font-semibold mb-4">Finals</h3>
                    <div className="mt-32">
                      {bracketGames.filter(g => g.round === 3).map(game => (
                        <div key={game.id} className="glass-panel p-3">
                          <div className="space-y-2">
                            <div className="text-white text-sm">Winner SF1</div>
                            <div className="border-t border-gray-700"></div>
                            <div className="text-white text-sm">Winner SF2</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Champion */}
                  <div className="space-y-8">
                    <h3 className="text-white font-semibold mb-4">Champion</h3>
                    <div className="mt-48">
                      <div className="glass-panel p-4 border-amber-500/50">
                        <Trophy className="h-8 w-8 text-amber-400 mx-auto mb-2" />
                        <p className="text-center text-white font-bold">TBD</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default PlayoffsBracket;