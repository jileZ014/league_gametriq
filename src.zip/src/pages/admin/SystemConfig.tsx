import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, Settings, Save, Shield, Clock, 
  Trophy, Users, Calendar, Bell, Mail, Globe,
  Database, AlertCircle, Check
} from 'lucide-react';

interface SystemSettings {
  leagueName: string;
  leagueLogo: string;
  seasonYear: string;
  registrationOpen: boolean;
  registrationDeadline: string;
  gameLength: number;
  quarters: number;
  foulsLimit: number;
  timeoutsPerHalf: number;
  mercyRule: boolean;
  mercyRulePoints: number;
  minPlayersRequired: number;
  maxRosterSize: number;
  ageVerificationRequired: boolean;
  parentConsentRequired: boolean;
  emailNotifications: boolean;
  smsNotifications: boolean;
  autoStandingsUpdate: boolean;
  publicPortalEnabled: boolean;
  maintenanceMode: boolean;
}

export const SystemConfig: React.FC = () => {
  const navigate = useNavigate();
  const [settings, setSettings] = useState<SystemSettings>({
    leagueName: 'Youth Basketball League',
    leagueLogo: '',
    seasonYear: '2025',
    registrationOpen: true,
    registrationDeadline: '2025-02-01',
    gameLength: 40,
    quarters: 4,
    foulsLimit: 5,
    timeoutsPerHalf: 3,
    mercyRule: true,
    mercyRulePoints: 30,
    minPlayersRequired: 5,
    maxRosterSize: 15,
    ageVerificationRequired: true,
    parentConsentRequired: true,
    emailNotifications: true,
    smsNotifications: false,
    autoStandingsUpdate: true,
    publicPortalEnabled: true,
    maintenanceMode: false
  });
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    // Simulate saving to database
    setTimeout(() => {
      setSaving(false);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    }, 1000);
  };

  const handleToggle = (key: keyof SystemSettings) => {
    setSettings(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleChange = (key: keyof SystemSettings, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glass-panel p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-display font-bold text-gradient">
                  System Configuration
                </h1>
                <p className="text-gray-400 mt-1">Configure league settings and rules</p>
              </div>
            </div>
            <div className="h-12 w-12 bg-gradient-to-br from-gray-500 to-gray-600 rounded-full flex items-center justify-center">
              <Settings className="h-8 w-8 text-white" />
            </div>
          </div>
        </div>

        {/* Save Notification */}
        {saved && (
          <div className="glass-panel p-4 border-green-500/50">
            <div className="flex items-center gap-2">
              <Check className="h-5 w-5 text-green-400" />
              <span className="text-green-400">Settings saved successfully!</span>
            </div>
          </div>
        )}

        {/* League Settings */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Trophy className="h-5 w-5 mr-2" />
              League Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">League Name</label>
                <input
                  type="text"
                  value={settings.leagueName}
                  onChange={(e) => handleChange('leagueName', e.target.value)}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Season Year</label>
                <input
                  type="text"
                  value={settings.seasonYear}
                  onChange={(e) => handleChange('seasonYear', e.target.value)}
                  className="glass-input w-full text-white"
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Registration Deadline</label>
                <input
                  type="date"
                  value={settings.registrationDeadline}
                  onChange={(e) => handleChange('registrationDeadline', e.target.value)}
                  className="glass-input w-full text-white"
                />
              </div>
              <div className="flex items-end">
                <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer w-full">
                  <input
                    type="checkbox"
                    checked={settings.registrationOpen}
                    onChange={() => handleToggle('registrationOpen')}
                    className="rounded border-gray-600"
                  />
                  <div>
                    <p className="text-white">Registration Open</p>
                    <p className="text-xs text-gray-400">Allow new team registrations</p>
                  </div>
                </label>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Game Rules */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Clock className="h-5 w-5 mr-2" />
              Game Rules
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Game Length (min)</label>
                <input
                  type="number"
                  value={settings.gameLength}
                  onChange={(e) => handleChange('gameLength', parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Quarters</label>
                <input
                  type="number"
                  value={settings.quarters}
                  onChange={(e) => handleChange('quarters', parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Fouls Limit</label>
                <input
                  type="number"
                  value={settings.foulsLimit}
                  onChange={(e) => handleChange('foulsLimit', parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Timeouts/Half</label>
                <input
                  type="number"
                  value={settings.timeoutsPerHalf}
                  onChange={(e) => handleChange('timeoutsPerHalf', parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.mercyRule}
                  onChange={() => handleToggle('mercyRule')}
                  className="rounded border-gray-600"
                />
                <div className="flex-1">
                  <p className="text-white">Mercy Rule</p>
                  <p className="text-xs text-gray-400">End game if point differential exceeds limit</p>
                </div>
              </label>
              
              {settings.mercyRule && (
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Mercy Rule Points</label>
                  <input
                    type="number"
                    value={settings.mercyRulePoints}
                    onChange={(e) => handleChange('mercyRulePoints', parseInt(e.target.value))}
                    className="glass-input w-full text-white"
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Team Settings */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Team Settings
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Min Players Required</label>
                <input
                  type="number"
                  value={settings.minPlayersRequired}
                  onChange={(e) => handleChange('minPlayersRequired', parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Max Roster Size</label>
                <input
                  type="number"
                  value={settings.maxRosterSize}
                  onChange={(e) => handleChange('maxRosterSize', parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.ageVerificationRequired}
                  onChange={() => handleToggle('ageVerificationRequired')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-white">Age Verification Required</p>
                  <p className="text-xs text-gray-400">Require proof of age for players</p>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.parentConsentRequired}
                  onChange={() => handleToggle('parentConsentRequired')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-white">Parent Consent Required</p>
                  <p className="text-xs text-gray-400">Require parent/guardian consent</p>
                </div>
              </label>
            </div>
          </CardContent>
        </Card>

        {/* System Settings */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Database className="h-5 w-5 mr-2" />
              System Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.emailNotifications}
                  onChange={() => handleToggle('emailNotifications')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-white">Email Notifications</p>
                  <p className="text-xs text-gray-400">Send email updates to users</p>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.smsNotifications}
                  onChange={() => handleToggle('smsNotifications')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-white">SMS Notifications</p>
                  <p className="text-xs text-gray-400">Send text message updates</p>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.autoStandingsUpdate}
                  onChange={() => handleToggle('autoStandingsUpdate')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-white">Auto Standings Update</p>
                  <p className="text-xs text-gray-400">Automatically calculate standings</p>
                </div>
              </label>

              <label className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.publicPortalEnabled}
                  onChange={() => handleToggle('publicPortalEnabled')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-white">Public Portal Enabled</p>
                  <p className="text-xs text-gray-400">Allow public access to schedules</p>
                </div>
              </label>
            </div>

            {/* Maintenance Mode */}
            <div className="mt-6 p-4 glass-panel border-yellow-500/50">
              <label className="flex items-center gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.maintenanceMode}
                  onChange={() => handleToggle('maintenanceMode')}
                  className="rounded border-gray-600"
                />
                <div>
                  <p className="text-yellow-400 font-semibold">Maintenance Mode</p>
                  <p className="text-xs text-gray-400">Temporarily disable public access for maintenance</p>
                </div>
              </label>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button
            onClick={handleSave}
            disabled={saving}
            className="glass-button bg-green-500/20 hover:bg-green-500/30 text-white px-8"
          >
            {saving ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Saving...
              </>
            ) : (
              <>
                <Save className="h-5 w-5 mr-2" />
                Save Settings
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SystemConfig;