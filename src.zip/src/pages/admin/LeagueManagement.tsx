import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  Trophy, Plus, Edit, Trash2, Calendar, Users, 
  DollarSign, Settings, Check, X, AlertTriangle,
  Clock, MapPin, Shield, FileText
} from 'lucide-react';
import { databaseService } from '../../services/DatabaseService';
import { useAuth } from '../../AuthContext';
import { where } from 'firebase/firestore';

interface League {
  id: string;
  name: string;
  description: string;
  sport: string;
  season: string;
  startDate: string;
  endDate: string;
  registrationDeadline: string;
  status: 'planning' | 'registration' | 'active' | 'completed';
  divisions: Division[];
  fees: FeeStructure;
  rules: LeagueRules;
  venues: string[];
  maxTeams: number;
  currentTeams: number;
  createdBy: string;
  createdAt: any;
  updatedAt: any;
}

interface Division {
  id: string;
  name: string;
  ageMin: number;
  ageMax: number;
  skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'elite';
  maxTeams: number;
  currentTeams: number;
}

interface FeeStructure {
  registrationFee: number;
  earlyBirdDiscount: number;
  earlyBirdDeadline: string;
  lateFee: number;
  lateFeeStartDate: string;
  scholarshipAvailable: boolean;
  paymentPlans: boolean;
  refundPolicy: string;
}

interface LeagueRules {
  gameLength: number;
  periodLength: number;
  periods: number;
  overtimeRules: string;
  foulLimit: number;
  timeoutsPerHalf: number;
  substitutionRules: string;
  eligibilityRequirements: string;
  conductCode: string;
}

const LeagueManagement: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [leagues, setLeagues] = useState<League[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingLeague, setEditingLeague] = useState<League | null>(null);
  const [formData, setFormData] = useState<Partial<League>>({
    name: '',
    description: '',
    sport: 'basketball',
    season: '',
    startDate: '',
    endDate: '',
    registrationDeadline: '',
    status: 'planning',
    divisions: [],
    fees: {
      registrationFee: 0,
      earlyBirdDiscount: 0,
      earlyBirdDeadline: '',
      lateFee: 0,
      lateFeeStartDate: '',
      scholarshipAvailable: false,
      paymentPlans: false,
      refundPolicy: ''
    },
    rules: {
      gameLength: 40,
      periodLength: 10,
      periods: 4,
      overtimeRules: '5 minute overtime periods',
      foulLimit: 5,
      timeoutsPerHalf: 3,
      substitutionRules: 'Unlimited substitutions on dead balls',
      eligibilityRequirements: 'Age verification required',
      conductCode: 'Zero tolerance for unsportsmanlike conduct'
    },
    venues: [],
    maxTeams: 0
  });

  useEffect(() => {
    loadLeagues();
  }, []);

  const loadLeagues = async () => {
    setLoading(true);
    try {
      const leaguesData = await databaseService.getCollection<League>('leagues');
      setLeagues(leaguesData);
    } catch (error) {
      console.error('Error loading leagues:', error);
    }
    setLoading(false);
  };

  const handleCreateLeague = async () => {
    if (!formData.name || !formData.startDate || !formData.endDate) {
      alert('Please fill in all required fields');
      return;
    }

    try {
      await databaseService.createDocument('leagues', null, {
        ...formData,
        currentTeams: 0,
        createdBy: currentUser?.uid,
        divisions: formData.divisions?.map(d => ({
          ...d,
          id: Math.random().toString(36).substr(2, 9),
          currentTeams: 0
        }))
      });

      await loadLeagues();
      setShowCreateModal(false);
      resetForm();
    } catch (error) {
      console.error('Error creating league:', error);
      alert('Failed to create league. Please try again.');
    }
  };

  const handleUpdateLeague = async () => {
    if (!editingLeague || !formData.name) return;

    try {
      await databaseService.updateDocument('leagues', editingLeague.id, formData);
      await loadLeagues();
      setEditingLeague(null);
      resetForm();
    } catch (error) {
      console.error('Error updating league:', error);
      alert('Failed to update league. Please try again.');
    }
  };

  const handleDeleteLeague = async (leagueId: string) => {
    if (!confirm('Are you sure you want to delete this league? This action cannot be undone.')) {
      return;
    }

    try {
      await databaseService.deleteDocument('leagues', leagueId);
      await loadLeagues();
    } catch (error) {
      console.error('Error deleting league:', error);
      alert('Failed to delete league. Please try again.');
    }
  };

  const addDivision = () => {
    const newDivision: Division = {
      id: Math.random().toString(36).substr(2, 9),
      name: '',
      ageMin: 0,
      ageMax: 0,
      skillLevel: 'beginner',
      maxTeams: 0,
      currentTeams: 0
    };

    setFormData(prev => ({
      ...prev,
      divisions: [...(prev.divisions || []), newDivision]
    }));
  };

  const updateDivision = (index: number, field: keyof Division, value: any) => {
    const divisions = [...(formData.divisions || [])];
    divisions[index] = { ...divisions[index], [field]: value };
    setFormData(prev => ({ ...prev, divisions }));
  };

  const removeDivision = (index: number) => {
    const divisions = [...(formData.divisions || [])];
    divisions.splice(index, 1);
    setFormData(prev => ({ ...prev, divisions }));
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      sport: 'basketball',
      season: '',
      startDate: '',
      endDate: '',
      registrationDeadline: '',
      status: 'planning',
      divisions: [],
      fees: {
        registrationFee: 0,
        earlyBirdDiscount: 0,
        earlyBirdDeadline: '',
        lateFee: 0,
        lateFeeStartDate: '',
        scholarshipAvailable: false,
        paymentPlans: false,
        refundPolicy: ''
      },
      rules: {
        gameLength: 40,
        periodLength: 10,
        periods: 4,
        overtimeRules: '5 minute overtime periods',
        foulLimit: 5,
        timeoutsPerHalf: 3,
        substitutionRules: 'Unlimited substitutions on dead balls',
        eligibilityRequirements: 'Age verification required',
        conductCode: 'Zero tolerance for unsportsmanlike conduct'
      },
      venues: [],
      maxTeams: 0
    });
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'planning':
        return <Badge variant="secondary">Planning</Badge>;
      case 'registration':
        return <Badge variant="warning">Registration Open</Badge>;
      case 'active':
        return <Badge variant="success">Active</Badge>;
      case 'completed':
        return <Badge variant="outline">Completed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-white">League Management</h2>
          <p className="text-gray-400">Create and manage basketball leagues</p>
        </div>
        <Button
          onClick={() => setShowCreateModal(true)}
          variant="primary"
        >
          <Plus className="h-4 w-4 mr-2" />
          Create League
        </Button>
      </div>

      {/* Leagues Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {leagues.length === 0 ? (
          <Card variant="navy" className="col-span-full">
            <CardContent className="text-center py-12">
              <Trophy className="h-16 w-16 text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400 mb-4">No leagues created yet</p>
              <Button onClick={() => setShowCreateModal(true)} variant="primary">
                Create Your First League
              </Button>
            </CardContent>
          </Card>
        ) : (
          leagues.map(league => (
            <Card key={league.id} variant="navy">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-white">{league.name}</CardTitle>
                    <p className="text-gray-400 text-sm mt-1">{league.description}</p>
                  </div>
                  {getStatusBadge(league.status)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* League Info */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-400">Season</p>
                    <p className="text-white font-semibold">{league.season}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Teams</p>
                    <p className="text-white font-semibold">
                      {league.currentTeams}/{league.maxTeams}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Start Date</p>
                    <p className="text-white font-semibold">
                      {new Date(league.startDate).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-gray-400">Registration Deadline</p>
                    <p className="text-white font-semibold">
                      {new Date(league.registrationDeadline).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {/* Divisions */}
                {league.divisions && league.divisions.length > 0 && (
                  <div>
                    <p className="text-gray-400 text-sm mb-2">Divisions</p>
                    <div className="flex flex-wrap gap-2">
                      {league.divisions.map(division => (
                        <Badge key={division.id} variant="outline">
                          {division.name} ({division.ageMin}-{division.ageMax} yrs)
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Fees */}
                {league.fees && (
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-gray-400 text-sm">Registration Fee</p>
                      <p className="text-white font-semibold text-lg">
                        ${league.fees.registrationFee}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {league.fees.scholarshipAvailable && (
                        <Badge variant="success">Scholarships</Badge>
                      )}
                      {league.fees.paymentPlans && (
                        <Badge variant="success">Payment Plans</Badge>
                      )}
                    </div>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-2 pt-4 border-t border-navy-800">
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => navigate(`/admin/leagues/${league.id}`)}
                  >
                    <Settings className="h-4 w-4 mr-1" />
                    Manage
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      setEditingLeague(league);
                      setFormData(league);
                      setShowCreateModal(true);
                    }}
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="text-red-400 hover:bg-red-900/20"
                    onClick={() => handleDeleteLeague(league.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Create/Edit Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-navy-900 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-navy-900 border-b border-navy-800 p-6">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-white">
                  {editingLeague ? 'Edit League' : 'Create New League'}
                </h2>
                <Button
                  variant="ghost"
                  onClick={() => {
                    setShowCreateModal(false);
                    setEditingLeague(null);
                    resetForm();
                  }}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Basic Information */}
              <Card variant="navy">
                <CardHeader>
                  <CardTitle className="text-white">Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        League Name *
                      </label>
                      <input
                        type="text"
                        value={formData.name}
                        onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                        placeholder="e.g., Spring 2024 Basketball League"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Season
                      </label>
                      <input
                        type="text"
                        value={formData.season}
                        onChange={(e) => setFormData(prev => ({ ...prev, season: e.target.value }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                        placeholder="e.g., Spring 2024"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">
                      Description
                    </label>
                    <textarea
                      value={formData.description}
                      onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                      className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                      rows={3}
                      placeholder="League description..."
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Start Date *
                      </label>
                      <input
                        type="date"
                        value={formData.startDate}
                        onChange={(e) => setFormData(prev => ({ ...prev, startDate: e.target.value }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        End Date *
                      </label>
                      <input
                        type="date"
                        value={formData.endDate}
                        onChange={(e) => setFormData(prev => ({ ...prev, endDate: e.target.value }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Registration Deadline
                      </label>
                      <input
                        type="date"
                        value={formData.registrationDeadline}
                        onChange={(e) => setFormData(prev => ({ ...prev, registrationDeadline: e.target.value }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Status
                      </label>
                      <select
                        value={formData.status}
                        onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as League['status'] }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                      >
                        <option value="planning">Planning</option>
                        <option value="registration">Registration Open</option>
                        <option value="active">Active</option>
                        <option value="completed">Completed</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Max Teams
                      </label>
                      <input
                        type="number"
                        value={formData.maxTeams}
                        onChange={(e) => setFormData(prev => ({ ...prev, maxTeams: parseInt(e.target.value) }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                        placeholder="0"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Divisions */}
              <Card variant="navy">
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white">Age Divisions</CardTitle>
                    <Button size="sm" variant="primary" onClick={addDivision}>
                      <Plus className="h-4 w-4 mr-1" />
                      Add Division
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {formData.divisions && formData.divisions.length > 0 ? (
                    <div className="space-y-4">
                      {formData.divisions.map((division, index) => (
                        <div key={division.id} className="border border-navy-700 rounded p-4 space-y-3">
                          <div className="flex justify-between items-start">
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 flex-1">
                              <input
                                type="text"
                                value={division.name}
                                onChange={(e) => updateDivision(index, 'name', e.target.value)}
                                className="p-2 bg-navy-800 border border-navy-700 rounded text-white"
                                placeholder="Division name"
                              />
                              <input
                                type="number"
                                value={division.ageMin}
                                onChange={(e) => updateDivision(index, 'ageMin', parseInt(e.target.value))}
                                className="p-2 bg-navy-800 border border-navy-700 rounded text-white"
                                placeholder="Min age"
                              />
                              <input
                                type="number"
                                value={division.ageMax}
                                onChange={(e) => updateDivision(index, 'ageMax', parseInt(e.target.value))}
                                className="p-2 bg-navy-800 border border-navy-700 rounded text-white"
                                placeholder="Max age"
                              />
                              <select
                                value={division.skillLevel}
                                onChange={(e) => updateDivision(index, 'skillLevel', e.target.value)}
                                className="p-2 bg-navy-800 border border-navy-700 rounded text-white"
                              >
                                <option value="beginner">Beginner</option>
                                <option value="intermediate">Intermediate</option>
                                <option value="advanced">Advanced</option>
                                <option value="elite">Elite</option>
                              </select>
                            </div>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => removeDivision(index)}
                              className="text-red-400 hover:bg-red-900/20"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-gray-400 text-center py-4">
                      No divisions added yet. Click "Add Division" to create age groups.
                    </p>
                  )}
                </CardContent>
              </Card>

              {/* Fee Structure */}
              <Card variant="navy">
                <CardHeader>
                  <CardTitle className="text-white">Fee Structure</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Registration Fee ($)
                      </label>
                      <input
                        type="number"
                        value={formData.fees?.registrationFee}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          fees: { ...prev.fees!, registrationFee: parseFloat(e.target.value) }
                        }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                        placeholder="0.00"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-400 mb-1">
                        Early Bird Discount ($)
                      </label>
                      <input
                        type="number"
                        value={formData.fees?.earlyBirdDiscount}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          fees: { ...prev.fees!, earlyBirdDiscount: parseFloat(e.target.value) }
                        }))}
                        className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                        placeholder="0.00"
                      />
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-white">
                      <input
                        type="checkbox"
                        checked={formData.fees?.scholarshipAvailable}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          fees: { ...prev.fees!, scholarshipAvailable: e.target.checked }
                        }))}
                        className="rounded"
                      />
                      Scholarships Available
                    </label>
                    <label className="flex items-center gap-2 text-white">
                      <input
                        type="checkbox"
                        checked={formData.fees?.paymentPlans}
                        onChange={(e) => setFormData(prev => ({
                          ...prev,
                          fees: { ...prev.fees!, paymentPlans: e.target.checked }
                        }))}
                        className="rounded"
                      />
                      Payment Plans Available
                    </label>
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCreateModal(false);
                    setEditingLeague(null);
                    resetForm();
                  }}
                >
                  Cancel
                </Button>
                <Button
                  variant="primary"
                  onClick={editingLeague ? handleUpdateLeague : handleCreateLeague}
                >
                  {editingLeague ? 'Update League' : 'Create League'}
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LeagueManagement;