import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, Users, Check, X, Clock, Mail, Phone, 
  Calendar, MapPin, Shield, AlertCircle 
} from 'lucide-react';
import { db } from '../../firebase';
import { collection, query, where, getDocs, doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../../AuthContext';

interface Team {
  id: string;
  name: string;
  division: string;
  coachName: string;
  coachEmail: string;
  coachPhone: string;
  assistantCoach?: string;
  homeVenue?: string;
  registrationDate: string;
  status: 'pending' | 'approved' | 'rejected';
  playerCount?: number;
  notes?: string;
}

export const TeamApproval: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [teams, setTeams] = useState<Team[]>([]);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('pending');
  const [loading, setLoading] = useState(true);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);

  useEffect(() => {
    loadTeams();
  }, [filter]);

  const loadTeams = async () => {
    setLoading(true);
    try {
      let q;
      if (filter === 'all') {
        q = query(collection(db, 'teams'));
      } else {
        q = query(collection(db, 'teams'), where('status', '==', filter));
      }
      
      const snapshot = await getDocs(q);
      const teamsData = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Team));
      
      setTeams(teamsData);
    } catch (error) {
      console.error('Error loading teams:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApproval = async (teamId: string, approved: boolean) => {
    try {
      const teamRef = doc(db, 'teams', teamId);
      await updateDoc(teamRef, {
        status: approved ? 'approved' : 'rejected',
        reviewedBy: currentUser?.uid,
        reviewedAt: serverTimestamp(),
        reviewerName: currentUser?.displayName || 'Admin'
      });
      
      // Show success message
      const action = approved ? 'approved' : 'rejected';
      console.log(`Team ${action} successfully`);
      
      // Reload teams
      loadTeams();
    } catch (error) {
      console.error('Error updating team:', error);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'border-yellow-500/50';
      case 'approved': return 'border-green-500/50';
      case 'rejected': return 'border-red-500/50';
      default: return 'border-gray-500/50';
    }
  };

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glass-panel p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-display font-bold text-gradient">
                  Team Approval System
                </h1>
                <p className="text-gray-400 mt-1">Review and manage team registrations</p>
              </div>
            </div>
            <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
              <Users className="h-8 w-8 text-white" />
            </div>
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2">
          {(['all', 'pending', 'approved', 'rejected'] as const).map((status) => (
            <Button
              key={status}
              onClick={() => setFilter(status)}
              variant={filter === status ? 'default' : 'ghost'}
              className={filter === status ? 'glass-button text-white' : 'text-gray-400'}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
              {status === 'pending' && teams.filter(t => t.status === 'pending').length > 0 && (
                <Badge className="ml-2 bg-yellow-500/20 text-yellow-300">
                  {teams.filter(t => t.status === 'pending').length}
                </Badge>
              )}
            </Button>
          ))}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="glass-panel">
            <CardContent className="p-4">
              <Clock className="h-6 w-6 text-yellow-400 mb-2" />
              <p className="text-2xl font-bold text-white">
                {teams.filter(t => t.status === 'pending').length}
              </p>
              <p className="text-xs text-gray-400">Pending Review</p>
            </CardContent>
          </Card>
          <Card className="glass-panel">
            <CardContent className="p-4">
              <Check className="h-6 w-6 text-green-400 mb-2" />
              <p className="text-2xl font-bold text-white">
                {teams.filter(t => t.status === 'approved').length}
              </p>
              <p className="text-xs text-gray-400">Approved</p>
            </CardContent>
          </Card>
          <Card className="glass-panel">
            <CardContent className="p-4">
              <X className="h-6 w-6 text-red-400 mb-2" />
              <p className="text-2xl font-bold text-white">
                {teams.filter(t => t.status === 'rejected').length}
              </p>
              <p className="text-xs text-gray-400">Rejected</p>
            </CardContent>
          </Card>
          <Card className="glass-panel">
            <CardContent className="p-4">
              <Users className="h-6 w-6 text-blue-400 mb-2" />
              <p className="text-2xl font-bold text-white">{teams.length}</p>
              <p className="text-xs text-gray-400">Total Teams</p>
            </CardContent>
          </Card>
        </div>

        {/* Teams List */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white">Team Applications</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
              </div>
            ) : teams.length === 0 ? (
              <div className="text-center py-8">
                <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-400">No teams found with status: {filter}</p>
              </div>
            ) : (
              <div className="space-y-4">
                {teams.map((team) => (
                  <div key={team.id} className="glass-panel p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-xl font-semibold text-white">{team.name}</h3>
                          <Badge className={`glass-badge ${getStatusColor(team.status)}`}>
                            {team.status}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm">
                              <Shield className="h-4 w-4 text-gray-400" />
                              <span className="text-gray-400">Division:</span>
                              <span className="text-white">{team.division}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Users className="h-4 w-4 text-gray-400" />
                              <span className="text-gray-400">Coach:</span>
                              <span className="text-white">{team.coachName}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Mail className="h-4 w-4 text-gray-400" />
                              <span className="text-gray-400">Email:</span>
                              <span className="text-white">{team.coachEmail}</span>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-sm">
                              <Phone className="h-4 w-4 text-gray-400" />
                              <span className="text-gray-400">Phone:</span>
                              <span className="text-white">{team.coachPhone}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Calendar className="h-4 w-4 text-gray-400" />
                              <span className="text-gray-400">Registered:</span>
                              <span className="text-white">
                                {new Date(team.registrationDate).toLocaleDateString()}
                              </span>
                            </div>
                            {team.homeVenue && (
                              <div className="flex items-center gap-2 text-sm">
                                <MapPin className="h-4 w-4 text-gray-400" />
                                <span className="text-gray-400">Venue:</span>
                                <span className="text-white">{team.homeVenue}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        {team.notes && (
                          <div className="mt-4 p-3 bg-gray-900/50 rounded-lg">
                            <p className="text-sm text-gray-400">Notes:</p>
                            <p className="text-white text-sm mt-1">{team.notes}</p>
                          </div>
                        )}
                      </div>

                      {team.status === 'pending' && (
                        <div className="flex gap-2 ml-4">
                          <Button
                            onClick={() => handleApproval(team.id, true)}
                            className="glass-button bg-green-500/20 hover:bg-green-500/30 text-white"
                          >
                            <Check className="h-4 w-4 mr-1" />
                            Approve
                          </Button>
                          <Button
                            onClick={() => handleApproval(team.id, false)}
                            className="glass-button bg-red-500/20 hover:bg-red-500/30 text-white"
                          >
                            <X className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TeamApproval;