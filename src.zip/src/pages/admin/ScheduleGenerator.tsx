import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  Calendar, Clock, MapPin, RefreshCw, Save, 
  AlertCircle, ChevronLeft, ChevronRight, Plus,
  Edit, Trash2, Copy, Filter, Download
} from 'lucide-react';
import { databaseService } from '../../services/DatabaseService';
import { where, orderBy } from 'firebase/firestore';

interface Venue {
  id: string;
  name: string;
  address: string;
  courts: number;
  availability: {
    [day: string]: {
      start: string;
      end: string;
      courts: number[];
    };
  };
  blocked: string[];
}

interface Game {
  id: string;
  homeTeam: string;
  homeTeamId: string;
  awayTeam: string;
  awayTeamId: string;
  date: string;
  time: string;
  venue: string;
  venueId: string;
  court: number;
  division: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
  officials: string[];
}

interface Division {
  id: string;
  name: string;
  teams: string[];
  gameLength: number;
  gamesPerTeam: number;
}

export const ScheduleGenerator: React.FC = () => {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [games, setGames] = useState<Game[]>([]);
  const [divisions, setDivisions] = useState<Division[]>([]);
  const [selectedDivision, setSelectedDivision] = useState<string>('all');
  const [selectedWeek, setSelectedWeek] = useState(0);
  const [showVenueModal, setShowVenueModal] = useState(false);
  const [showGenerateModal, setShowGenerateModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  const [newVenue, setNewVenue] = useState<Partial<Venue>>({
    name: '',
    address: '',
    courts: 1,
    availability: {
      saturday: { start: '08:00', end: '20:00', courts: [1] },
      sunday: { start: '08:00', end: '18:00', courts: [1] }
    },
    blocked: []
  });

  const [scheduleParams, setScheduleParams] = useState({
    startDate: '',
    endDate: '',
    divisions: [] as string[],
    venues: [] as string[],
    avoidBackToBack: true,
    minDaysBetweenGames: 3,
    preferredGameTimes: ['morning', 'afternoon']
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [venuesData, gamesData, divisionsData] = await Promise.all([
        databaseService.getCollection<Venue>('venues'),
        databaseService.getCollection<Game>('games', [orderBy('date', 'asc')]),
        databaseService.getCollection<Division>('divisions')
      ]);
      setVenues(venuesData);
      setGames(gamesData);
      setDivisions(divisionsData);
    } catch (error) {
      console.error('Error loading schedule data:', error);
    }
    setLoading(false);
  };

  const generateSchedule = async () => {
    setGenerating(true);
    try {
      const schedule = await generateRoundRobinSchedule(
        scheduleParams.divisions,
        venues.filter(v => scheduleParams.venues.includes(v.id)),
        new Date(scheduleParams.startDate),
        new Date(scheduleParams.endDate)
      );

      const batch = schedule.map(game => ({
        type: 'create' as const,
        collection: 'games',
        id: `game_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        data: game
      }));

      await databaseService.batchWrite(batch);
      await loadData();
      setShowGenerateModal(false);
    } catch (error) {
      console.error('Error generating schedule:', error);
    }
    setGenerating(false);
  };

  const generateRoundRobinSchedule = async (
    divisionIds: string[],
    selectedVenues: Venue[],
    startDate: Date,
    endDate: Date
  ): Promise<Partial<Game>[]> => {
    const schedule: Partial<Game>[] = [];
    
    for (const divisionId of divisionIds) {
      const division = divisions.find(d => d.id === divisionId);
      if (!division) continue;

      const teams = division.teams;
      const n = teams.length;
      
      if (n < 2) continue;

      const rounds: [number, number][][] = [];
      const isOdd = n % 2 !== 0;
      const teamCount = isOdd ? n + 1 : n;
      
      for (let round = 0; round < teamCount - 1; round++) {
        const roundGames: [number, number][] = [];
        
        for (let i = 0; i < teamCount / 2; i++) {
          const home = (round + i) % (teamCount - 1);
          const away = (teamCount - 1 - i + round) % (teamCount - 1);
          
          if (i === 0) {
            roundGames.push([teamCount - 1, away]);
          } else {
            roundGames.push([home, away]);
          }
        }
        
        rounds.push(roundGames.filter(([h, a]) => h < n && a < n));
      }

      let currentDate = new Date(startDate);
      let venueIndex = 0;
      
      for (const round of rounds) {
        for (const [homeIndex, awayIndex] of round) {
          if (currentDate > endDate) break;

          const venue = selectedVenues[venueIndex % selectedVenues.length];
          const game: Partial<Game> = {
            homeTeam: teams[homeIndex],
            homeTeamId: teams[homeIndex],
            awayTeam: teams[awayIndex],
            awayTeamId: teams[awayIndex],
            date: currentDate.toISOString().split('T')[0],
            time: '10:00',
            venue: venue.name,
            venueId: venue.id,
            court: 1,
            division: division.name,
            status: 'scheduled',
            officials: []
          };
          
          schedule.push(game);
          venueIndex++;
        }
        
        currentDate.setDate(currentDate.getDate() + 7);
      }
    }
    
    return schedule;
  };

  const handleAddVenue = async () => {
    try {
      await databaseService.createDocument('venues', null, newVenue);
      await loadData();
      setShowVenueModal(false);
      setNewVenue({
        name: '',
        address: '',
        courts: 1,
        availability: {
          saturday: { start: '08:00', end: '20:00', courts: [1] },
          sunday: { start: '08:00', end: '18:00', courts: [1] }
        },
        blocked: []
      });
    } catch (error) {
      console.error('Error adding venue:', error);
    }
  };

  const handleDeleteGame = async (gameId: string) => {
    try {
      await databaseService.deleteDocument('games', gameId);
      await loadData();
    } catch (error) {
      console.error('Error deleting game:', error);
    }
  };

  const exportSchedule = () => {
    const csv = [
      ['Date', 'Time', 'Division', 'Home Team', 'Away Team', 'Venue', 'Court'],
      ...games.map(g => [
        g.date,
        g.time,
        g.division,
        g.homeTeam,
        g.awayTeam,
        g.venue,
        g.court
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `schedule_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const getWeekGames = () => {
    const today = new Date();
    const weekStart = new Date(today);
    weekStart.setDate(today.getDate() - today.getDay() + (selectedWeek * 7));
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);

    return games.filter(game => {
      const gameDate = new Date(game.date);
      return gameDate >= weekStart && gameDate <= weekEnd;
    }).filter(game => selectedDivision === 'all' || game.division === selectedDivision);
  };

  const groupGamesByDate = (games: Game[]) => {
    const grouped: { [date: string]: Game[] } = {};
    games.forEach(game => {
      if (!grouped[game.date]) {
        grouped[game.date] = [];
      }
      grouped[game.date].push(game);
    });
    return grouped;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  const weekGames = getWeekGames();
  const groupedGames = groupGamesByDate(weekGames);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Schedule Generator</h2>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={exportSchedule}>
            <Download className="h-4 w-4 mr-2" />
            Export Schedule
          </Button>
          <Button variant="primary" size="sm" onClick={() => setShowGenerateModal(true)}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Generate Schedule
          </Button>
        </div>
      </div>

      {/* Venue Management */}
      <Card variant="navy">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-white">Venues</CardTitle>
            <Button size="sm" variant="primary" onClick={() => setShowVenueModal(true)}>
              <Plus className="h-4 w-4 mr-1" />
              Add Venue
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {venues.map(venue => (
              <div key={venue.id} className="p-4 bg-navy-800 rounded-lg">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-semibold text-white">{venue.name}</h4>
                    <p className="text-sm text-gray-400">{venue.address}</p>
                  </div>
                  <Badge variant="secondary">{venue.courts} Courts</Badge>
                </div>
                <div className="text-sm text-gray-400">
                  <p>Saturday: {venue.availability.saturday?.start} - {venue.availability.saturday?.end}</p>
                  <p>Sunday: {venue.availability.sunday?.start} - {venue.availability.sunday?.end}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Week Navigation & Filters */}
      <Card variant="navy">
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedWeek(selectedWeek - 1)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-white font-semibold">
                Week of {new Date(Date.now() + selectedWeek * 7 * 24 * 60 * 60 * 1000).toLocaleDateString()}
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedWeek(selectedWeek + 1)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <select
              value={selectedDivision}
              onChange={(e) => setSelectedDivision(e.target.value)}
              className="px-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white"
            >
              <option value="all">All Divisions</option>
              {divisions.map(div => (
                <option key={div.id} value={div.name}>{div.name}</option>
              ))}
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Schedule Grid */}
      <div className="space-y-4">
        {Object.entries(groupedGames).map(([date, dayGames]) => (
          <Card key={date} variant="navy">
            <CardHeader>
              <CardTitle className="text-white">
                {new Date(date).toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {dayGames.sort((a, b) => a.time.localeCompare(b.time)).map(game => (
                  <div key={game.id} className="p-4 bg-navy-800 rounded-lg">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center gap-4">
                        <div className="text-center">
                          <p className="text-sm text-gray-400">Time</p>
                          <p className="font-semibold text-white">{game.time}</p>
                        </div>
                        <div>
                          <Badge variant="secondary" className="mb-1">{game.division}</Badge>
                          <p className="font-semibold text-white">
                            {game.homeTeam} vs {game.awayTeam}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-sm text-gray-400">
                            <MapPin className="inline h-3 w-3 mr-1" />
                            {game.venue}
                          </p>
                          <p className="text-sm text-gray-400">Court {game.court}</p>
                        </div>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => handleDeleteGame(game.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
        {Object.keys(groupedGames).length === 0 && (
          <Card variant="navy">
            <CardContent className="p-12 text-center">
              <Calendar className="h-12 w-12 text-gray-500 mx-auto mb-4" />
              <p className="text-gray-400">No games scheduled for this week</p>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Add Venue Modal */}
      {showVenueModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card variant="navy" className="max-w-md w-full">
            <CardHeader>
              <CardTitle className="text-white">Add New Venue</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Venue Name
                  </label>
                  <input
                    type="text"
                    value={newVenue.name}
                    onChange={(e) => setNewVenue({...newVenue, name: e.target.value})}
                    className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Address
                  </label>
                  <input
                    type="text"
                    value={newVenue.address}
                    onChange={(e) => setNewVenue({...newVenue, address: e.target.value})}
                    className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Number of Courts
                  </label>
                  <input
                    type="number"
                    value={newVenue.courts}
                    onChange={(e) => setNewVenue({...newVenue, courts: parseInt(e.target.value)})}
                    className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                  />
                </div>
                <div className="flex gap-2">
                  <Button variant="primary" className="flex-1" onClick={handleAddVenue}>
                    Add Venue
                  </Button>
                  <Button variant="outline" className="flex-1" onClick={() => setShowVenueModal(false)}>
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Generate Schedule Modal */}
      {showGenerateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card variant="navy" className="max-w-2xl w-full">
            <CardHeader>
              <CardTitle className="text-white">Generate New Schedule</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">
                      Start Date
                    </label>
                    <input
                      type="date"
                      value={scheduleParams.startDate}
                      onChange={(e) => setScheduleParams({...scheduleParams, startDate: e.target.value})}
                      className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-1">
                      End Date
                    </label>
                    <input
                      type="date"
                      value={scheduleParams.endDate}
                      onChange={(e) => setScheduleParams({...scheduleParams, endDate: e.target.value})}
                      className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white"
                    />
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Select Divisions
                  </label>
                  <div className="space-y-2">
                    {divisions.map(div => (
                      <label key={div.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={scheduleParams.divisions.includes(div.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setScheduleParams({
                                ...scheduleParams,
                                divisions: [...scheduleParams.divisions, div.id]
                              });
                            } else {
                              setScheduleParams({
                                ...scheduleParams,
                                divisions: scheduleParams.divisions.filter(d => d !== div.id)
                              });
                            }
                          }}
                          className="rounded border-gray-600"
                        />
                        <span className="text-white">{div.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Select Venues
                  </label>
                  <div className="space-y-2">
                    {venues.map(venue => (
                      <label key={venue.id} className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={scheduleParams.venues.includes(venue.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setScheduleParams({
                                ...scheduleParams,
                                venues: [...scheduleParams.venues, venue.id]
                              });
                            } else {
                              setScheduleParams({
                                ...scheduleParams,
                                venues: scheduleParams.venues.filter(v => v !== venue.id)
                              });
                            }
                          }}
                          className="rounded border-gray-600"
                        />
                        <span className="text-white">{venue.name}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="flex gap-2">
                  <Button 
                    variant="primary" 
                    className="flex-1" 
                    onClick={generateSchedule}
                    disabled={generating}
                  >
                    {generating ? 'Generating...' : 'Generate Schedule'}
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex-1" 
                    onClick={() => setShowGenerateModal(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default ScheduleGenerator;