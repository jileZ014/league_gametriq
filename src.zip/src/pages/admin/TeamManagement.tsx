import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  Users, UserPlus, Shield, Mail, Phone, 
  CheckCircle, XCircle, Clock, Search, Filter,
  Edit, Trash2, Eye, Download, ChevronDown
} from 'lucide-react';
import { databaseService } from '../../services/DatabaseService';
import { where, orderBy } from 'firebase/firestore';

interface Team {
  id: string;
  name: string;
  division: string;
  coachId: string;
  coachName: string;
  players: Player[];
  status: 'pending' | 'approved' | 'suspended';
  registrationDate: string;
  approvalDate?: string;
  maxPlayers: number;
  fees: {
    total: number;
    paid: number;
    outstanding: number;
  };
}

interface Player {
  id: string;
  name: string;
  email: string;
  phone: string;
  parentName: string;
  parentEmail: string;
  parentPhone: string;
  dateOfBirth: string;
  jerseyNumber: number;
  position: string;
  status: 'active' | 'inactive' | 'injured';
  medicalClearance: boolean;
  waiverSigned: boolean;
}

export const TeamManagement: React.FC = () => {
  const [teams, setTeams] = useState<Team[]>([]);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'approved' | 'suspended'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showPlayerModal, setShowPlayerModal] = useState(false);

  useEffect(() => {
    loadTeams();
  }, []);

  const loadTeams = async () => {
    setLoading(true);
    try {
      const constraints = [orderBy('registrationDate', 'desc')];
      const teamsData = await databaseService.getCollection<Team>('teams', constraints);
      setTeams(teamsData);
    } catch (error) {
      console.error('Error loading teams:', error);
    }
    setLoading(false);
  };

  const handleApproveTeam = async (teamId: string) => {
    try {
      await databaseService.updateDocument('teams', teamId, {
        status: 'approved',
        approvalDate: new Date().toISOString()
      });
      await loadTeams();
    } catch (error) {
      console.error('Error approving team:', error);
    }
  };

  const handleRejectTeam = async (teamId: string) => {
    try {
      await databaseService.updateDocument('teams', teamId, {
        status: 'suspended'
      });
      await loadTeams();
    } catch (error) {
      console.error('Error rejecting team:', error);
    }
  };

  const handleExportRoster = (team: Team) => {
    const csv = [
      ['Team', 'Player Name', 'Jersey #', 'Position', 'Parent Name', 'Parent Email', 'Parent Phone'],
      ...team.players.map(p => [
        team.name,
        p.name,
        p.jerseyNumber,
        p.position,
        p.parentName,
        p.parentEmail,
        p.parentPhone
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${team.name.replace(/\s+/g, '_')}_roster.csv`;
    a.click();
  };

  const filteredTeams = teams.filter(team => {
    const matchesFilter = filter === 'all' || team.status === filter;
    const matchesSearch = team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          team.coachName.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge variant="success">Approved</Badge>;
      case 'pending':
        return <Badge variant="warning">Pending</Badge>;
      case 'suspended':
        return <Badge variant="danger">Suspended</Badge>;
      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-white">Team Management</h2>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export All
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Teams</p>
                <p className="text-3xl font-bold text-white">{teams.length}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Pending Approval</p>
                <p className="text-3xl font-bold text-white">
                  {teams.filter(t => t.status === 'pending').length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Approved</p>
                <p className="text-3xl font-bold text-white">
                  {teams.filter(t => t.status === 'approved').length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Players</p>
                <p className="text-3xl font-bold text-white">
                  {teams.reduce((sum, t) => sum + (t.players?.length || 0), 0)}
                </p>
              </div>
              <Shield className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card variant="navy">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <input
                type="text"
                placeholder="Search teams or coaches..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-navy-800 border border-navy-700 rounded-lg text-white placeholder-gray-400"
              />
            </div>
            <div className="flex gap-2">
              {(['all', 'pending', 'approved', 'suspended'] as const).map(status => (
                <Button
                  key={status}
                  size="sm"
                  variant={filter === status ? 'primary' : 'outline'}
                  onClick={() => setFilter(status)}
                >
                  {status.charAt(0).toUpperCase() + status.slice(1)}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Teams List */}
      <div className="space-y-4">
        {filteredTeams.map(team => (
          <Card key={team.id} variant="navy">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-semibold text-white">{team.name}</h3>
                    {getStatusBadge(team.status)}
                  </div>
                  <div className="space-y-1 text-sm text-gray-400">
                    <p>Coach: {team.coachName}</p>
                    <p>Division: {team.division}</p>
                    <p>Players: {team.players?.length || 0} / {team.maxPlayers}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-400 mb-1">Registration Fee</p>
                  <p className="text-2xl font-bold text-white">${team.fees?.total || 0}</p>
                  {team.fees?.outstanding > 0 && (
                    <p className="text-sm text-red-400">
                      ${team.fees.outstanding} outstanding
                    </p>
                  )}
                </div>
              </div>

              {/* Player Preview */}
              {team.players && team.players.length > 0 && (
                <div className="mb-4 p-3 bg-navy-800 rounded-lg">
                  <p className="text-sm text-gray-400 mb-2">Recent Players:</p>
                  <div className="flex flex-wrap gap-2">
                    {team.players.slice(0, 5).map(player => (
                      <Badge key={player.id} variant="secondary">
                        #{player.jerseyNumber} {player.name}
                      </Badge>
                    ))}
                    {team.players.length > 5 && (
                      <Badge variant="outline">+{team.players.length - 5} more</Badge>
                    )}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex flex-wrap gap-2">
                {team.status === 'pending' && (
                  <>
                    <Button
                      size="sm"
                      variant="success"
                      onClick={() => handleApproveTeam(team.id)}
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                    <Button
                      size="sm"
                      variant="danger"
                      onClick={() => handleRejectTeam(team.id)}
                    >
                      <XCircle className="h-4 w-4 mr-1" />
                      Reject
                    </Button>
                  </>
                )}
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => setSelectedTeam(team)}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  View Details
                </Button>
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={() => handleExportRoster(team)}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Export Roster
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                >
                  <Mail className="h-4 w-4 mr-1" />
                  Contact Coach
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Team Details Modal */}
      {selectedTeam && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <Card variant="navy" className="max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-white">{selectedTeam.name} - Full Roster</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedTeam(null)}
                >
                  <XCircle className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {selectedTeam.players?.map(player => (
                  <div key={player.id} className="p-4 bg-navy-800 rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <h4 className="font-semibold text-white">
                          #{player.jerseyNumber} {player.name}
                        </h4>
                        <p className="text-sm text-gray-400">{player.position}</p>
                        <div className="mt-2 space-y-1 text-sm text-gray-400">
                          <p>Parent: {player.parentName}</p>
                          <p>Email: {player.parentEmail}</p>
                          <p>Phone: {player.parentPhone}</p>
                        </div>
                      </div>
                      <div className="flex flex-col gap-1">
                        {player.medicalClearance && (
                          <Badge variant="success">Medical Cleared</Badge>
                        )}
                        {player.waiverSigned && (
                          <Badge variant="success">Waiver Signed</Badge>
                        )}
                        <Badge variant={player.status === 'active' ? 'success' : 'warning'}>
                          {player.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                )) || <p className="text-gray-400">No players registered yet</p>}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TeamManagement;