import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { 
  ArrowLeft, Calendar, Clock, MapPin, Users, 
  AlertCircle, Check, RefreshCw, Settings, Play,
  Save, FileText, Download
} from 'lucide-react';
import { db } from '../../firebase';
import { collection, query, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';

interface Team {
  id: string;
  name: string;
  division: string;
}

interface Venue {
  id: string;
  name: string;
  courts: number;
  address: string;
}

interface GameSlot {
  date: string;
  time: string;
  venue: string;
  court: number;
  homeTeam: string;
  awayTeam: string;
  division: string;
}

export const ScheduleGeneratorFixed: React.FC = () => {
  const navigate = useNavigate();
  const [teams, setTeams] = useState<Team[]>([]);
  const [venues, setVenues] = useState<Venue[]>([]);
  const [selectedDivision, setSelectedDivision] = useState<string>('');
  const [divisions, setDivisions] = useState<string[]>([]);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [gameTime, setGameTime] = useState<string>('10:00');
  const [gameDuration, setGameDuration] = useState<number>(60);
  const [selectedVenues, setSelectedVenues] = useState<string[]>([]);
  const [schedule, setSchedule] = useState<GameSlot[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // Load teams
      const teamsSnapshot = await getDocs(collection(db, 'teams'));
      const teamsData = teamsSnapshot.docs
        .map(doc => ({
          id: doc.id,
          ...doc.data()
        } as Team))
        .filter(team => team.name); // Filter out invalid teams

      // Load venues
      const venuesSnapshot = await getDocs(collection(db, 'venues'));
      const venuesData = venuesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Venue));

      // Extract unique divisions
      const uniqueDivisions = [...new Set(teamsData.map(t => t.division))].filter(Boolean);

      setTeams(teamsData);
      setVenues(venuesData);
      setDivisions(uniqueDivisions);
      
      // Set defaults
      if (uniqueDivisions.length > 0) {
        setSelectedDivision(uniqueDivisions[0]);
      }
      
      // Set default dates (next Saturday to 10 weeks out)
      const today = new Date();
      const nextSaturday = new Date(today);
      nextSaturday.setDate(today.getDate() + ((6 - today.getDay()) % 7 || 7));
      const tenWeeksLater = new Date(nextSaturday);
      tenWeeksLater.setDate(nextSaturday.getDate() + 70);
      
      setStartDate(nextSaturday.toISOString().split('T')[0]);
      setEndDate(tenWeeksLater.toISOString().split('T')[0]);
      
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateRoundRobin = () => {
    if (!selectedDivision || selectedVenues.length === 0) {
      alert('Please select a division and at least one venue');
      return;
    }

    setGenerating(true);
    
    // Filter teams by division
    const divisionTeams = teams.filter(t => t.division === selectedDivision);
    
    if (divisionTeams.length < 2) {
      alert('Need at least 2 teams to generate schedule');
      setGenerating(false);
      return;
    }

    const games: GameSlot[] = [];
    const startDateObj = new Date(startDate);
    const endDateObj = new Date(endDate);
    
    // Generate round-robin matchups
    const matchups: Array<[Team, Team]> = [];
    for (let i = 0; i < divisionTeams.length; i++) {
      for (let j = i + 1; j < divisionTeams.length; j++) {
        matchups.push([divisionTeams[i], divisionTeams[j]]);
      }
    }

    // Calculate games per week
    const totalWeeks = Math.ceil((endDateObj.getTime() - startDateObj.getTime()) / (7 * 24 * 60 * 60 * 1000));
    const gamesPerWeek = Math.ceil(matchups.length / totalWeeks);
    
    let currentDate = new Date(startDateObj);
    let matchupIndex = 0;
    let venueIndex = 0;
    
    while (matchupIndex < matchups.length && currentDate <= endDateObj) {
      // Only schedule on Saturdays
      if (currentDate.getDay() === 6) {
        let timeSlot = new Date(currentDate);
        const [hours, minutes] = gameTime.split(':').map(Number);
        timeSlot.setHours(hours, minutes, 0, 0);
        
        // Schedule games for this Saturday
        for (let g = 0; g < gamesPerWeek && matchupIndex < matchups.length; g++) {
          const venue = venues.find(v => v.id === selectedVenues[venueIndex % selectedVenues.length]);
          if (!venue) continue;
          
          const [home, away] = matchups[matchupIndex];
          const court = (g % venue.courts) + 1;
          
          games.push({
            date: currentDate.toISOString().split('T')[0],
            time: `${timeSlot.getHours().toString().padStart(2, '0')}:${timeSlot.getMinutes().toString().padStart(2, '0')}`,
            venue: venue.name,
            court: court,
            homeTeam: home.name,
            awayTeam: away.name,
            division: selectedDivision
          });
          
          matchupIndex++;
          
          // Move to next time slot if courts are full
          if ((g + 1) % venue.courts === 0) {
            timeSlot.setMinutes(timeSlot.getMinutes() + gameDuration);
          }
          
          venueIndex++;
        }
      }
      
      currentDate.setDate(currentDate.getDate() + 1);
    }
    
    setSchedule(games);
    setGenerating(false);
  };

  const saveSchedule = async () => {
    if (schedule.length === 0) {
      alert('No schedule to save');
      return;
    }

    try {
      // Save each game to database
      for (const game of schedule) {
        await addDoc(collection(db, 'games'), {
          homeTeamName: game.homeTeam,
          awayTeamName: game.awayTeam,
          date: game.date,
          time: game.time,
          venue: game.venue,
          venueName: game.venue,
          courtNumber: game.court,
          division: game.division,
          status: 'scheduled',
          homeScore: 0,
          awayScore: 0,
          createdAt: serverTimestamp(),
          createdBy: 'Schedule Generator'
        });
      }
      
      alert(`Successfully saved ${schedule.length} games to the database!`);
      setSchedule([]);
    } catch (error) {
      console.error('Error saving schedule:', error);
      alert('Error saving schedule. Please try again.');
    }
  };

  const exportSchedule = () => {
    if (schedule.length === 0) return;
    
    // Create CSV content
    const headers = ['Date', 'Time', 'Venue', 'Court', 'Home Team', 'Away Team', 'Division'];
    const rows = schedule.map(g => [
      g.date, g.time, g.venue, g.court, g.homeTeam, g.awayTeam, g.division
    ]);
    
    const csvContent = [
      headers.join(','),
      ...rows.map(r => r.join(','))
    ].join('\n');
    
    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `schedule-${selectedDivision}-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-950 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-navy-950 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="glass-panel p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                onClick={() => navigate('/dashboard')}
                variant="ghost"
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
              <div>
                <h1 className="text-3xl font-display font-bold text-gradient">
                  Schedule Generator
                </h1>
                <p className="text-gray-400 mt-1">Create round-robin game schedules</p>
              </div>
            </div>
            <div className="h-12 w-12 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
              <Calendar className="h-8 w-8 text-white" />
            </div>
          </div>
        </div>

        {/* Configuration */}
        <Card className="glass-panel">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <Settings className="h-5 w-5 mr-2" />
              Schedule Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Division Selection */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Division</label>
              <select
                value={selectedDivision}
                onChange={(e) => setSelectedDivision(e.target.value)}
                className="glass-input w-full text-white"
              >
                <option value="">Select Division</option>
                {divisions.map(div => (
                  <option key={div} value={div}>{div}</option>
                ))}
              </select>
            </div>

            {/* Date Range */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Start Date</label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">End Date</label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="glass-input w-full text-white"
                />
              </div>
            </div>

            {/* Time Settings */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Game Start Time</label>
                <input
                  type="time"
                  value={gameTime}
                  onChange={(e) => setGameTime(e.target.value)}
                  className="glass-input w-full text-white"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Game Duration (minutes)</label>
                <input
                  type="number"
                  value={gameDuration}
                  onChange={(e) => setGameDuration(parseInt(e.target.value))}
                  className="glass-input w-full text-white"
                  min="30"
                  max="120"
                />
              </div>
            </div>

            {/* Venue Selection */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Venues</label>
              <div className="space-y-2">
                {venues.map(venue => (
                  <label key={venue.id} className="flex items-center gap-3 p-3 glass-panel cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedVenues.includes(venue.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedVenues([...selectedVenues, venue.id]);
                        } else {
                          setSelectedVenues(selectedVenues.filter(v => v !== venue.id));
                        }
                      }}
                      className="rounded border-gray-600"
                    />
                    <div className="flex-1">
                      <p className="text-white font-medium">{venue.name}</p>
                      <p className="text-sm text-gray-400">
                        <MapPin className="inline h-3 w-3 mr-1" />
                        {venue.address} • {venue.courts} courts
                      </p>
                    </div>
                  </label>
                ))}
              </div>
            </div>

            {/* Generate Button */}
            <div className="flex gap-3">
              <Button
                onClick={generateRoundRobin}
                disabled={generating}
                className="glass-button bg-green-500/20 hover:bg-green-500/30 text-white"
              >
                {generating ? (
                  <>
                    <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5 mr-2" />
                    Generate Schedule
                  </>
                )}
              </Button>
              
              {schedule.length > 0 && (
                <>
                  <Button
                    onClick={saveSchedule}
                    className="glass-button bg-blue-500/20 hover:bg-blue-500/30 text-white"
                  >
                    <Save className="h-5 w-5 mr-2" />
                    Save to Database
                  </Button>
                  <Button
                    onClick={exportSchedule}
                    className="glass-button text-white"
                  >
                    <Download className="h-5 w-5 mr-2" />
                    Export CSV
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Generated Schedule Preview */}
        {schedule.length > 0 && (
          <Card className="glass-panel">
            <CardHeader>
              <CardTitle className="text-white flex items-center justify-between">
                <span className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  Generated Schedule
                </span>
                <Badge className="glass-badge border-green-500/50">
                  {schedule.length} games
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-700">
                      <th className="text-left p-2 text-gray-400">Date</th>
                      <th className="text-left p-2 text-gray-400">Time</th>
                      <th className="text-left p-2 text-gray-400">Venue</th>
                      <th className="text-left p-2 text-gray-400">Court</th>
                      <th className="text-left p-2 text-gray-400">Home Team</th>
                      <th className="text-left p-2 text-gray-400">Away Team</th>
                    </tr>
                  </thead>
                  <tbody>
                    {schedule.slice(0, 20).map((game, index) => (
                      <tr key={index} className="border-b border-gray-800">
                        <td className="p-2 text-white">
                          {new Date(game.date).toLocaleDateString()}
                        </td>
                        <td className="p-2 text-white">{game.time}</td>
                        <td className="p-2 text-white">{game.venue}</td>
                        <td className="p-2 text-white">Court {game.court}</td>
                        <td className="p-2 text-white">{game.homeTeam}</td>
                        <td className="p-2 text-white">{game.awayTeam}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {schedule.length > 20 && (
                  <p className="text-center text-gray-400 mt-4">
                    Showing first 20 of {schedule.length} games
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default ScheduleGeneratorFixed;