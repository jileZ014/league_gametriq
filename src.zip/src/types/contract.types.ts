// CONTRACT-SPECIFIC TYPES FOR YOUTH BASKETBALL LEAGUE MANAGEMENT SYSTEM
// CRITICAL: These types match the exact contract requirements

export interface ContractGame {
  id: string;
  homeTeamId: string;
  awayTeamId: string;
  homeTeamName: string;
  awayTeamName: string;
  homeScore: number;
  awayScore: number;
  date: string;
  time: string;
  venue: string;
  venueId: string;
  division: string;
  status: 'scheduled' | 'in_progress' | 'completed' | 'postponed' | 'forfeited';
  courtNumber?: number;
  officials?: string[];
  scorekeeper?: string;
  incidentReports?: string[];
  lastUpdated: string;
  finalizedAt?: string;
  finalizedBy?: string;
}

export interface ContractTeam {
  id: string;
  name: string;
  division: string;
  coachId: string;
  coachName: string;
  wins: number;
  losses: number;
  pointsFor: number;
  pointsAgainst: number;
  winPercentage: number;
  gamesPlayed: number;
  gamesBack?: number;
  streak: string;
  lastFive: string;
  roster: ContractPlayer[];
  status: 'pending' | 'approved' | 'rejected' | 'suspended';
  approvedBy?: string;
  approvedAt?: string;
  registrationFee: number;
  feePaid: boolean;
  paymentDate?: string;
}

export interface ContractPlayer {
  id: string;
  name: string;
  jerseyNumber: string;
  dateOfBirth: string;
  age: number;
  parentName: string;
  emergencyContact: EmergencyContact;
  medicalInfo?: string;
  photoUrl?: string;
  eligibilityStatus: 'eligible' | 'ineligible' | 'pending';
  teamId: string;
}

export interface EmergencyContact {
  name: string;
  relationship: string;
  primaryPhone: string;
  alternatePhone?: string;
  email?: string;
}

export interface ContractVenue {
  id: string;
  name: string;
  address: string;
  courts: number;
  availability: VenueAvailability[];
  contactPerson: string;
  contactPhone: string;
  parkingInfo?: string;
  directions?: string;
}

export interface VenueAvailability {
  dayOfWeek: number; // 0-6 (Sunday-Saturday)
  startTime: string;
  endTime: string;
  courts: number[];
}

export interface ContractDivision {
  id: string;
  name: string;
  ageMin: number;
  ageMax: number;
  skillLevel: 'beginner' | 'intermediate' | 'advanced' | 'elite';
  maxTeams: number;
  currentTeams: number;
  playoffFormat: 'single-elimination' | 'double-elimination' | 'round-robin';
  playoffTeams: number;
}

export interface ContractIncident {
  id: string;
  gameId: string;
  reportedBy: string;
  reportedByRole: string;
  incidentType: 'technical' | 'ejection' | 'injury' | 'conduct' | 'facility' | 'other';
  description: string;
  involvedParties: string[];
  timestamp: string;
  photos?: string[];
  status: 'pending' | 'reviewed' | 'resolved';
  resolvedBy?: string;
  resolution?: string;
  resolvedAt?: string;
}

export interface ContractInvoice {
  id: string;
  teamId: string;
  teamName: string;
  amount: number;
  dueDate: string;
  status: 'pending' | 'paid' | 'overdue' | 'cancelled';
  items: InvoiceItem[];
  payments: Payment[];
  createdAt: string;
  paidAt?: string;
}

export interface InvoiceItem {
  description: string;
  amount: number;
  quantity: number;
  total: number;
}

export interface Payment {
  id: string;
  amount: number;
  method: 'cash' | 'check' | 'card' | 'online';
  reference?: string;
  date: string;
  processedBy: string;
}

export interface ContractStaff {
  id: string;
  name: string;
  role: 'referee' | 'scorekeeper' | 'site_manager' | 'coordinator';
  email: string;
  phone: string;
  availability: StaffAvailability[];
  assignedGames: string[];
  checkedIn: boolean;
  checkInTime?: string;
}

export interface StaffAvailability {
  date: string;
  startTime: string;
  endTime: string;
  venueId?: string;
}

export interface ContractScheduleRequest {
  divisions: string[];
  startDate: string;
  endDate: string;
  venues: string[];
  blackoutDates: string[];
  gameLength: number;
  bufferTime: number;
  maxGamesPerDay: number;
  minDaysBetweenGames: number;
}

export interface ContractStanding {
  teamId: string;
  teamName: string;
  division: string;
  wins: number;
  losses: number;
  winPercentage: number;
  gamesBack: number;
  pointsFor: number;
  pointsAgainst: number;
  differential: number;
  streak: string;
  lastFive: string;
  position: number;
  playoffSeed?: number;
  clinched?: 'division' | 'playoff' | 'eliminated';
}

export interface ContractTestResult {
  id: string;
  testName: string;
  category: string;
  status: 'pass' | 'fail' | 'skip';
  message?: string;
  timestamp: string;
  duration: number;
  validator: string;
  screenshot?: string;
  errorDetails?: any;
}

export interface ContractVerification {
  feature: string;
  tested: boolean;
  passed: boolean;
  testedBy: string;
  testedAt: string;
  bugs: string[];
  notes?: string;
  signature?: string;
}