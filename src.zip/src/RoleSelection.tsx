import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Button } from './components/ui/button';
import { 
  Users, Shield, Activity, UserCheck, User, Flag,
  Trophy, ChevronRight, Building
} from 'lucide-react';
import { db } from './firebase';
import { doc, updateDoc, collection, getDocs, writeBatch, query, where } from 'firebase/firestore';
import { useAuth } from './AuthContext';
import type { UserRole } from './types';
import { leagueConfig } from './config/league.config';

interface RoleOption {
  role: UserRole;
  title: string;
  description: string;
  icon: React.ElementType;
  color: string;
}

const roleOptions: RoleOption[] = [
  {
    role: 'admin',
    title: 'Administrator',
    description: 'Oversee the entire league, manage users, and configure settings',
    icon: Shield,
    color: 'from-purple-500 to-purple-600'
  },
  {
    role: 'sitedirector' as UserRole,
    title: 'Site Director',
    description: 'Manage venue operations, staff assignments, and game logistics',
    icon: Building,
    color: 'from-amber-500 to-amber-600'
  },
  {
    role: 'coach',
    title: 'Coach',
    description: 'Manage teams, schedule practices, and track player performance',
    icon: Trophy,
    color: 'from-blue-500 to-blue-600'
  },
  {
    role: 'scorekeeper',
    title: 'Scorekeeper',
    description: 'Track live game scores and manage game statistics',
    icon: Activity,
    color: 'from-red-500 to-red-600'
  }
];

export const RoleSelection: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [selectedRole, setSelectedRole] = useState<UserRole | null>(null);
  const [loading, setLoading] = useState(false);

  const handleRoleSelection = async () => {
    if (!selectedRole || !currentUser) return;

    setLoading(true);
    try {
      // Check if this is the first admin in the system
      if (selectedRole === 'admin') {
        const adminsQuery = query(collection(db, 'users'), where('role', '==', 'admin'));
        const adminSnapshot = await getDocs(adminsQuery);
        
        // If no other admins exist, this is the first admin
        if (adminSnapshot.empty) {
          console.log('First admin detected - clearing all data for fresh start');
          
          // Collections to clear (excluding 'users')
          const collectionsToReset = [
            'teams', 'players', 'games', 'schedules', 'standings',
            'statistics', 'venues', 'divisions', 'seasons', 'payments',
            'messages', 'incidents', 'certifications', 'rosters',
            'scoresheets', 'notifications', 'leagues', 'playerStats',
            'teamStats', 'gameStats', 'brackets'
          ];
          
          // Clear each collection
          for (const collectionName of collectionsToReset) {
            try {
              const collectionRef = collection(db, collectionName);
              const snapshot = await getDocs(collectionRef);
              
              if (!snapshot.empty) {
                const batch = writeBatch(db);
                let count = 0;
                
                snapshot.forEach((doc) => {
                  batch.delete(doc.ref);
                  count++;
                  
                  // Firestore batch limit is 500
                  if (count >= 500) {
                    batch.commit();
                    count = 0;
                  }
                });
                
                if (count > 0) {
                  await batch.commit();
                }
                
                console.log(`Cleared ${collectionName}: ${snapshot.size} documents`);
              }
            } catch (error) {
              console.log(`Collection ${collectionName} might not exist, skipping`);
            }
          }
          
          // Mark this admin as the initial setup admin
          await updateDoc(doc(db, 'users', currentUser.uid), {
            role: selectedRole,
            roleSelectedAt: new Date().toISOString(),
            isInitialSetupAdmin: true,
            setupCompletedAt: new Date().toISOString()
          });
        } else {
          // Not the first admin, just update role normally
          await updateDoc(doc(db, 'users', currentUser.uid), {
            role: selectedRole,
            roleSelectedAt: new Date().toISOString()
          });
        }
      } else {
        // Non-admin role, update normally
        await updateDoc(doc(db, 'users', currentUser.uid), {
          role: selectedRole,
          roleSelectedAt: new Date().toISOString()
        });
      }

      // Force a page reload to update the auth context
      window.location.href = '/dashboard';
    } catch (error) {
      console.error('Error updating role:', error);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black" />
      <div className="max-w-4xl w-full relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-8"
        >
          <div className="h-16 w-16 mx-auto mb-4 bg-gradient-to-r from-green-500 to-cyan-500 rounded-full flex items-center justify-center">
            <Trophy className="h-10 w-10 text-white" />
          </div>
          <h1 className="text-4xl font-display font-bold text-gradient mb-2">
            Welcome to {leagueConfig.leagueName}
          </h1>
          <p className="text-xl text-gray-400">
            Select your role to get started
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {roleOptions.map((option, index) => {
            const Icon = option.icon;
            return (
              <motion.div
                key={option.role}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card
                  className={`glass-panel cursor-pointer transition-all ${
                    selectedRole === option.role
                      ? 'border-green-500/50 bg-white/10'
                      : 'hover:border-white/20'
                  }`}
                  onClick={() => setSelectedRole(option.role)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`w-16 h-16 bg-gradient-to-br ${option.color} rounded-2xl flex items-center justify-center mb-4`}>
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="text-lg font-semibold text-white mb-2">
                        {option.title}
                      </h3>
                      <p className="text-sm text-gray-400 mb-4">
                        {option.description}
                      </p>
                      {selectedRole === option.role && (
                        <div className="w-full h-1 bg-gradient-to-r from-green-500 to-cyan-500 rounded-full" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="text-center"
        >
          <Button
            onClick={handleRoleSelection}
            disabled={!selectedRole || loading}
            size="lg"
            className="min-w-[200px] glass-button text-white"
          >
            {loading ? 'Setting up...' : 'Continue to Dashboard'}
          </Button>
          
          <p className="text-sm text-gray-500 mt-4">
            You can change your role later in settings
          </p>
        </motion.div>
      </div>
    </div>
  );
};

export default RoleSelection;