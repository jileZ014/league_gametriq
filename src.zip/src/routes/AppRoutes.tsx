import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

// Dashboards
import AdminDashboard from '../dashboards/AdminDashboard';
import CoachDashboard from '../dashboards/CoachDashboard';
import ScorekeeperDashboard from '../dashboards/ScorekeeperDashboard';
import ParentDashboard from '../dashboards/ParentDashboard';
import PlayerDashboard from '../dashboards/PlayerDashboard';
import RefereeDashboard from '../dashboards/RefereeDashboard';

// Admin Components
import LeagueManagement from '../pages/admin/LeagueManagement';
import TeamManagement from '../pages/admin/TeamManagement';
import ScheduleGenerator from '../pages/admin/ScheduleGenerator';
import FinancialCompliance from '../pages/admin/FinancialCompliance';

// Coach Components
import PerformanceAnalytics from '../pages/coach/PerformanceAnalytics';

// Scorekeeper Components
import LiveScoring from '../pages/scorekeeper/LiveScoring';

// Shared Components
import NotificationCenter from '../components/NotificationCenter';
import NotificationPreferences from '../components/NotificationPreferences';

// Testing
import QATestSuite from '../testing/QATestSuite';

// Public Pages
import HomepageNew from '../pages/public/HomepageNew';

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRoles?: string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRoles }) => {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRoles && currentUser.role && !allowedRoles.includes(currentUser.role)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
};

export const AppRoutes: React.FC = () => {
  const { currentUser } = useAuth();

  return (
    <Routes>
      {/* Dashboard Routes */}
      <Route path="/dashboard" element={
        <ProtectedRoute>
          {currentUser?.role === 'admin' && <AdminDashboard />}
          {currentUser?.role === 'coach' && <CoachDashboard />}
          {currentUser?.role === 'scorekeeper' && <ScorekeeperDashboard />}
          {currentUser?.role === 'parent' && <ParentDashboard />}
          {currentUser?.role === 'player' && <PlayerDashboard />}
          {currentUser?.role === 'referee' && <RefereeDashboard />}
          {!currentUser?.role && <Navigate to="/setup" />}
        </ProtectedRoute>
      } />

      {/* Admin Routes */}
      <Route path="/admin/leagues" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <LeagueManagement />
        </ProtectedRoute>
      } />
      <Route path="/admin/teams" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <TeamManagement />
        </ProtectedRoute>
      } />
      <Route path="/admin/schedule" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <ScheduleGenerator />
        </ProtectedRoute>
      } />
      <Route path="/admin/financial" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <FinancialCompliance />
        </ProtectedRoute>
      } />

      {/* Coach Routes */}
      <Route path="/coach/analytics" element={
        <ProtectedRoute allowedRoles={['coach']}>
          <PerformanceAnalytics />
        </ProtectedRoute>
      } />

      {/* Scorekeeper Routes */}
      <Route path="/scorekeeper/live" element={
        <ProtectedRoute allowedRoles={['scorekeeper']}>
          <LiveScoring />
        </ProtectedRoute>
      } />

      {/* Shared Routes */}
      <Route path="/notifications" element={
        <ProtectedRoute>
          <NotificationCenter />
        </ProtectedRoute>
      } />
      <Route path="/settings/notifications" element={
        <ProtectedRoute>
          <NotificationPreferences />
        </ProtectedRoute>
      } />

      {/* QA Testing Route (Admin only) */}
      <Route path="/qa-testing" element={
        <ProtectedRoute allowedRoles={['admin']}>
          <QATestSuite />
        </ProtectedRoute>
      } />

      {/* Public Homepage - No Auth Required */}
      <Route path="/public/homepage" element={<HomepageNew />} />

      {/* Default redirect */}
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};

export default AppRoutes;