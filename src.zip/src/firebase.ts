import { initializeApp, FirebaseError } from 'firebase/app';
import { getAuth, GoogleAuthProvider, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';

// Firebase configuration - HARDCODED FOR AZ-FLIGHT-FALL-LEAGUE
// UPDATED: 2024-09-11 - CORRECT PROJECT
const firebaseConfig = {
  apiKey: "AIzaSyCE6wQEF03o0PSL2PWETDBLNUpF3EBka2o",
  authDomain: "az-flight-fall-league.firebaseapp.com",
  projectId: "az-flight-fall-league",
  storageBucket: "az-flight-fall-league.firebasestorage.app",
  messagingSenderId: "1086579388",
  appId: "1:1086579388:web:b59ea76fecf0a57744e6b9"
};

console.log("FIREBASE CONFIG:", firebaseConfig);

let app: any;
let auth: any;
let db: any;
let googleProvider: any;

try {
  // Initialize Firebase
  app = initializeApp(firebaseConfig);
  
  // Initialize Auth
  auth = getAuth(app);
  auth.useDeviceLanguage(); // Use device language for auth UI
  
  // Initialize Google Provider with additional scopes
  googleProvider = new GoogleAuthProvider();
  googleProvider.addScope('profile');
  googleProvider.addScope('email');
  googleProvider.setCustomParameters({
    prompt: 'select_account' // Always show account selection
  });
  
  // Initialize Firestore
  db = getFirestore(app);
  
  // Connect to emulators if in development (optional)
  if (process.env.NODE_ENV === 'development' && process.env.VITE_USE_EMULATORS === 'true') {
    connectAuthEmulator(auth, 'http://localhost:9099', { disableWarnings: true });
    connectFirestoreEmulator(db, 'localhost', 8080);
  }
  
  if (import.meta.env.DEV) {
    console.log('Firebase initialized successfully');
  }
} catch (error) {
  if (import.meta.env.DEV) {
    console.error('Firebase initialization error:', error);
  }
  
  // Provide helpful error messages
  if (error instanceof FirebaseError) {
    switch (error.code) {
      case 'auth/api-key-not-valid':
        if (import.meta.env.DEV) {
          console.error('Invalid API key. Please check your Firebase configuration.');
        }
        break;
      case 'auth/invalid-api-key':
        if (import.meta.env.DEV) {
          console.error('The provided API key is invalid. Please check Firebase Console.');
        }
        break;
      default:
        if (import.meta.env.DEV) {
          console.error('Firebase error:', error.message);
        }
    }
  }
}

// Error handler for auth operations
export const handleAuthError = (error: FirebaseError) => {
  if (import.meta.env.DEV) {
    console.error('Auth error:', error);
  }
  
  switch (error.code) {
    case 'auth/api-key-not-valid':
      return 'Configuration error. Please contact support.';
    case 'auth/invalid-api-key':
      return 'Invalid API key configuration.';
    case 'auth/popup-closed-by-user':
      return 'Sign in cancelled.';
    case 'auth/cancelled-popup-request':
      return 'Only one sign in window allowed at a time.';
    case 'auth/popup-blocked':
      return 'Sign in popup was blocked. Please allow popups for this site.';
    case 'auth/unauthorized-domain':
      return 'This domain is not authorized. Please contact support.';
    case 'auth/operation-not-allowed':
      return 'Google sign in is not enabled. Please contact support.';
    case 'auth/network-request-failed':
      return 'Network error. Please check your connection.';
    default:
      return error.message || 'An unexpected error occurred. Please try again.';
  }
};

export { app, auth, googleProvider, db };