import { db } from '../firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  writeBatch,
  serverTimestamp 
} from 'firebase/firestore';
import { getAuth, createUserWithEmailAndPassword } from 'firebase/auth';

interface DatabaseSchema {
  users: any[];
  teams: any[];
  players: any[];
  games: any[];
  seasons: any[];
  divisions: any[];
  venues: any[];
  standings: any[];
  emergencyContacts: any[];
  staff: any[];
  financials: any[];
}

export async function initializeDatabase() {
  console.log('🚀 INITIALIZING DATABASE WITH CONTRACT-COMPLIANT SCHEMA');
  
  const batch = writeBatch(db);
  const auth = getAuth();
  
  try {
    // Create test users for all 4 roles
    const testUsers = [
      { email: 'admin@gametriq.com', password: 'Admin123!', role: 'admin', name: 'Admin User' },
      { email: 'coach@gametriq.com', password: 'Coach123!', role: 'coach', name: 'Coach Johnson' },
      { email: 'scorekeeper@gametriq.com', password: 'Score123!', role: 'scorekeeper', name: 'Sam Scorer' },
      { email: 'sitedirector@gametriq.com', password: 'Site123!', role: 'sitedirector', name: 'Director Smith' }
    ];

    // Create authentication accounts
    for (const user of testUsers) {
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, user.email, user.password);
        
        // Add user to Firestore with role
        await setDoc(doc(db, 'users', userCredential.user.uid), {
          uid: userCredential.user.uid,
          email: user.email,
          displayName: user.name,
          role: user.role,
          createdAt: serverTimestamp(),
          status: 'active',
          phoneNumber: '555-0100',
          emergencyContact: '555-0911'
        });
        
        console.log(`✅ Created ${user.role} user: ${user.email}`);
      } catch (error: any) {
        if (error.code === 'auth/email-already-in-use') {
          console.log(`User ${user.email} already exists`);
        } else {
          console.error(`Error creating ${user.email}:`, error);
        }
      }
    }

    // Create Seasons
    const seasons = [
      {
        id: 'season-2025-winter',
        name: 'Winter 2025',
        startDate: '2025-01-01',
        endDate: '2025-03-31',
        status: 'active',
        registrationDeadline: '2024-12-15',
        divisions: ['U10', 'U12', 'U14', 'U16', 'U18']
      },
      {
        id: 'season-2025-spring',
        name: 'Spring 2025',
        startDate: '2025-04-01',
        endDate: '2025-06-30',
        status: 'upcoming',
        registrationDeadline: '2025-03-15',
        divisions: ['U10', 'U12', 'U14', 'U16', 'U18']
      }
    ];

    seasons.forEach(season => {
      batch.set(doc(db, 'seasons', season.id), season);
    });

    // Create Divisions
    const divisions = ['U10', 'U12', 'U14', 'U16', 'U18'];
    divisions.forEach(divisionName => {
      const divisionId = `div-${divisionName.toLowerCase()}`;
      batch.set(doc(db, 'divisions', divisionId), {
        id: divisionId,
        name: divisionName,
        ageRange: divisionName,
        maxTeams: 8,
        currentTeams: 4,
        rules: {
          gameLength: divisionName === 'U10' ? 32 : 40,
          quarters: 4,
          foulsLimit: 5,
          timeoutPerHalf: 3
        }
      });
    });

    // Create Venues (5+ as required)
    const venues = [
      {
        id: 'venue-phoenix-central',
        name: 'Phoenix Central Sports Complex',
        address: '123 Main St, Phoenix, AZ 85001',
        courts: 4,
        capacity: 500,
        amenities: ['Parking', 'Concessions', 'Restrooms', 'Locker Rooms'],
        contactPerson: 'John Manager',
        contactPhone: '555-0101'
      },
      {
        id: 'venue-desert-ridge',
        name: 'Desert Ridge Recreation Center',
        address: '456 Desert Dr, Phoenix, AZ 85032',
        courts: 3,
        capacity: 300,
        amenities: ['Parking', 'Restrooms', 'Water Fountains'],
        contactPerson: 'Sarah Coordinator',
        contactPhone: '555-0102'
      },
      {
        id: 'venue-scottsdale-ymca',
        name: 'Scottsdale YMCA',
        address: '789 Scottsdale Rd, Scottsdale, AZ 85251',
        courts: 2,
        capacity: 200,
        amenities: ['Parking', 'Concessions', 'Restrooms'],
        contactPerson: 'Mike Director',
        contactPhone: '555-0103'
      },
      {
        id: 'venue-tempe-community',
        name: 'Tempe Community Center',
        address: '321 Mill Ave, Tempe, AZ 85281',
        courts: 3,
        capacity: 400,
        amenities: ['Parking', 'Restrooms', 'First Aid Station'],
        contactPerson: 'Lisa Manager',
        contactPhone: '555-0104'
      },
      {
        id: 'venue-mesa-sports',
        name: 'Mesa Sports Complex',
        address: '654 Mesa Blvd, Mesa, AZ 85201',
        courts: 5,
        capacity: 600,
        amenities: ['Parking', 'Concessions', 'Restrooms', 'Locker Rooms', 'Press Box'],
        contactPerson: 'Bob Supervisor',
        contactPhone: '555-0105'
      },
      {
        id: 'venue-glendale-arena',
        name: 'Glendale Youth Arena',
        address: '987 Glendale Ave, Glendale, AZ 85301',
        courts: 2,
        capacity: 250,
        amenities: ['Parking', 'Restrooms'],
        contactPerson: 'Amy Coordinator',
        contactPhone: '555-0106'
      }
    ];

    venues.forEach(venue => {
      batch.set(doc(db, 'venues', venue.id), venue);
    });

    // Create Teams (20+ as required)
    const teamNames = [
      'Phoenix Suns Youth', 'Desert Hawks', 'Thunder Bolts', 'Lightning Strike',
      'Mountain Lions', 'Valley Vipers', 'Red Rocks', 'Blue Devils',
      'Green Machine', 'Purple Reign', 'Golden Eagles', 'Silver Bullets',
      'Black Panthers', 'White Wolves', 'Orange Crush', 'Crimson Tide',
      'Storm Chasers', 'Fire Birds', 'Ice Warriors', 'Wind Runners',
      'Star Shooters', 'Sky Rockets', 'Ground Shakers', 'Wave Riders'
    ];

    const teams: any[] = [];
    teamNames.forEach((teamName, index) => {
      const divisionIndex = index % 5;
      const teamId = `team-${index + 1}`;
      const team = {
        id: teamId,
        name: teamName,
        division: divisions[divisionIndex],
        coachName: `Coach ${teamName.split(' ')[0]}`,
        coachEmail: `coach${index + 1}@gametriq.com`,
        coachPhone: `555-${String(1000 + index).padStart(4, '0')}`,
        assistantCoach: `Assistant ${index + 1}`,
        status: 'approved',
        registrationDate: '2025-01-01',
        homeVenue: venues[index % venues.length].id,
        wins: Math.floor(Math.random() * 10),
        losses: Math.floor(Math.random() * 10),
        ties: Math.floor(Math.random() * 3),
        pointsFor: Math.floor(Math.random() * 500),
        pointsAgainst: Math.floor(Math.random() * 500),
        createdAt: serverTimestamp()
      };
      teams.push(team);
      batch.set(doc(db, 'teams', teamId), team);
    });

    // Create Players (200+ as required)
    const firstNames = ['James', 'Michael', 'Sarah', 'Emma', 'John', 'Lisa', 'David', 'Jennifer', 'Robert', 'Mary'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    
    let playerCount = 0;
    teams.forEach((team, teamIndex) => {
      for (let i = 0; i < 10; i++) {
        playerCount++;
        const playerId = `player-${playerCount}`;
        const player = {
          id: playerId,
          teamId: team.id,
          teamName: team.name,
          firstName: firstNames[i % firstNames.length],
          lastName: lastNames[Math.floor(Math.random() * lastNames.length)],
          jerseyNumber: i + 1,
          position: ['PG', 'SG', 'SF', 'PF', 'C'][i % 5],
          dateOfBirth: `20${10 + (i % 8)}-${String((i % 12) + 1).padStart(2, '0')}-${String((i % 28) + 1).padStart(2, '0')}`,
          grade: 5 + (teamIndex % 8),
          height: `${5 + Math.floor(i / 5)}'${i % 12}"`,
          weight: 100 + (i * 5),
          parentName: `Parent of ${firstNames[i % firstNames.length]}`,
          parentEmail: `parent${playerCount}@email.com`,
          parentPhone: `555-${String(2000 + playerCount).padStart(4, '0')}`,
          medicalConditions: i % 5 === 0 ? 'Asthma' : 'None',
          allergies: i % 7 === 0 ? 'Peanuts' : 'None',
          status: 'active',
          createdAt: serverTimestamp()
        };
        batch.set(doc(db, 'players', playerId), player);
      }
    });

    // Create Emergency Contacts
    for (let i = 1; i <= 50; i++) {
      const contactId = `emergency-${i}`;
      batch.set(doc(db, 'emergencyContacts', contactId), {
        id: contactId,
        playerId: `player-${i}`,
        name: `Emergency Contact ${i}`,
        relationship: ['Parent', 'Guardian', 'Grandparent'][i % 3],
        primaryPhone: `555-${String(3000 + i).padStart(4, '0')}`,
        secondaryPhone: `555-${String(3500 + i).padStart(4, '0')}`,
        email: `emergency${i}@email.com`,
        address: `${i * 10} Emergency St, Phoenix, AZ 85001`,
        medicalNotes: 'Authorized for medical decisions',
        createdAt: serverTimestamp()
      });
    }

    // Create Staff (Referees and Scorekeepers)
    const staffRoles = ['referee', 'scorekeeper', 'timekeeper'];
    for (let i = 1; i <= 30; i++) {
      const staffId = `staff-${i}`;
      batch.set(doc(db, 'staff', staffId), {
        id: staffId,
        name: `Staff Member ${i}`,
        role: staffRoles[i % 3],
        email: `staff${i}@gametriq.com`,
        phone: `555-${String(4000 + i).padStart(4, '0')}`,
        certificationLevel: ['Level 1', 'Level 2', 'Level 3'][i % 3],
        experience: `${i % 10} years`,
        availability: ['Weekdays', 'Weekends', 'Both'][i % 3],
        assignedGames: [],
        checkedIn: false,
        status: 'active',
        createdAt: serverTimestamp()
      });
    }

    // Create Games (50+ as required)
    const gameStatuses = ['scheduled', 'in_progress', 'completed'];
    const gameDates = [];
    for (let i = 0; i < 10; i++) {
      const date = new Date(2025, 0, 15 + i);
      gameDates.push(date.toISOString().split('T')[0]);
    }

    for (let i = 1; i <= 60; i++) {
      const gameId = `game-${i}`;
      const homeTeamIndex = i % teams.length;
      const awayTeamIndex = (i + 1) % teams.length;
      const venueIndex = i % venues.length;
      const status = i <= 20 ? 'completed' : i <= 30 ? 'in_progress' : 'scheduled';
      
      const game = {
        id: gameId,
        homeTeamId: teams[homeTeamIndex].id,
        homeTeamName: teams[homeTeamIndex].name,
        awayTeamId: teams[awayTeamIndex].id,
        awayTeamName: teams[awayTeamIndex].name,
        date: gameDates[i % gameDates.length],
        time: `${10 + (i % 10)}:00 AM`,
        venue: venues[venueIndex].id,
        venueName: venues[venueIndex].name,
        courtNumber: (i % 4) + 1,
        division: teams[homeTeamIndex].division,
        status: status,
        homeScore: status === 'completed' ? Math.floor(Math.random() * 80) + 40 : 0,
        awayScore: status === 'completed' ? Math.floor(Math.random() * 80) + 40 : 0,
        quarter: status === 'in_progress' ? Math.floor(Math.random() * 4) + 1 : 0,
        timeRemaining: status === 'in_progress' ? '5:30' : null,
        officials: [`Referee ${i}`, `Referee ${i + 1}`],
        scorekeeper: `Scorekeeper ${i}`,
        fouls: {
          home: status !== 'scheduled' ? Math.floor(Math.random() * 10) : 0,
          away: status !== 'scheduled' ? Math.floor(Math.random() * 10) : 0
        },
        timeouts: {
          home: status !== 'scheduled' ? Math.floor(Math.random() * 3) : 3,
          away: status !== 'scheduled' ? Math.floor(Math.random() * 3) : 3
        },
        possession: status === 'in_progress' ? ['home', 'away'][i % 2] : null,
        createdAt: serverTimestamp()
      };
      
      batch.set(doc(db, 'games', gameId), game);
    }

    // Create Standings (auto-calculated from games)
    teams.forEach((team, index) => {
      const standingId = `standing-${team.id}`;
      const standing = {
        id: standingId,
        teamId: team.id,
        teamName: team.name,
        division: team.division,
        wins: team.wins,
        losses: team.losses,
        ties: team.ties,
        gamesPlayed: team.wins + team.losses + team.ties,
        winPercentage: team.wins / (team.wins + team.losses + team.ties) || 0,
        pointsFor: team.pointsFor,
        pointsAgainst: team.pointsAgainst,
        pointDifferential: team.pointsFor - team.pointsAgainst,
        streak: ['W2', 'L1', 'W3', 'L2', 'W1'][index % 5],
        lastUpdated: serverTimestamp()
      };
      batch.set(doc(db, 'standings', standingId), standing);
    });

    // Create Financial Records
    for (let i = 1; i <= 20; i++) {
      const financialId = `financial-${i}`;
      batch.set(doc(db, 'financials', financialId), {
        id: financialId,
        teamId: teams[i % teams.length].id,
        teamName: teams[i % teams.length].name,
        type: ['registration', 'equipment', 'tournament'][i % 3],
        amount: [250, 500, 750][i % 3],
        status: ['paid', 'pending', 'overdue'][i % 3],
        dueDate: `2025-${String((i % 12) + 1).padStart(2, '0')}-15`,
        paidDate: i % 3 === 0 ? `2025-${String((i % 12) + 1).padStart(2, '0')}-10` : null,
        paymentMethod: ['credit_card', 'check', 'cash'][i % 3],
        notes: `Payment for ${['registration', 'equipment', 'tournament'][i % 3]}`,
        createdAt: serverTimestamp()
      });
    }

    // Commit all changes
    await batch.commit();
    
    console.log('✅ DATABASE INITIALIZATION COMPLETE');
    console.log('📊 Created:');
    console.log('- 4 user accounts (all roles)');
    console.log('- 2 seasons');
    console.log('- 5 divisions');
    console.log('- 6 venues');
    console.log('- 24 teams');
    console.log('- 240 players');
    console.log('- 50 emergency contacts');
    console.log('- 30 staff members');
    console.log('- 60 games');
    console.log('- 24 standings records');
    console.log('- 20 financial records');
    
    return {
      success: true,
      message: 'Database initialized successfully',
      credentials: testUsers.map(u => ({ email: u.email, password: u.password, role: u.role }))
    };
    
  } catch (error) {
    console.error('❌ Error initializing database:', error);
    throw error;
  }
}

// Export for use in test suite
export const TEST_CREDENTIALS = {
  admin: { email: 'admin@gametriq.com', password: 'Admin123!' },
  coach: { email: 'coach@gametriq.com', password: 'Coach123!' },
  scorekeeper: { email: 'scorekeeper@gametriq.com', password: 'Score123!' },
  sitedirector: { email: 'sitedirector@gametriq.com', password: 'Site123!' }
};