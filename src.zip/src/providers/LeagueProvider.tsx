import React, { createContext, useContext, ReactNode } from 'react';
import { leagueConfig, LeagueConfig } from '../config/league.config';

interface LeagueContextType {
  config: LeagueConfig;
  getCollectionName: (collection: string) => string;
  getStoragePath: (path: string) => string;
}

const LeagueContext = createContext<LeagueContextType | undefined>(undefined);

export const useLeague = () => {
  const context = useContext(LeagueContext);
  if (!context) {
    throw new Error('useLeague must be used within a LeagueProvider');
  }
  return context;
};

interface LeagueProviderProps {
  children: ReactNode;
}

export const LeagueProvider: React.FC<LeagueProviderProps> = ({ children }) => {
  // Helper function to get league-specific collection name
  const getCollectionName = (collection: string): string => {
    return `${leagueConfig.firestorePrefix}_${collection}`;
  };

  // Helper function to get league-specific storage path
  const getStoragePath = (path: string): string => {
    return `leagues/${leagueConfig.leagueId}/${path}`;
  };

  // Apply theme colors to CSS variables
  React.useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty('--primary-color', leagueConfig.primaryColor);
    root.style.setProperty('--secondary-color', leagueConfig.secondaryColor);
    root.style.setProperty('--accent-color', leagueConfig.accentColor);
    
    // Update page title
    document.title = `${leagueConfig.leagueName} - GameTriq League Management`;
    
    // Update favicon
    const favicon = document.querySelector("link[rel*='icon']") as HTMLLinkElement;
    if (favicon) {
      favicon.href = leagueConfig.faviconUrl;
    }
  }, []);

  return (
    <LeagueContext.Provider value={{ 
      config: leagueConfig, 
      getCollectionName,
      getStoragePath 
    }}>
      {children}
    </LeagueContext.Provider>
  );
};