import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Activity, Clock, ClipboardList, FileText, 
  PlayCircle, Calendar, MapPin, Trophy 
} from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { useAuth } from '../AuthContext';
import { leagueConfig } from '../config/league.config';
import ComprehensiveStatTracker from '../components/ComprehensiveStatTracker';
import LiveScoring from '../pages/scorekeeper/LiveScoring';

interface Game {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  location: string;
  status: 'scheduled' | 'in_progress' | 'completed';
  homeScore: number;
  awayScore: number;
}

export const ScorekeeperDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [todayGames, setTodayGames] = useState<Game[]>([]);
  const [completedGames, setCompletedGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);
  const [showStatTracker, setShowStatTracker] = useState(false);
  const [selectedGameId, setSelectedGameId] = useState<string | null>(null);
  const [showLiveScoring, setShowLiveScoring] = useState(false);
  const [demoPlayers] = useState([
    { id: '1', name: 'John Smith', jerseyNumber: '23' },
    { id: '2', name: 'Mike Johnson', jerseyNumber: '10' },
    { id: '3', name: 'David Lee', jerseyNumber: '5' },
    { id: '4', name: 'Chris Brown', jerseyNumber: '15' },
    { id: '5', name: 'Alex Wilson', jerseyNumber: '7' }
  ]);

  // PROOF OF LIFE LOG
  React.useEffect(() => {
    console.log("🟠 SCOREKEEPER DASHBOARD LOADED - PROOF OF LIFE");
    console.log("User Role: SCOREKEEPER");
    console.log("Dashboard Component: ScorekeeperDashboard.tsx");
    console.log("Timestamp:", new Date().toLocaleTimeString());
  }, []);

  useEffect(() => {
    loadGames();
  }, []);

  const loadGames = async () => {
    setLoading(true);
    try {
      // Simplified query to avoid index errors
      const gamesQuery = query(
        collection(db, 'games')
      );
      const snapshot = await getDocs(gamesQuery);
      
      const today = new Date().toISOString().split('T')[0];
      const games = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Game));

      const todayGamesList = games.filter(g => 
        g.date === today && g.status !== 'completed'
      );

      const completedList = games.filter(g => 
        g.status === 'completed'
      ).slice(0, 5);

      // No demo data - use real Firestore data only

      setTodayGames(todayGamesList);
      setCompletedGames(completedList);
    } catch (error) {
      console.error('Error loading games:', error);
    }
    setLoading(false);
  };

  const startScoring = (gameId: string) => {
    setSelectedGameId(gameId);
    setShowStatTracker(true);
  };

  const handleStatTrackerComplete = () => {
    setShowStatTracker(false);
    setSelectedGameId(null);
    loadGames(); // Reload games after completing stats
  };

  const quickActions = [
    { label: 'Stat Tracker (NEW)', route: '/scorekeeper/stat-tracker', icon: ClipboardList, color: 'bg-green-500', action: () => navigate('/scorekeeper/stat-tracker') },
    { label: 'Live Scoring', route: '/scorekeeper/live', icon: Activity, color: 'bg-red-500', action: () => navigate('/scorekeeper/live') },
    { label: 'Enter Live Scores', route: '/scoring', icon: Activity, color: 'bg-orange-500', action: () => setShowLiveScoring(true) },
    { label: 'Game History', route: '/history', icon: Clock, color: 'bg-blue-500', action: () => navigate('/history') },
    { label: 'Export Reports', route: '/reports', icon: FileText, color: 'bg-purple-500', action: () => navigate('/reports') }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  if (showLiveScoring) {
    return <LiveScoring />;
  }

  if (showStatTracker && selectedGameId) {
    return (
      <ComprehensiveStatTracker
        gameId={selectedGameId}
        players={demoPlayers}
        onComplete={handleStatTrackerComplete}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Scorekeeper Header */}
      <div className="glass-panel p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img 
              src={leagueConfig.logoUrl}
              alt="League Logo"
              className="h-16 w-16 object-contain"
            />
            <div>
              <h2 className="text-3xl font-display font-bold text-gradient mb-2">
                Scorekeeper Dashboard
              </h2>
              <p className="text-gray-400">
                Track live scores and manage game statistics
              </p>
            </div>
          </div>
          <div className="h-12 w-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center pulse-glow">
            <Activity className="h-8 w-8 text-white" />
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Today's Games</p>
                <p className="text-3xl font-bold text-white">{todayGames.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Live Now</p>
                <p className="text-3xl font-bold text-white">
                  {todayGames.filter(g => g.status === 'in_progress').length}
                </p>
              </div>
              <Activity className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Completed Today</p>
                <p className="text-3xl font-bold text-white">
                  {completedGames.filter(g => 
                    g.date === new Date().toISOString().split('T')[0]
                  ).length}
                </p>
              </div>
              <Trophy className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Scored</p>
                <p className="text-3xl font-bold text-white">247</p>
              </div>
              <ClipboardList className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Today's Games to Score */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Today's Games</h3>
        <div className="space-y-3">
          {todayGames.map(game => (
            <Card key={game.id} className="glass-panel">
              <CardContent className="p-6">
                <div className="flex justify-between items-center">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-lg font-semibold text-white">
                        {game.homeTeam} vs {game.awayTeam}
                      </h4>
                      {game.status === 'in_progress' && (
                        <Badge variant="game-live">LIVE</Badge>
                      )}
                      {game.status === 'scheduled' && (
                        <Badge variant="outline">SCHEDULED</Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {game.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {game.location}
                      </span>
                    </div>
                    {game.status === 'in_progress' && (
                      <div className="mt-2 flex items-center gap-4">
                        <span className="text-white font-semibold">
                          Score: {game.homeScore} - {game.awayScore}
                        </span>
                      </div>
                    )}
                  </div>
                  <div>
                    {game.status === 'scheduled' ? (
                      <Button 
                        variant="primary"
                        onClick={() => navigate(`/scorekeeper/stat-tracker/${game.id}`)}
                      >
                        <PlayCircle className="h-4 w-4 mr-2" />
                        Start Scoring
                      </Button>
                    ) : (
                      <Button 
                        variant="game-live"
                        onClick={() => navigate(`/scorekeeper/stat-tracker/${game.id}`)}
                      >
                        <Activity className="h-4 w-4 mr-2" />
                        Continue Scoring
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Recently Completed Games */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Recently Completed</h3>
        <div className="space-y-2">
          {completedGames.map(game => (
            <Card key={game.id} className="glass-panel">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="font-semibold text-white">
                      {game.homeTeam} {game.homeScore} - {game.awayScore} {game.awayTeam}
                    </p>
                    <p className="text-sm text-gray-400">
                      {game.date} • {game.location}
                    </p>
                  </div>
                  <Button size="sm" variant="outline">
                    View Details
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  className="glass-panel cursor-pointer hover:border-red-500/50 transition-all"
                  onClick={action.action}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`w-12 h-12 bg-gradient-to-br ${action.color.replace('bg-', 'from-')}-400 ${action.color.replace('bg-', 'to-')}-600 rounded-lg flex items-center justify-center mb-3`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="font-semibold text-white">{action.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ScorekeeperDashboard;