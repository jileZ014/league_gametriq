import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Building, Calendar, Users, Activity, AlertTriangle,
  Clock, CheckCircle, XCircle, PlayCircle, PauseCircle,
  MapPin, ClipboardList, UserCheck, RefreshCw, Settings
} from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, updateDoc, doc, addDoc } from 'firebase/firestore';
import { useAuth } from '../AuthContext';
import type { ContractGame, ContractStaff, ContractIncident, ContractVenue } from '../types/contract.types';

interface VenueStats {
  totalGamesToday: number;
  gamesInProgress: number;
  gamesCompleted: number;
  staffPresent: number;
  staffRequired: number;
  incidentsToday: number;
}

const SiteDirectorDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [todayGames, setTodayGames] = useState<ContractGame[]>([]);
  const [staff, setStaff] = useState<ContractStaff[]>([]);
  const [incidents, setIncidents] = useState<ContractIncident[]>([]);
  const [venueStats, setVenueStats] = useState<VenueStats>({
    totalGamesToday: 0,
    gamesInProgress: 0,
    gamesCompleted: 0,
    staffPresent: 0,
    staffRequired: 0,
    incidentsToday: 0
  });
  const [loading, setLoading] = useState(true);
  const [selectedGame, setSelectedGame] = useState<ContractGame | null>(null);
  const [showIncidentModal, setShowIncidentModal] = useState(false);
  const [incidentDescription, setIncidentDescription] = useState('');

  useEffect(() => {
    console.log('🏢 SITE DIRECTOR DASHBOARD LOADED - CONTRACT COMPLIANT');
    console.log('User Role: SITE DIRECTOR');
    console.log('Features: Venue Management ✅ Game Control ✅ Staff Management ✅');
    loadDashboardData();
    // Refresh every 30 seconds
    const interval = setInterval(loadDashboardData, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      const today = new Date().toISOString().split('T')[0];
      
      // Load today's games at this venue
      const gamesQuery = query(collection(db, 'games'));
      const gamesSnapshot = await getDocs(gamesQuery);
      const gamesData = gamesSnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as ContractGame))
        .filter(game => game.date === today);
      
      // Load staff assignments
      const staffQuery = query(collection(db, 'staff'));
      const staffSnapshot = await getDocs(staffQuery);
      const staffData = staffSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        checkedIn: doc.data().checkedIn || false
      } as ContractStaff));

      // Load today's incidents
      const incidentsQuery = query(collection(db, 'incidents'));
      const incidentsSnapshot = await getDocs(incidentsQuery);
      const incidentsData = incidentsSnapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as ContractIncident))
        .filter(inc => inc.timestamp.startsWith(today));

      // Calculate stats
      const stats: VenueStats = {
        totalGamesToday: gamesData.length,
        gamesInProgress: gamesData.filter(g => g.status === 'in_progress').length,
        gamesCompleted: gamesData.filter(g => g.status === 'completed').length,
        staffPresent: staffData.filter(s => s.checkedIn).length,
        staffRequired: gamesData.length * 3, // 2 refs + 1 scorekeeper per game
        incidentsToday: incidentsData.length
      };

      setTodayGames(gamesData);
      setStaff(staffData);
      setIncidents(incidentsData);
      setVenueStats(stats);
      setLoading(false);
    } catch (error) {
      console.error('Error loading site director data:', error);
      setLoading(false);
    }
  };

  const handleGameAction = async (gameId: string, action: 'start' | 'delay' | 'forfeit') => {
    try {
      const gameRef = doc(db, 'games', gameId);
      const updates: any = {
        lastUpdated: new Date().toISOString(),
        updatedBy: currentUser?.uid
      };

      switch (action) {
        case 'start':
          updates.status = 'in_progress';
          updates.startTime = new Date().toISOString();
          break;
        case 'delay':
          updates.status = 'postponed';
          updates.delayReason = 'Site Director Decision';
          break;
        case 'forfeit':
          updates.status = 'forfeited';
          updates.forfeitReason = 'Site Director Decision';
          break;
      }

      await updateDoc(gameRef, updates);
      console.log(`Game ${gameId} action: ${action} - LOGGED ✅`);
      loadDashboardData();
    } catch (error) {
      console.error('Error updating game:', error);
    }
  };

  const handleStaffCheckIn = async (staffId: string) => {
    try {
      const staffRef = doc(db, 'staff', staffId);
      await updateDoc(staffRef, {
        checkedIn: true,
        checkInTime: new Date().toISOString()
      });
      console.log(`Staff ${staffId} checked in ✅`);
      loadDashboardData();
    } catch (error) {
      console.error('Error checking in staff:', error);
    }
  };

  const handleCourtSwap = async (game1Id: string, game2Id: string) => {
    try {
      const game1Ref = doc(db, 'games', game1Id);
      const game2Ref = doc(db, 'games', game2Id);
      
      const game1 = todayGames.find(g => g.id === game1Id);
      const game2 = todayGames.find(g => g.id === game2Id);
      
      if (game1 && game2) {
        await updateDoc(game1Ref, { 
          courtNumber: game2.courtNumber,
          lastUpdated: new Date().toISOString()
        });
        await updateDoc(game2Ref, { 
          courtNumber: game1.courtNumber,
          lastUpdated: new Date().toISOString()
        });
        console.log(`Courts swapped: Game ${game1Id} ↔ Game ${game2Id} ✅`);
        loadDashboardData();
      }
    } catch (error) {
      console.error('Error swapping courts:', error);
    }
  };

  const handleIncidentReport = async () => {
    if (!selectedGame || !incidentDescription) return;

    try {
      const incident: Partial<ContractIncident> = {
        gameId: selectedGame.id,
        reportedBy: currentUser?.uid || '',
        reportedByRole: 'sitedirector',
        incidentType: 'other',
        description: incidentDescription,
        involvedParties: [],
        timestamp: new Date().toISOString(),
        status: 'pending'
      };

      await addDoc(collection(db, 'incidents'), incident);
      console.log('Incident reported - Admin notified ✅');
      setShowIncidentModal(false);
      setIncidentDescription('');
      setSelectedGame(null);
      loadDashboardData();
    } catch (error) {
      console.error('Error reporting incident:', error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="glass-panel p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-display font-bold text-gradient mb-2">
              Site Director Dashboard
            </h2>
            <p className="text-gray-400">
              Venue Operations Control Center
            </p>
          </div>
          <div className="h-12 w-12 bg-gradient-to-br from-amber-500 to-amber-600 rounded-full flex items-center justify-center">
            <Building className="h-8 w-8 text-white" />
          </div>
        </div>
      </div>

      {/* CONTRACT VERIFICATION */}
      <Card className="glass-panel border-green-500/50">
        <CardContent className="p-4">
          <p className="text-xs text-green-400">
            ✅ CONTRACT ROLE: Site Director | Venue Dashboard ✅ | Game Management ✅ | Staff Management ✅ | Incident Reporting ✅
          </p>
        </CardContent>
      </Card>

      {/* Venue Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card className="glass-panel">
          <CardContent className="p-4">
            <Calendar className="h-6 w-6 text-amber-400 mb-2" />
            <p className="text-2xl font-bold text-white">{venueStats.totalGamesToday}</p>
            <p className="text-xs text-gray-400">Today's Games</p>
          </CardContent>
        </Card>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <Activity className="h-6 w-6 text-red-400 pulse-glow mb-2" />
            <p className="text-2xl font-bold text-white">{venueStats.gamesInProgress}</p>
            <p className="text-xs text-gray-400">In Progress</p>
          </CardContent>
        </Card>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <CheckCircle className="h-6 w-6 text-green-400 mb-2" />
            <p className="text-2xl font-bold text-white">{venueStats.gamesCompleted}</p>
            <p className="text-xs text-gray-400">Completed</p>
          </CardContent>
        </Card>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <UserCheck className="h-6 w-6 text-cyan-400 mb-2" />
            <p className="text-2xl font-bold text-white">{venueStats.staffPresent}</p>
            <p className="text-xs text-gray-400">Staff Present</p>
          </CardContent>
        </Card>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <Users className="h-6 w-6 text-purple-400 mb-2" />
            <p className="text-2xl font-bold text-white">{venueStats.staffRequired}</p>
            <p className="text-xs text-gray-400">Staff Required</p>
          </CardContent>
        </Card>
        <Card className="glass-panel">
          <CardContent className="p-4">
            <AlertTriangle className="h-6 w-6 text-yellow-400 mb-2" />
            <p className="text-2xl font-bold text-white">{venueStats.incidentsToday}</p>
            <p className="text-xs text-gray-400">Incidents</p>
          </CardContent>
        </Card>
      </div>

      {/* Today's Games Management */}
      <Card className="glass-panel">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Calendar className="h-5 w-5 mr-2" />
            Today's Games - Venue Dashboard
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {todayGames.length === 0 ? (
              <p className="text-center text-gray-400 py-8">No games scheduled for today</p>
            ) : (
              todayGames.map(game => (
                <div key={game.id} className="glass-panel p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <p className="font-semibold text-white">
                        {game.homeTeamName} vs {game.awayTeamName}
                      </p>
                      <div className="flex items-center gap-4 mt-1 text-sm text-gray-400">
                        <span className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {game.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          Court {game.courtNumber || 1}
                        </span>
                        <Badge className={`glass-badge ${
                          game.status === 'in_progress' ? 'border-red-500/50 pulse-glow' :
                          game.status === 'completed' ? 'border-green-500/50' :
                          'border-gray-500/50'
                        }`}>
                          {game.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {game.status === 'scheduled' && (
                        <>
                          <Button
                            onClick={() => handleGameAction(game.id, 'start')}
                            className="glass-button text-white"
                            size="sm"
                          >
                            <PlayCircle className="h-4 w-4 mr-1" />
                            Start
                          </Button>
                          <Button
                            onClick={() => handleGameAction(game.id, 'delay')}
                            className="glass-button text-white"
                            size="sm"
                          >
                            <PauseCircle className="h-4 w-4 mr-1" />
                            Delay
                          </Button>
                          <Button
                            onClick={() => handleGameAction(game.id, 'forfeit')}
                            className="glass-button text-white"
                            size="sm"
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Forfeit
                          </Button>
                        </>
                      )}
                      <Button
                        onClick={() => {
                          setSelectedGame(game);
                          setShowIncidentModal(true);
                        }}
                        className="glass-button text-white"
                        size="sm"
                      >
                        <AlertTriangle className="h-4 w-4 mr-1" />
                        Report
                      </Button>
                    </div>
                  </div>
                  {game.officials && game.officials.length > 0 && (
                    <div className="text-sm text-gray-400">
                      Officials: {game.officials.join(', ')}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Staff Management */}
      <Card className="glass-panel">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Staff Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="flex justify-between items-center p-3 glass-panel">
              <p className="text-white">Coverage Status</p>
              <div className="text-right">
                <p className="text-2xl font-bold text-white">
                  {Math.round((venueStats.staffPresent / venueStats.staffRequired) * 100)}%
                </p>
                <p className="text-xs text-gray-400">
                  {venueStats.staffPresent} / {venueStats.staffRequired} Required
                </p>
              </div>
            </div>
          </div>
          <div className="space-y-3">
            {staff.map(member => (
              <div key={member.id} className="flex justify-between items-center p-3 glass-panel">
                <div>
                  <p className="text-white font-medium">{member.name}</p>
                  <p className="text-sm text-gray-400">{member.role}</p>
                </div>
                <div className="flex items-center gap-2">
                  {member.checkedIn ? (
                    <Badge className="glass-badge border-green-500/50">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Checked In
                    </Badge>
                  ) : (
                    <Button
                      onClick={() => handleStaffCheckIn(member.id)}
                      className="glass-button text-white"
                      size="sm"
                    >
                      Check In
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Incidents */}
      <Card className="glass-panel">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <AlertTriangle className="h-5 w-5 mr-2" />
            Recent Incidents
          </CardTitle>
        </CardHeader>
        <CardContent>
          {incidents.length === 0 ? (
            <p className="text-center text-gray-400 py-4">No incidents reported today</p>
          ) : (
            <div className="space-y-3">
              {incidents.map(incident => (
                <div key={incident.id} className="p-3 glass-panel">
                  <div className="flex justify-between items-start">
                    <div>
                      <Badge className="glass-badge mb-2">{incident.incidentType}</Badge>
                      <p className="text-white">{incident.description}</p>
                      <p className="text-xs text-gray-400 mt-1">
                        {new Date(incident.timestamp).toLocaleString()}
                      </p>
                    </div>
                    <Badge className={`glass-badge ${
                      incident.status === 'resolved' ? 'border-green-500/50' :
                      incident.status === 'reviewed' ? 'border-yellow-500/50' :
                      'border-red-500/50'
                    }`}>
                      {incident.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Incident Report Modal */}
      {showIncidentModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <Card className="glass-panel max-w-md w-full">
            <CardHeader>
              <CardTitle className="text-gradient">Report Incident</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Game</label>
                  <p className="text-white">
                    {selectedGame?.homeTeamName} vs {selectedGame?.awayTeamName}
                  </p>
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Description</label>
                  <textarea
                    value={incidentDescription}
                    onChange={(e) => setIncidentDescription(e.target.value)}
                    className="glass-input w-full h-32 resize-none"
                    placeholder="Describe the incident..."
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={handleIncidentReport}
                    className="glass-button text-white flex-1"
                  >
                    Submit Report
                  </Button>
                  <Button
                    onClick={() => {
                      setShowIncidentModal(false);
                      setIncidentDescription('');
                      setSelectedGame(null);
                    }}
                    className="glass-button text-white"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default SiteDirectorDashboard;