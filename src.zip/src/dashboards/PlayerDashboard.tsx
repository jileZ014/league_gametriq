import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Calendar, TrendingUp, Users, Trophy, 
  Target, Award, Activity, Clock 
} from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

interface PlayerStats {
  ppg: number;
  rpg: number;
  apg: number;
  fg: number;
  threePt: number;
  ft: number;
}

interface Game {
  id: string;
  opponent: string;
  date: string;
  time: string;
  location: string;
  result?: 'W' | 'L';
  playerPoints?: number;
}

export const PlayerDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [stats, setStats] = useState<PlayerStats>({
    ppg: 15.5,
    rpg: 5.2,
    apg: 3.8,
    fg: 48,
    threePt: 35,
    ft: 82
  });
  const [upcomingGames, setUpcomingGames] = useState<Game[]>([]);
  const [recentGames, setRecentGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(true);

  // PROOF OF LIFE LOG
  React.useEffect(() => {
    console.log("🟣 PLAYER DASHBOARD LOADED - PROOF OF LIFE");
    console.log("User Role: PLAYER");
    console.log("Dashboard Component: PlayerDashboard.tsx");
    console.log("Timestamp:", new Date().toLocaleTimeString());
  }, []);

  useEffect(() => {
    loadPlayerData();
  }, [currentUser]);

  const loadPlayerData = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      // Load player stats from Firestore
      const playerQuery = query(
        collection(db, 'players'),
        where('userId', '==', currentUser.uid)
      );
      const playerSnapshot = await getDocs(playerQuery);
      
      if (!playerSnapshot.empty) {
        const playerData = playerSnapshot.docs[0].data();
        if (playerData.stats) {
          setStats(playerData.stats);
        }
      }

      // Load games from Firestore
      const gamesQuery = query(collection(db, 'games'));
      const gamesSnapshot = await getDocs(gamesQuery);
      const allGames = gamesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Game));
      
      // Filter upcoming and recent games
      const today = new Date().toISOString().split('T')[0];
      const upcoming = allGames.filter(g => g.date >= today && g.result === undefined);
      const recent = allGames.filter(g => g.date < today || g.result !== undefined).slice(0, 5);
      
      setUpcomingGames(upcoming);
      setRecentGames(recent);
    } catch (error) {
      console.error('Error loading player data:', error);
    }
    setLoading(false);
  };

  const quickActions = [
    { label: 'View Schedule', route: '/schedule', icon: Calendar, color: 'bg-blue-500' },
    { label: 'My Stats', route: '/stats', icon: TrendingUp, color: 'bg-purple-500' },
    { label: 'Team Roster', route: '/team-roster', icon: Users, color: 'bg-green-500' },
    { label: 'Game Results', route: '/results', icon: Trophy, color: 'bg-orange-500' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Player Header */}
      <div className="bg-gradient-navy p-6 rounded-xl border border-navy-800">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-display font-bold text-white mb-2">
              Player Dashboard
            </h2>
            <p className="text-gray-400">
              Track your performance and upcoming games
            </p>
          </div>
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-orange rounded-full flex items-center justify-center mb-2">
              <span className="text-3xl font-bold text-white">#15</span>
            </div>
            <p className="text-white font-semibold">Phoenix Thunder</p>
          </div>
        </div>
      </div>

      {/* Season Stats */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Season Stats</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <Card variant="navy">
            <CardContent className="p-4 text-center">
              <Target className="h-6 w-6 text-basketball-orange-500 mx-auto mb-2" />
              <p className="text-gray-400 text-xs uppercase">PPG</p>
              <p className="text-2xl font-bold text-white">{stats.ppg}</p>
            </CardContent>
          </Card>
          <Card variant="navy">
            <CardContent className="p-4 text-center">
              <Activity className="h-6 w-6 text-blue-500 mx-auto mb-2" />
              <p className="text-gray-400 text-xs uppercase">RPG</p>
              <p className="text-2xl font-bold text-white">{stats.rpg}</p>
            </CardContent>
          </Card>
          <Card variant="navy">
            <CardContent className="p-4 text-center">
              <Users className="h-6 w-6 text-green-500 mx-auto mb-2" />
              <p className="text-gray-400 text-xs uppercase">APG</p>
              <p className="text-2xl font-bold text-white">{stats.apg}</p>
            </CardContent>
          </Card>
          <Card variant="navy">
            <CardContent className="p-4 text-center">
              <Trophy className="h-6 w-6 text-purple-500 mx-auto mb-2" />
              <p className="text-gray-400 text-xs uppercase">FG%</p>
              <p className="text-2xl font-bold text-white">{stats.fg}%</p>
            </CardContent>
          </Card>
          <Card variant="navy">
            <CardContent className="p-4 text-center">
              <Award className="h-6 w-6 text-yellow-500 mx-auto mb-2" />
              <p className="text-gray-400 text-xs uppercase">3P%</p>
              <p className="text-2xl font-bold text-white">{stats.threePt}%</p>
            </CardContent>
          </Card>
          <Card variant="navy">
            <CardContent className="p-4 text-center">
              <Target className="h-6 w-6 text-red-500 mx-auto mb-2" />
              <p className="text-gray-400 text-xs uppercase">FT%</p>
              <p className="text-2xl font-bold text-white">{stats.ft}%</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Performance Chart */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Performance Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-48 flex items-end justify-between gap-2">
            {[18, 22, 15, 28, 19, 24, 31, 17, 20, 26].map((points, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div 
                  className="w-full bg-gradient-orange rounded-t"
                  style={{ height: `${(points / 35) * 100}%` }}
                />
                <span className="text-xs text-gray-500 mt-1">{points}</span>
              </div>
            ))}
          </div>
          <p className="text-center text-gray-400 text-sm mt-4">Points Per Game (Last 10 Games)</p>
        </CardContent>
      </Card>

      {/* Two Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Games */}
        <div>
          <h3 className="text-xl font-semibold text-white mb-4">Upcoming Games</h3>
          <div className="space-y-3">
            {upcomingGames.map(game => (
              <Card key={game.id} variant="navy">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <h4 className="font-semibold text-white">vs {game.opponent}</h4>
                      <div className="flex items-center gap-3 text-sm text-gray-400 mt-1">
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {new Date(game.date).toLocaleDateString()}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {game.time}
                        </span>
                      </div>
                    </div>
                    <Button size="sm" variant="primary">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recent Games */}
        <div>
          <h3 className="text-xl font-semibold text-white mb-4">Recent Games</h3>
          <div className="space-y-3">
            {recentGames.map(game => (
              <Card key={game.id} variant="navy">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-semibold text-white">vs {game.opponent}</h4>
                        <Badge variant={game.result === 'W' ? 'success' : 'destructive'}>
                          {game.result}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-400 mt-1">
                        Your Points: <span className="text-basketball-orange-500 font-semibold">
                          {game.playerPoints}
                        </span>
                      </p>
                    </div>
                    <Button size="sm" variant="outline">
                      Stats
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* Achievements */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Recent Achievements</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-yellow-500/20 rounded-full flex items-center justify-center">
                <Trophy className="h-6 w-6 text-yellow-500" />
              </div>
              <div>
                <p className="font-semibold text-white">Game MVP</p>
                <p className="text-xs text-gray-400">vs Valley Kings</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-purple-500/20 rounded-full flex items-center justify-center">
                <Target className="h-6 w-6 text-purple-500" />
              </div>
              <div>
                <p className="font-semibold text-white">30+ Points</p>
                <p className="text-xs text-gray-400">Personal Best</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-500/20 rounded-full flex items-center justify-center">
                <Award className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="font-semibold text-white">Perfect FT</p>
                <p className="text-xs text-gray-400">10/10 Free Throws</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  variant="navy" 
                  className="cursor-pointer hover:border-basketball-orange-500 transition-all"
                  onClick={() => navigate(action.route)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-3`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="font-semibold text-white">{action.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default PlayerDashboard;