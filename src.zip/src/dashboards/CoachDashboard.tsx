import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Users, Calendar, TrendingUp, MessageSquare, Trophy, 
  Clock, Activity, Plus, Edit, ClipboardList, X 
} from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, orderBy, addDoc } from 'firebase/firestore';
import { useAuth } from '../AuthContext';
import { leagueConfig } from '../config/league.config';

interface Team {
  id: string;
  name: string;
  players: number;
  wins: number;
  losses: number;
}

interface Practice {
  id: string;
  date: string;
  time: string;
  location: string;
  type: string;
}

export const CoachDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [teams, setTeams] = useState<Team[]>([]);
  const [practices, setPractices] = useState<Practice[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddTeamModal, setShowAddTeamModal] = useState(false);
  const [newTeamName, setNewTeamName] = useState('');
  const [saving, setSaving] = useState(false);

  // PROOF OF LIFE LOG
  React.useEffect(() => {
    console.log("🔵 COACH DASHBOARD LOADED - PROOF OF LIFE");
    console.log("User Role: COACH");
    console.log("Dashboard Component: CoachDashboard.tsx");
    console.log("Timestamp:", new Date().toLocaleTimeString());
  }, []);

  useEffect(() => {
    loadDashboardData();
  }, [currentUser]);

  const loadDashboardData = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      // Load teams - simplified query to avoid index errors
      const teamsQuery = query(
        collection(db, 'teams'),
        where('coachId', '==', currentUser.uid)
      );
      const teamsSnapshot = await getDocs(teamsQuery);
      const teamsData = teamsSnapshot.docs.map(doc => ({
        id: doc.id,
        name: doc.data().name || 'Unnamed Team',
        players: doc.data().players || 0,
        wins: doc.data().wins || 0,
        losses: doc.data().losses || 0
      }));
      
      setTeams(teamsData);

      // Load practices - simplified query
      const practicesQuery = query(
        collection(db, 'practices'),
        where('coachId', '==', currentUser.uid)
      );
      const practicesSnapshot = await getDocs(practicesQuery);
      const practicesData = practicesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Practice));
      
      setPractices(practicesData);
    } catch (error) {
      console.error('Error loading coach data:', error);
    }
    setLoading(false);
  };

  const handleAddTeam = async () => {
    if (!newTeamName.trim() || !currentUser) return;
    
    setSaving(true);
    try {
      const teamData = {
        name: newTeamName,
        coachId: currentUser.uid,
        coachName: currentUser.displayName || 'Coach',
        players: 0,
        wins: 0,
        losses: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };
      
      await addDoc(collection(db, 'teams'), teamData);
      console.log('Team created successfully in Firestore');
      
      // Reload teams
      await loadDashboardData();
      
      // Reset form
      setNewTeamName('');
      setShowAddTeamModal(false);
    } catch (error) {
      console.error('Error creating team:', error);
    }
    setSaving(false);
  };

  const quickActions = [
    { label: 'Manage Team Roster', route: '/team-roster', icon: Users, color: 'bg-blue-500' },
    { label: 'View Game Stats', route: '/stats', icon: TrendingUp, color: 'bg-purple-500' },
    { label: 'Performance Analytics', route: '/coach/analytics', icon: Activity, color: 'bg-green-500' },
    { label: 'Schedule', route: '/schedule', icon: Calendar, color: 'bg-yellow-500' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="glass-panel p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img 
              src={leagueConfig.logoUrl}
              alt="League Logo"
              className="h-16 w-16 object-contain"
            />
            <div>
              <h2 className="text-3xl font-display font-bold text-gradient mb-2">
                Coach Dashboard
              </h2>
              <p className="text-gray-400">
                Welcome back, Coach {currentUser?.displayName?.split(' ')[0] || 'User'}! 
                Manage your teams and track performance.
              </p>
            </div>
          </div>
          <div className="h-12 w-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center">
            <Trophy className="h-8 w-8 text-white" />
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-panel">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Teams</p>
                <p className="text-3xl font-bold text-white">{teams.length}</p>
              </div>
              <Trophy className="h-8 w-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-panel">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Active Players</p>
                <p className="text-3xl font-bold text-white">
                  {teams.reduce((sum, team) => sum + team.players, 0)}
                </p>
              </div>
              <Users className="h-8 w-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-panel">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Win Rate</p>
                <p className="text-3xl font-bold text-white">
                  {teams[0] && (teams[0].wins + teams[0].losses) > 0 
                    ? Math.round((teams[0].wins / (teams[0].wins + teams[0].losses)) * 100) 
                    : 0}%
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="glass-panel">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Next Practice</p>
                <p className="text-2xl font-bold text-white">Tomorrow</p>
              </div>
              <Clock className="h-8 w-8 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* My Teams */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">My Teams</h3>
          <Button variant="primary" size="sm" onClick={() => setShowAddTeamModal(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Team
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {teams.map(team => (
            <Card key={team.id} className="glass-panel">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-lg font-semibold text-white">{team.name}</h4>
                    <p className="text-gray-400 text-sm">{team.players} Players</p>
                  </div>
                  <Badge variant="success">
                    {team.wins}W - {team.losses}L
                  </Badge>
                </div>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    variant="secondary"
                    onClick={() => navigate('/team-roster')}
                  >
                    <Users className="h-4 w-4 mr-1" />
                    Roster
                  </Button>
                  <Button 
                    size="sm" 
                    variant="secondary"
                    onClick={() => navigate('/stats')}
                  >
                    <TrendingUp className="h-4 w-4 mr-1" />
                    Stats
                  </Button>
                  <Button 
                    size="sm" 
                    variant="secondary"
                    onClick={() => navigate('/schedule')}
                  >
                    <Calendar className="h-4 w-4 mr-1" />
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Upcoming Practices */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">Upcoming Practices</h3>
          <Button variant="primary" size="sm" onClick={() => navigate('/schedule')}>
            View All
          </Button>
        </div>
        <div className="space-y-2">
          {practices.slice(0, 3).map(practice => (
            <Card key={practice.id} className="glass-panel">
              <CardContent className="p-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="font-semibold text-white">{practice.type}</h4>
                    <p className="text-sm text-gray-400">
                      {practice.date} at {practice.time} • {practice.location}
                    </p>
                  </div>
                  <Button size="sm" variant="outline">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  className="glass-panel cursor-pointer hover:border-cyan-500/50 transition-all"
                  onClick={() => navigate(action.route)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`w-12 h-12 bg-gradient-to-br ${action.color.replace('bg-', 'from-')}-400 ${action.color.replace('bg-', 'to-')}-600 rounded-lg flex items-center justify-center mb-3`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="font-semibold text-white">{action.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Add Team Modal */}
      {showAddTeamModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <Card className="glass-panel max-w-md w-full">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-gradient">Add New Team</CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAddTeamModal(false)}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Team Name
                  </label>
                  <input
                    type="text"
                    value={newTeamName}
                    onChange={(e) => setNewTeamName(e.target.value)}
                    className="w-full p-2 bg-navy-800 border border-navy-700 rounded text-white placeholder-gray-500"
                    placeholder="Enter team name"
                    autoFocus
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="primary"
                    className="flex-1"
                    onClick={handleAddTeam}
                    disabled={!newTeamName.trim() || saving}
                  >
                    {saving ? 'Creating...' : 'Create Team'}
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => {
                      setShowAddTeamModal(false);
                      setNewTeamName('');
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default CoachDashboard;