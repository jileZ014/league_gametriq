import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  Calendar, Activity, FileText, MessageSquare, 
  User, MapPin, Clock, Trophy, Bell, Star 
} from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

interface Child {
  id: string;
  name: string;
  team: string;
  jersey: number;
  position: string;
}

interface UpcomingGame {
  id: string;
  opponent: string;
  date: string;
  time: string;
  location: string;
  type: string;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'game' | 'practice' | 'announcement';
  timestamp: string;
  read: boolean;
}

export const ParentDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [children, setChildren] = useState<Child[]>([]);
  const [upcomingGames, setUpcomingGames] = useState<UpcomingGame[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  // PROOF OF LIFE LOG
  React.useEffect(() => {
    console.log("🟢 PARENT DASHBOARD LOADED - PROOF OF LIFE");
    console.log("User Role: PARENT");
    console.log("Dashboard Component: ParentDashboard.tsx");
    console.log("Timestamp:", new Date().toLocaleTimeString());
  }, []);

  useEffect(() => {
    loadParentData();
  }, [currentUser]);

  const loadParentData = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      // Load children from players collection
      const childrenQuery = query(
        collection(db, 'players'),
        where('parentId', '==', currentUser.uid)
      );
      const childrenSnapshot = await getDocs(childrenQuery);
      const childrenData = childrenSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Child));
      setChildren(childrenData);

      // Load upcoming games
      const gamesQuery = query(collection(db, 'games'));
      const gamesSnapshot = await getDocs(gamesQuery);
      const gamesData = gamesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as UpcomingGame));
      setUpcomingGames(gamesData);

      // Load notifications
      const notificationsQuery = query(
        collection(db, 'notifications'),
        where('userId', '==', currentUser.uid)
      );
      const notificationsSnapshot = await getDocs(notificationsQuery);
      const notificationsData = notificationsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Notification));
      setNotifications(notificationsData);
    } catch (error) {
      console.error('Error loading parent data:', error);
    }
    setLoading(false);
  };

  const quickActions = [
    { label: 'View Schedule', route: '/schedule', icon: Calendar, color: 'bg-blue-500' },
    { label: 'Game Updates', route: '/notifications', icon: Bell, color: 'bg-orange-500' },
    { label: 'Team News', route: '/updates', icon: FileText, color: 'bg-purple-500' },
    { label: 'Contact Coach', route: '/messages', icon: MessageSquare, color: 'bg-green-500' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Parent Header */}
      <div className="bg-gradient-navy p-6 rounded-xl border border-navy-800">
        <h2 className="text-3xl font-display font-bold text-white mb-2">
          Parent Dashboard
        </h2>
        <p className="text-gray-400">
          Welcome back! Stay updated on your child's basketball journey.
        </p>
      </div>

      {/* My Children */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">My Children</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {children.map(child => (
            <Card key={child.id} variant="navy">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-4">
                    <div className="w-16 h-16 bg-gradient-orange rounded-full flex items-center justify-center">
                      <span className="text-2xl font-bold text-white">
                        {child.jersey}
                      </span>
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-white">{child.name}</h4>
                      <p className="text-gray-400">{child.team}</p>
                      <Badge variant="secondary" className="mt-1">{child.position}</Badge>
                    </div>
                  </div>
                  <Star className="h-5 w-5 text-yellow-500" />
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div>
                    <p className="text-gray-400 text-xs">PPG</p>
                    <p className="text-lg font-bold text-white">12.5</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs">RPG</p>
                    <p className="text-lg font-bold text-white">4.2</p>
                  </div>
                  <div>
                    <p className="text-gray-400 text-xs">APG</p>
                    <p className="text-lg font-bold text-white">3.1</p>
                  </div>
                </div>
                <div className="mt-4 flex gap-2">
                  <Button size="sm" variant="secondary" className="flex-1">
                    View Stats
                  </Button>
                  <Button size="sm" variant="secondary" className="flex-1">
                    Schedule
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Upcoming Games */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">Upcoming Games</h3>
          <Button variant="outline" size="sm" onClick={() => navigate('/schedule')}>
            View Full Schedule
          </Button>
        </div>
        <div className="space-y-3">
          {upcomingGames.map(game => (
            <Card key={game.id} variant="navy">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="text-lg font-semibold text-white">
                        vs {game.opponent}
                      </h4>
                      <Badge variant={game.type === 'Tournament' ? 'game-live' : 'outline'}>
                        {game.type}
                      </Badge>
                    </div>
                    <div className="space-y-1 text-sm text-gray-400">
                      <p className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        {new Date(game.date).toLocaleDateString('en-US', { 
                          weekday: 'long', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </p>
                      <p className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {game.time}
                      </p>
                      <p className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {game.location}
                      </p>
                    </div>
                  </div>
                  <Button variant="primary" size="sm">
                    Get Directions
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Recent Notifications */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">Recent Notifications</h3>
          <Badge variant="game-live">
            {notifications.filter(n => !n.read).length} New
          </Badge>
        </div>
        <Card variant="navy">
          <CardContent className="p-0">
            <div className="divide-y divide-navy-800">
              {notifications.map(notification => (
                <div 
                  key={notification.id} 
                  className={`p-4 hover:bg-navy-800/50 cursor-pointer transition-colors ${
                    !notification.read ? 'bg-navy-800/30' : ''
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-2 h-2 rounded-full mt-2 ${
                      !notification.read ? 'bg-basketball-orange-500' : 'bg-transparent'
                    }`} />
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-semibold text-white">{notification.title}</h4>
                        <span className="text-xs text-gray-500">
                          {new Date(notification.timestamp).toLocaleTimeString([], { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </span>
                      </div>
                      <p className="text-sm text-gray-400">{notification.message}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  variant="navy" 
                  className="cursor-pointer hover:border-basketball-orange-500 transition-all"
                  onClick={() => navigate(action.route)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-3`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="font-semibold text-white">{action.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ParentDashboard;