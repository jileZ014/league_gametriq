import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { 
  ClipboardList, FileText, Calendar, Clock,
  MapPin, Flag, AlertTriangle, CheckCircle 
} from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { useAuth } from '../AuthContext';

interface Assignment {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time: string;
  location: string;
  division: string;
  status: 'upcoming' | 'completed' | 'in_progress';
  reportSubmitted?: boolean;
}

interface Rule {
  id: string;
  title: string;
  category: string;
  description: string;
}

export const RefereeDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [completedGames, setCompletedGames] = useState<Assignment[]>([]);
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);

  // PROOF OF LIFE LOG
  React.useEffect(() => {
    console.log("🟡 REFEREE DASHBOARD LOADED - PROOF OF LIFE");
    console.log("User Role: REFEREE");
    console.log("Dashboard Component: RefereeDashboard.tsx");
    console.log("Timestamp:", new Date().toLocaleTimeString());
  }, []);

  useEffect(() => {
    loadRefereeData();
  }, [currentUser]);

  const loadRefereeData = async () => {
    if (!currentUser) return;
    
    setLoading(true);
    try {
      // Load referee assignments from Firestore
      const assignmentsQuery = query(
        collection(db, 'games'),
        where('refereeId', '==', currentUser.uid)
      );
      const assignmentsSnapshot = await getDocs(assignmentsQuery);
      const assignmentsData = assignmentsSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Assignment));
      
      // Separate upcoming and completed games
      const upcoming = assignmentsData.filter(a => a.status !== 'completed');
      const completed = assignmentsData.filter(a => a.status === 'completed');
      
      setAssignments(upcoming);
      setCompletedGames(completed);

      // Load rules from Firestore
      const rulesQuery = query(collection(db, 'rules'));
      const rulesSnapshot = await getDocs(rulesQuery);
      const rulesData = rulesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      } as Rule));
      
      setRules(rulesData);
    } catch (error) {
      console.error('Error loading referee data:', error);
    }
    setLoading(false);
  };

  const quickActions = [
    { label: 'Game Assignments', route: '/assignments', icon: ClipboardList, color: 'bg-blue-500' },
    { label: 'Submit Reports', route: '/reports', icon: FileText, color: 'bg-purple-500' },
    { label: 'View Schedule', route: '/schedule', icon: Calendar, color: 'bg-green-500' },
    { label: 'Rules Reference', route: '/rules', icon: FileText, color: 'bg-orange-500' }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Referee Header */}
      <div className="bg-gradient-navy p-6 rounded-xl border border-navy-800">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-display font-bold text-white mb-2">
              Referee Dashboard
            </h2>
            <p className="text-gray-400">
              Manage your game assignments and submit reports
            </p>
          </div>
          <div className="w-16 h-16 bg-gradient-orange rounded-full flex items-center justify-center">
            <Flag className="h-8 w-8 text-white" />
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Upcoming Games</p>
                <p className="text-3xl font-bold text-white">{assignments.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">This Week</p>
                <p className="text-3xl font-bold text-white">5</p>
              </div>
              <Clock className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Games Officiated</p>
                <p className="text-3xl font-bold text-white">48</p>
              </div>
              <CheckCircle className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card variant="navy">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Pending Reports</p>
                <p className="text-3xl font-bold text-white">
                  {completedGames.filter(g => !g.reportSubmitted).length}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upcoming Assignments */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold text-white">Upcoming Assignments</h3>
          <Button variant="outline" size="sm" onClick={() => navigate('/assignments')}>
            View All
          </Button>
        </div>
        <div className="space-y-3">
          {assignments.map(assignment => (
            <Card key={assignment.id} variant="navy">
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h4 className="text-lg font-semibold text-white">
                        {assignment.homeTeam} vs {assignment.awayTeam}
                      </h4>
                      <Badge variant="secondary">{assignment.division}</Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(assignment.date).toLocaleDateString('en-US', { 
                          weekday: 'short',
                          month: 'short',
                          day: 'numeric' 
                        })}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {assignment.time}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {assignment.location}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="primary">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Pending Reports */}
      {completedGames.filter(g => !g.reportSubmitted).length > 0 && (
        <Card variant="navy" className="border-yellow-500/50">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-yellow-500" />
                Pending Game Reports
              </CardTitle>
              <Badge variant="warning">
                {completedGames.filter(g => !g.reportSubmitted).length} Pending
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {completedGames.filter(g => !g.reportSubmitted).map(game => (
                <div key={game.id} className="flex justify-between items-center p-3 bg-navy-800 rounded">
                  <div>
                    <p className="font-semibold text-white">
                      {game.homeTeam} vs {game.awayTeam}
                    </p>
                    <p className="text-sm text-gray-400">{game.date} • {game.division}</p>
                  </div>
                  <Button size="sm" variant="primary">
                    Submit Report
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Reference */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Quick Reference</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {rules.map(rule => (
            <Card key={rule.id} variant="navy">
              <CardContent className="p-4">
                <Badge variant="outline" className="mb-2">{rule.category}</Badge>
                <h4 className="font-semibold text-white mb-1">{rule.title}</h4>
                <p className="text-sm text-gray-400">{rule.description}</p>
                <Button size="sm" variant="ghost" className="mt-2">
                  Read More →
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-xl font-semibold text-white mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action, index) => {
            const Icon = action.icon;
            return (
              <motion.div
                key={index}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  variant="navy" 
                  className="cursor-pointer hover:border-basketball-orange-500 transition-all"
                  onClick={() => navigate(action.route)}
                >
                  <CardContent className="p-6">
                    <div className="flex flex-col items-center text-center">
                      <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-3`}>
                        <Icon className="h-6 w-6 text-white" />
                      </div>
                      <p className="font-semibold text-white">{action.label}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default RefereeDashboard;