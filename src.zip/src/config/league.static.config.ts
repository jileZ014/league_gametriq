// Static league configuration (replacing runtime-config)
// This file contains the configuration for a single league deployment

export interface LeagueConfig {
  // Basic Information
  leagueId: string;
  leagueName: string;
  leagueShortName: string;
  leagueTagline: string;
  leagueSlogan: string;
  
  // Branding
  logoUrl: string;
  faviconUrl: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  
  // Season/Location
  season: string;
  location: string;
  sport: string;
  division: string;
  
  // Contact
  contactEmail: string;
  contactPhone: string;
  websiteUrl: string;
  socialMedia: {
    facebook?: string;
    instagram?: string;
    twitter?: string;
  };
  
  // Firebase Configuration
  firebaseProject: string;
  firebaseSite: string;
  firestorePrefix: string;
  
  // Features (can be toggled per league)
  features: {
    tournaments: boolean;
    allStarVoting: boolean;
    liveScoring: boolean;
    mediaGallery: boolean;
  };
}

// Static configuration for this deployment
// These values should be customized for each client deployment
export const leagueConfig: LeagueConfig = {
  leagueId: 'az-flight',
  leagueName: 'AZ Flight West Valley Fall 2025 League',
  leagueShortName: 'West Valley 2025 Fall League',
  leagueTagline: 'Rise. Grind. Dominate',
  leagueSlogan: 'Rise. Grind. Dominate',
  
  logoUrl: '/gametriq-logo.png',
  faviconUrl: '/gametriq-logo.png',
  primaryColor: '#1a2332',
  secondaryColor: '#FFD700',
  accentColor: '#f97316',
  
  season: 'Fall 2025',
  location: 'West Valley',
  sport: 'Basketball',
  division: 'Competitive League',
  
  contactEmail: 'info@legacyyouthsports.com',
  contactPhone: '(602) 555-0100',
  websiteUrl: 'https://legacyyouthsports.com',
  socialMedia: {
    facebook: 'legacyyouthsportsphx',
    instagram: 'legacy_youth_phx',
    twitter: 'legacyphx'
  },
  
  firebaseProject: 'gametriq-32ed1',
  firebaseSite: 'league-2a773',
  firestorePrefix: 'legacy',
  
  features: {
    tournaments: true,
    allStarVoting: true,
    liveScoring: true,
    mediaGallery: true
  }
};

// Export helper functions for compatibility
export function getLeagueConfig(): LeagueConfig {
  return leagueConfig;
}

export function getLeagueCollection(collectionName: string): string {
  // For single-league deployment, just return the collection name
  // Remove multi-tenant prefixing
  return collectionName;
}

export function getLeagueStoragePath(path: string): string {
  // For single-league deployment, just return the path
  // Remove multi-tenant prefixing
  return path;
}

// Stub function for compatibility (does nothing in static config)
export function setDevLeague(leagueId: string): void {
  console.log('setDevLeague is not used in static configuration');
}

// Export default for backward compatibility
export default getLeagueConfig;