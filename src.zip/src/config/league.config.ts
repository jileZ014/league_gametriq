// League configuration - now using static config instead of runtime
// For client deployments, modify league.static.config.ts

export type { LeagueConfig } from './league.static.config';
export { 
  getLeagueConfig as default,
  getLeagueConfig,
  getLeagueCollection,
  getLeagueStoragePath,
  setDevLeague,
  leagueConfig
} from './league.static.config';