import type { ContractGame, ContractTeam, ContractPlayer, ContractStanding } from '../types/contract.types';

// Division configuration with unique colors
export const DIVISIONS = {
  '3rd Grade': { color: '#3B82F6', shortName: '3rd', order: 1 },
  '4th Grade': { color: '#10B981', shortName: '4th', order: 2 },
  '5th Grade': { color: '#F97316', shortName: '5th', order: 3 },
  '6th Grade': { color: '#EF4444', shortName: '6th', order: 4 },
  '7th Grade': { color: '#8B5CF6', shortName: '7th', order: 5 },
  '8th Grade': { color: '#F59E0B', shortName: '8th', order: 6 },
  'Freshman': { color: '#06B6D4', shortName: 'Fresh', order: 7 },
  'JV': { color: '#000000', shortName: 'JV', order: 8 }
};

// Team names pool
const TEAM_NAMES = [
  'Eagles', 'Hawks', 'Warriors', 'Thunder', 'Lakers', 'Celtics', 'Heat', 'Nets',
  'Bulls', 'Rockets', 'Suns', 'Mavs', 'Kings', 'Blazers', 'Nuggets', 'Jazz',
  'Wolves', 'Spurs', 'Raptors', 'Grizzlies', 'Pelicans', 'Hornets', 'Magic', 'Pistons',
  'Cavaliers', 'Pacers', 'Knicks', 'Bucks', 'Sixers', 'Wizards', 'Clippers', 'Panthers'
];

// Team emojis
const TEAM_EMOJIS = ['🦅', '🔥', '⚡', '🌟', '🏀', '🐺', '🦁', '🐯', '🦈', '🦎'];

// Player first names
const FIRST_NAMES = [
  'James', 'Michael', 'David', 'John', 'Robert', 'William', 'Chris', 'Kevin',
  'Anthony', 'Brandon', 'Tyler', 'Jason', 'Matthew', 'Daniel', 'Joseph', 'Ryan',
  'Jordan', 'Ethan', 'Mason', 'Lucas', 'Noah', 'Aiden', 'Jayden', 'Carter'
];

// Player last names
const LAST_NAMES = [
  'Johnson', 'Williams', 'Brown', 'Jones', 'Miller', 'Davis', 'Garcia', 'Rodriguez',
  'Wilson', 'Martinez', 'Anderson', 'Taylor', 'Thomas', 'Hernandez', 'Moore', 'Martin',
  'Jackson', 'Thompson', 'White', 'Lopez', 'Lee', 'Gonzalez', 'Harris', 'Clark'
];

// Venues
const VENUES = [
  'Phoenix Sports Complex - Court 1',
  'Phoenix Sports Complex - Court 2',
  'Desert Sky Recreation Center',
  'Scottsdale Community Center',
  'Mesa Athletic Center',
  'Chandler Basketball Arena',
  'Tempe Sports Complex',
  'Glendale Recreation Center'
];

// Generate random date within range
function randomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Generate random time slot
function randomTimeSlot(): string {
  const times = ['9:00 AM', '10:30 AM', '12:00 PM', '1:30 PM', '3:00 PM', '4:30 PM', '6:00 PM', '7:30 PM'];
  return times[Math.floor(Math.random() * times.length)];
}

// Generate player stats
interface PlayerStats {
  playerId: string;
  playerName: string;
  teamId: string;
  teamName: string;
  division: string;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  gamesPlayed: number;
  ppg: number;
  rpg: number;
  apg: number;
  spg: number;
  bpg: number;
  lastGame: {
    points: number;
    rebounds: number;
    assists: number;
    opponent: string;
    date: string;
  };
}

// Generate a player
function generatePlayer(teamId: string, index: number, age: number): ContractPlayer {
  const firstName = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
  const currentYear = new Date().getFullYear();
  const birthYear = currentYear - age;
  
  return {
    id: `player-${teamId}-${index}`,
    name: `${firstName} ${lastName}`,
    jerseyNumber: String(Math.floor(Math.random() * 50) + 1),
    dateOfBirth: `${birthYear}-${String(Math.floor(Math.random() * 12) + 1).padStart(2, '0')}-${String(Math.floor(Math.random() * 28) + 1).padStart(2, '0')}`,
    age: age,
    parentName: `${['Mr.', 'Mrs.', 'Ms.'][Math.floor(Math.random() * 3)]} ${lastName}`,
    emergencyContact: {
      name: `Parent ${lastName}`,
      relationship: 'Parent',
      primaryPhone: `(602) ${Math.floor(Math.random() * 900) + 100}-${Math.floor(Math.random() * 9000) + 1000}`,
      email: `${lastName.toLowerCase()}@email.com`
    },
    eligibilityStatus: 'eligible',
    teamId: teamId
  };
}

// Generate a team
function generateTeam(division: string, teamName: string, index: number): ContractTeam {
  const teamId = `team-${division.replace(/\s/g, '-').toLowerCase()}-${index}`;
  const wins = Math.floor(Math.random() * 15);
  const losses = Math.floor(Math.random() * 10);
  const pointsFor = wins * 65 + Math.floor(Math.random() * 200);
  const pointsAgainst = losses * 60 + Math.floor(Math.random() * 200);
  
  // Determine age based on division
  const ageMap: { [key: string]: number } = {
    '3rd Grade': 9,
    '4th Grade': 10,
    '5th Grade': 11,
    '6th Grade': 12,
    '7th Grade': 13,
    '8th Grade': 14,
    'Freshman': 15,
    'JV': 16
  };
  
  const age = ageMap[division] || 12;
  const roster = Array.from({ length: 8 }, (_, i) => generatePlayer(teamId, i, age));
  
  return {
    id: teamId,
    name: teamName,
    division: division,
    coachId: `coach-${teamId}`,
    coachName: `Coach ${LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)]}`,
    wins,
    losses,
    pointsFor,
    pointsAgainst,
    winPercentage: wins / (wins + losses) || 0,
    gamesPlayed: wins + losses,
    streak: Math.random() > 0.5 ? `W${Math.floor(Math.random() * 5) + 1}` : `L${Math.floor(Math.random() * 3) + 1}`,
    lastFive: `${Math.min(5, wins)}-${Math.min(5, losses)}`,
    roster,
    status: 'approved',
    registrationFee: 450,
    feePaid: true,
    paymentDate: '2025-01-01'
  };
}

// Generate a game
function generateGame(
  homeTeam: ContractTeam,
  awayTeam: ContractTeam,
  date: Date,
  gameIndex: number,
  status: 'scheduled' | 'in_progress' | 'completed'
): ContractGame {
  const gameId = `game-${date.toISOString().split('T')[0]}-${gameIndex}`;
  const isCompleted = status === 'completed';
  const isInProgress = status === 'in_progress';
  
  let homeScore = 0;
  let awayScore = 0;
  
  if (isCompleted) {
    homeScore = Math.floor(Math.random() * 40) + 35;
    awayScore = Math.floor(Math.random() * 40) + 35;
  } else if (isInProgress) {
    homeScore = Math.floor(Math.random() * 30) + 10;
    awayScore = Math.floor(Math.random() * 30) + 10;
  }
  
  return {
    id: gameId,
    homeTeamId: homeTeam.id,
    awayTeamId: awayTeam.id,
    homeTeamName: homeTeam.name,
    awayTeamName: awayTeam.name,
    homeScore,
    awayScore,
    date: date.toISOString().split('T')[0],
    time: randomTimeSlot(),
    venue: VENUES[Math.floor(Math.random() * VENUES.length)],
    venueId: `venue-${Math.floor(Math.random() * VENUES.length)}`,
    division: homeTeam.division,
    status,
    courtNumber: Math.floor(Math.random() * 3) + 1,
    officials: isCompleted || isInProgress ? ['Ref Johnson', 'Ref Smith'] : [],
    scorekeeper: isCompleted || isInProgress ? 'John Doe' : undefined,
    lastUpdated: new Date().toISOString(),
    finalizedAt: isCompleted ? new Date().toISOString() : undefined,
    finalizedBy: isCompleted ? 'system' : undefined
  };
}

// Generate standings from teams
function generateStandings(teams: ContractTeam[]): ContractStanding[] {
  const standings = teams.map(team => {
    const differential = team.pointsFor - team.pointsAgainst;
    return {
      teamId: team.id,
      teamName: team.name,
      division: team.division,
      wins: team.wins,
      losses: team.losses,
      winPercentage: team.winPercentage,
      gamesBack: 0, // Will be calculated
      pointsFor: team.pointsFor,
      pointsAgainst: team.pointsAgainst,
      differential,
      streak: team.streak,
      lastFive: team.lastFive,
      position: 0, // Will be calculated
      playoffSeed: undefined,
      clinched: undefined
    };
  });
  
  // Sort by win percentage and calculate position
  standings.sort((a, b) => b.winPercentage - a.winPercentage);
  
  standings.forEach((standing, index) => {
    standing.position = index + 1;
    if (index === 0) {
      standing.gamesBack = 0;
    } else {
      const leader = standings[0];
      const leaderWins = leader.wins;
      const leaderLosses = leader.losses;
      const gb = ((leaderWins - standing.wins) + (standing.losses - leaderLosses)) / 2;
      standing.gamesBack = Math.max(0, gb);
    }
    
    // Mark playoff seeds for top 4
    if (index < 4) {
      standing.playoffSeed = index + 1;
    }
  });
  
  return standings;
}

// Generate player statistics
function generatePlayerStats(teams: ContractTeam[]): PlayerStats[] {
  const stats: PlayerStats[] = [];
  
  teams.forEach(team => {
    team.roster.forEach(player => {
      const gamesPlayed = Math.floor(Math.random() * 10) + 5;
      const totalPoints = Math.floor(Math.random() * 200) + 50;
      const totalRebounds = Math.floor(Math.random() * 100) + 20;
      const totalAssists = Math.floor(Math.random() * 80) + 10;
      const totalSteals = Math.floor(Math.random() * 40) + 5;
      const totalBlocks = Math.floor(Math.random() * 30) + 2;
      
      stats.push({
        playerId: player.id,
        playerName: player.name,
        teamId: team.id,
        teamName: team.name,
        division: team.division,
        points: totalPoints,
        rebounds: totalRebounds,
        assists: totalAssists,
        steals: totalSteals,
        blocks: totalBlocks,
        gamesPlayed,
        ppg: Number((totalPoints / gamesPlayed).toFixed(1)),
        rpg: Number((totalRebounds / gamesPlayed).toFixed(1)),
        apg: Number((totalAssists / gamesPlayed).toFixed(1)),
        spg: Number((totalSteals / gamesPlayed).toFixed(1)),
        bpg: Number((totalBlocks / gamesPlayed).toFixed(1)),
        lastGame: {
          points: Math.floor(Math.random() * 30) + 5,
          rebounds: Math.floor(Math.random() * 15) + 2,
          assists: Math.floor(Math.random() * 10),
          opponent: TEAM_NAMES[Math.floor(Math.random() * TEAM_NAMES.length)],
          date: new Date().toISOString().split('T')[0]
        }
      });
    });
  });
  
  return stats;
}

// Main mock data generator
export function generateMockData() {
  const allTeams: ContractTeam[] = [];
  const allGames: ContractGame[] = [];
  const divisionStandings: { [key: string]: ContractStanding[] } = {};
  
  // Generate teams for each division
  Object.keys(DIVISIONS).forEach(division => {
    const divisionTeams: ContractTeam[] = [];
    const teamCount = 8 + Math.floor(Math.random() * 3); // 8-10 teams per division
    
    // Get unique team names for this division
    const availableNames = [...TEAM_NAMES];
    
    for (let i = 0; i < teamCount && i < availableNames.length; i++) {
      const randomIndex = Math.floor(Math.random() * availableNames.length);
      const teamName = availableNames.splice(randomIndex, 1)[0];
      const team = generateTeam(division, teamName, i);
      divisionTeams.push(team);
      allTeams.push(team);
    }
    
    // Generate standings for this division
    divisionStandings[division] = generateStandings(divisionTeams);
    
    // Generate games for this division
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const nextWeek = new Date(today);
    nextWeek.setDate(nextWeek.getDate() + 7);
    const lastWeek = new Date(today);
    lastWeek.setDate(lastWeek.getDate() - 7);
    
    // Generate completed games (past)
    for (let i = 0; i < 10; i++) {
      const homeTeam = divisionTeams[Math.floor(Math.random() * divisionTeams.length)];
      const awayTeam = divisionTeams.filter(t => t.id !== homeTeam.id)[Math.floor(Math.random() * (divisionTeams.length - 1))];
      const gameDate = randomDate(lastWeek, yesterday);
      const game = generateGame(homeTeam, awayTeam, gameDate, allGames.length, 'completed');
      allGames.push(game);
    }
    
    // Generate today's games (mix of scheduled, in_progress, completed)
    for (let i = 0; i < 3; i++) {
      const homeTeam = divisionTeams[Math.floor(Math.random() * divisionTeams.length)];
      const awayTeam = divisionTeams.filter(t => t.id !== homeTeam.id)[Math.floor(Math.random() * (divisionTeams.length - 1))];
      const status = i === 0 ? 'in_progress' : i === 1 ? 'completed' : 'scheduled';
      const game = generateGame(homeTeam, awayTeam, today, allGames.length, status);
      allGames.push(game);
    }
    
    // Generate upcoming games
    for (let i = 0; i < 5; i++) {
      const homeTeam = divisionTeams[Math.floor(Math.random() * divisionTeams.length)];
      const awayTeam = divisionTeams.filter(t => t.id !== homeTeam.id)[Math.floor(Math.random() * (divisionTeams.length - 1))];
      const gameDate = randomDate(tomorrow, nextWeek);
      const game = generateGame(homeTeam, awayTeam, gameDate, allGames.length, 'scheduled');
      allGames.push(game);
    }
  });
  
  // Generate player statistics
  const playerStats = generatePlayerStats(allTeams);
  
  // Sort player stats by category for leaderboards
  const leaderboards = {
    points: [...playerStats].sort((a, b) => b.ppg - a.ppg).slice(0, 20),
    rebounds: [...playerStats].sort((a, b) => b.rpg - a.rpg).slice(0, 20),
    assists: [...playerStats].sort((a, b) => b.apg - a.apg).slice(0, 20),
    steals: [...playerStats].sort((a, b) => b.spg - a.spg).slice(0, 20),
    blocks: [...playerStats].sort((a, b) => b.bpg - a.bpg).slice(0, 20)
  };
  
  // Select weekly MVPs (top scorer from each division)
  const weeklyMVPs: { [key: string]: PlayerStats } = {};
  Object.keys(DIVISIONS).forEach(division => {
    const divisionPlayers = playerStats.filter(p => p.division === division);
    if (divisionPlayers.length > 0) {
      weeklyMVPs[division] = divisionPlayers.sort((a, b) => b.ppg - a.ppg)[0];
    }
  });
  
  return {
    divisions: DIVISIONS,
    teams: allTeams,
    games: allGames,
    standings: divisionStandings,
    playerStats,
    leaderboards,
    weeklyMVPs,
    stats: {
      totalTeams: allTeams.length,
      totalGames: allGames.length,
      totalPlayers: allTeams.reduce((sum, team) => sum + team.roster.length, 0),
      liveGames: allGames.filter(g => g.status === 'in_progress').length,
      todayGames: allGames.filter(g => g.date === new Date().toISOString().split('T')[0]).length,
      completedGamesWithStats: allGames.filter(g => g.status === 'completed' && Math.random() > 0.3).length
    }
  };
}

// Get games for specific time period
export function getGamesByTimeframe(games: ContractGame[], timeframe: 'today' | 'tomorrow' | 'week' | 'results') {
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split('T')[0];
  const weekFromNow = new Date(new Date().setDate(new Date().getDate() + 7)).toISOString().split('T')[0];
  const yesterday = new Date(new Date().setDate(new Date().getDate() - 1)).toISOString().split('T')[0];
  
  switch (timeframe) {
    case 'today':
      return games.filter(g => g.date === today);
    case 'tomorrow':
      return games.filter(g => g.date === tomorrow);
    case 'week':
      return games.filter(g => g.date >= today && g.date <= weekFromNow);
    case 'results':
      return games.filter(g => g.status === 'completed' && g.date <= yesterday).slice(0, 20);
    default:
      return [];
  }
}

// Export mock data instance
export const mockData = generateMockData();