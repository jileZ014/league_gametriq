import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../firebase';
import type { UserRole } from '../types';

// Hardcoded role mappings for known test accounts
const HARDCODED_ROLES: Record<string, UserRole> = {
  // Admin accounts
  'admin@gametriq.com': 'admin',
  'admin1@gametriq.com': 'admin',
  'admin2@gametriq.com': 'admin',
  'admin3@gametriq.com': 'admin',
  
  // Coach accounts - FORCE COACH ROLE
  'coach@gametriq.com': 'coach',
  'coach1@gametriq.com': 'coach',
  'coach2@gametriq.com': 'coach',
  
  // Scorekeeper accounts
  'scorekeeper@gametriq.com': 'scorekeeper',
  'scorekeeper1@gametriq.com': 'scorekeeper',
  'scorekeeper2@gametriq.com': 'scorekeeper',
  'scorekeeper3@gametriq.com': 'scorekeeper',
  'scorekeeper4@gametriq.com': 'scorekeeper',
  'scorekeeper5@gametriq.com': 'scorekeeper',
  
  // Site Director
  'sitedirector@gametriq.com': 'siteDirector'
};

// Generate coach mappings for coach1-50@gametriq.com
for (let i = 1; i <= 50; i++) {
  HARDCODED_ROLES[`coach${i}@gametriq.com`] = 'coach';
}

// Generate scorekeeper mappings
for (let i = 1; i <= 5; i++) {
  HARDCODED_ROLES[`scorekeeper${i}@gametriq.com`] = 'scorekeeper';
}

export async function getUserRole(email: string, uid: string): Promise<UserRole> {
  const normalizedEmail = email.toLowerCase();
  
  // Check hardcoded mapping first
  if (HARDCODED_ROLES[normalizedEmail]) {
    const correctRole = HARDCODED_ROLES[normalizedEmail];
    
    // Update Firestore if role is wrong
    try {
      const userDoc = await getDoc(doc(db, 'users', uid));
      if (userDoc.exists()) {
        const currentRole = userDoc.data().role;
        
        // Fix bad role assignments
        if (currentRole === 'parent' || currentRole !== correctRole) {
          console.log(`Fixing role for ${email}: ${currentRole} -> ${correctRole}`);
          await updateDoc(doc(db, 'users', uid), { 
            role: correctRole,
            updatedAt: new Date().toISOString()
          });
        }
      } else {
        // Create user doc with correct role
        await updateDoc(doc(db, 'users', uid), {
          email: normalizedEmail,
          role: correctRole,
          createdAt: new Date().toISOString()
        });
      }
    } catch (error) {
      console.error('Error updating user role:', error);
    }
    
    return correctRole;
  }
  
  // Check Firestore for existing role
  try {
    const userDoc = await getDoc(doc(db, 'users', uid));
    if (userDoc.exists()) {
      const role = userDoc.data().role;
      
      // Fix 'parent' role to 'coach' as default
      if (role === 'parent') {
        console.log(`Fixing parent role for ${email} to coach`);
        await updateDoc(doc(db, 'users', uid), { 
          role: 'coach',
          updatedAt: new Date().toISOString()
        });
        return 'coach';
      }
      
      if (role && role !== 'parent') {
        return role as UserRole;
      }
    }
  } catch (error) {
    console.error('Error fetching user role:', error);
  }
  
  // Default to coach for any unknown user
  return 'coach';
}

// Batch fix function for existing users
export async function fixAllParentRoles() {
  console.log('Starting batch fix for parent roles...');
  
  try {
    // This would need admin SDK or cloud function in production
    // For now, we'll fix roles on login
    console.log('Parent roles will be fixed automatically on user login');
  } catch (error) {
    console.error('Error fixing parent roles:', error);
  }
}