// Test Data Generator for Multi-League System
// Generates sample data for testing league isolation

import { 
  collection, 
  addDoc, 
  setDoc, 
  serverTimestamp,
  writeBatch 
} from 'firebase/firestore';
import { db } from '../firebase';
import { 
  getLeagueCollectionRef, 
  getLeagueDocRef,
  ensureLeagueScoped,
  getLeagueConfig 
} from './firebase-helpers';

interface GeneratorOptions {
  numSeasons?: number;
  numDivisions?: number;
  numTeams?: number;
  numPlayers?: number;
  numGames?: number;
  clearExisting?: boolean;
}

export class TestDataGenerator {
  private leagueId: string;
  private leagueName: string;
  
  constructor() {
    const config = getLeagueConfig();
    this.leagueId = config.leagueId;
    this.leagueName = config.leagueName;
  }
  
  // Generate all test data
  async generateAll(options: GeneratorOptions = {}): Promise<void> {
    const {
      numSeasons = 1,
      numDivisions = 3,
      numTeams = 8,
      numPlayers = 10,
      numGames = 20,
      clearExisting = false
    } = options;
    
    console.log(`🔄 Generating test data for ${this.leagueName} (${this.leagueId})`);
    
    try {
      // Clear existing data if requested
      if (clearExisting) {
        await this.clearAllData();
      }
      
      // Generate data in order
      const seasonIds = await this.generateSeasons(numSeasons);
      const divisionIds = await this.generateDivisions(numDivisions, seasonIds[0]);
      const teamIds = await this.generateTeams(numTeams, divisionIds);
      const playerIds = await this.generatePlayers(numPlayers, teamIds);
      await this.generateGames(numGames, teamIds, seasonIds[0]);
      await this.generateStandings(teamIds, divisionIds);
      
      console.log(`✅ Test data generation complete for ${this.leagueName}`);
      console.log(`   - Seasons: ${numSeasons}`);
      console.log(`   - Divisions: ${numDivisions}`);
      console.log(`   - Teams: ${numTeams}`);
      console.log(`   - Players: ${playerIds.length}`);
      console.log(`   - Games: ${numGames}`);
      
    } catch (error) {
      console.error('❌ Error generating test data:', error);
      throw error;
    }
  }
  
  // Clear all data for current league
  async clearAllData(): Promise<void> {
    console.log(`🗑️ Clearing existing data for ${this.leagueName}`);
    
    const collectionsToC

: [
      'seasons', 'divisions', 'teams', 'players', 
      'games', 'standings', 'statistics', 'financials'
    ];
    
    // Note: In production, you'd want to properly delete documents
    // This is simplified for testing purposes
    console.log('⚠️ Data clearing not implemented - would delete collections:', collectionsToClear);
  }
  
  // Generate seasons
  async generateSeasons(count: number): Promise<string[]> {
    const seasonIds: string[] = [];
    const batch = writeBatch(db);
    
    for (let i = 0; i < count; i++) {
      const seasonRef = doc(collection(db, 'seasons');
      const seasonData = {
        name: `${this.leagueName} Season ${2025 + i}`,
        startDate: new Date(2025 + i, 0, 1).toISOString(),
        endDate: new Date(2025 + i, 3, 30).toISOString(),
        status: i === 0 ? 'active' : 'upcoming',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      
      batch.set(seasonRef, seasonData);
      seasonIds.push(seasonRef.id);
    }
    
    await batch.commit();
    return seasonIds;
  }
  
  // Generate divisions
  async generateDivisions(count: number, seasonId: string): Promise<string[]> {
    const divisionIds: string[] = [];
    const batch = writeBatch(db);
    const divisionNames = ['Elite', 'Premier', 'Select', 'Recreational', 'Developmental'];
    const ageGroups = ['U10', 'U12', 'U14', 'U16', 'U18'];
    
    for (let i = 0; i < count && i < divisionNames.length; i++) {
      const divisionRef = doc(collection(db, 'divisions');
      const divisionData = {
        name: `${divisionNames[i]} Division`,
        ageGroup: ageGroups[i],
        seasonId,
        maxTeams: 8,
        currentTeams: 0,
        status: 'active',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      
      batch.set(divisionRef, divisionData);
      divisionIds.push(divisionRef.id);
    }
    
    await batch.commit();
    return divisionIds;
  }
  
  // Generate teams
  async generateTeams(count: number, divisionIds: string[]): Promise<string[]> {
    const teamIds: string[] = [];
    const batch = writeBatch(db);
    const teamNames = [
      'Thunder', 'Lightning', 'Storm', 'Hurricanes', 'Cyclones',
      'Eagles', 'Hawks', 'Falcons', 'Ravens', 'Owls',
      'Warriors', 'Knights', 'Titans', 'Spartans', 'Vikings',
      'Blazers', 'Heat', 'Suns', 'Stars', 'Comets'
    ];
    
    for (let i = 0; i < count && i < teamNames.length; i++) {
      const teamRef = doc(collection(db, 'teams');
      const divisionId = divisionIds[i % divisionIds.length];
      
      const teamData = {
        name: `${this.leagueName} ${teamNames[i]}`,
        divisionId,
        coachId: `coach_${i}`,
        coachName: `Coach ${String.fromCharCode(65 + i)}`,
        wins: Math.floor(Math.random() * 10),
        losses: Math.floor(Math.random() * 10),
        status: 'approved',
        homeVenue: `Venue ${(i % 3) + 1}`,
        primaryColor: ['#FF0000', '#0000FF', '#00FF00', '#FFFF00', '#FF00FF'][i % 5],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      
      batch.set(teamRef, teamData);
      teamIds.push(teamRef.id);
    }
    
    await batch.commit();
    return teamIds;
  }
  
  // Generate players
  async generatePlayers(playersPerTeam: number, teamIds: string[]): Promise<string[]> {
    const playerIds: string[] = [];
    const firstNames = ['James', 'John', 'Michael', 'David', 'Chris', 'Alex', 'Ryan', 'Tyler', 'Jordan', 'Brandon'];
    const lastNames = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez'];
    
    for (const teamId of teamIds) {
      const batch = writeBatch(db);
      
      for (let i = 0; i < playersPerTeam; i++) {
        const playerRef = doc(collection(db, 'players');
        const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        
        const playerData = {
          firstName,
          lastName,
          fullName: `${firstName} ${lastName}`,
          teamId,
          jerseyNumber: String(i + 1).padStart(2, '0'),
          position: ['PG', 'SG', 'SF', 'PF', 'C'][i % 5],
          height: `${5 + Math.floor(i / 3)}'${8 + (i % 12)}"`,
          weight: 150 + (i * 5),
          birthDate: new Date(2010 - (i % 8), i % 12, (i % 28) + 1).toISOString(),
          status: 'active',
          stats: {
            gamesPlayed: 0,
            points: 0,
            rebounds: 0,
            assists: 0,
            steals: 0,
            blocks: 0
          },
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        
        batch.set(playerRef, playerData);
        playerIds.push(playerRef.id);
      }
      
      await batch.commit();
    }
    
    return playerIds;
  }
  
  // Generate games
  async generateGames(count: number, teamIds: string[], seasonId: string): Promise<string[]> {
    const gameIds: string[] = [];
    const batch = writeBatch(db);
    const venues = ['Main Arena', 'Sports Complex', 'Recreation Center', 'High School Gym'];
    
    for (let i = 0; i < count; i++) {
      const gameRef = doc(collection(db, 'games');
      
      // Pick two different teams
      const homeTeamIndex = i % teamIds.length;
      const awayTeamIndex = (i + 1 + Math.floor(i / teamIds.length) % teamIds.length;
      
      const gameDate = new Date();
      gameDate.setDate(gameDate.getDate() + i - Math.floor(count / 2);
      
      const gameData = {
        homeTeamId: teamIds[homeTeamIndex],
        awayTeamId: teamIds[awayTeamIndex],
        homeTeam: `Team ${homeTeamIndex + 1}`,
        awayTeam: `Team ${awayTeamIndex + 1}`,
        seasonId,
        date: gameDate.toISOString().split('T')[0],
        time: `${18 + (i % 4)}:${i % 2 === 0 ? '00' : '30'}`,
        venue: venues[i % venues.length],
        status: i < 5 ? 'completed' : i < 10 ? 'in_progress' : 'scheduled',
        homeScore: i < 5 ? 50 + Math.floor(Math.random() * 30) : 0,
        awayScore: i < 5 ? 50 + Math.floor(Math.random() * 30) : 0,
        quarter: i < 10 ? Math.min(4, Math.floor(i / 2) + 1) : 0,
        timeRemaining: i < 10 ? `${12 - (i % 12)}:00` : '',
        officials: [`Referee ${i % 3 + 1}`],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      
      batch.set(gameRef, gameData);
      gameIds.push(gameRef.id);
    }
    
    await batch.commit();
    return gameIds;
  }
  
  // Generate standings
  async generateStandings(teamIds: string[], divisionIds: string[]): Promise<void> {
    const batch = writeBatch(db);
    
    for (let i = 0; i < teamIds.length; i++) {
      const standingRef = doc(collection(db, 'standings'), teamIds[i]);
      const divisionId = divisionIds[i % divisionIds.length];
      
      const wins = Math.floor(Math.random() * 15);
      const losses = Math.floor(Math.random() * 15);
      
      const standingData = {
        teamId: teamIds[i],
        divisionId,
        wins,
        losses,
        winPercentage: wins / Math.max(1, wins + losses),
        pointsFor: wins * 75 + Math.floor(Math.random() * 200),
        pointsAgainst: losses * 75 + Math.floor(Math.random() * 200),
        differential: 0,
        streak: Math.random() > 0.5 ? `W${Math.floor(Math.random() * 5) + 1}` : `L${Math.floor(Math.random() * 3) + 1}`,
        lastUpdated: serverTimestamp()
      });
      
      standingData.differential = standingData.pointsFor - standingData.pointsAgainst;
      
      batch.set(standingRef, standingData);
    }
    
    await batch.commit();
  }
  
  // Generate sample user for testing
  async generateTestUser(role: string): Promise<string> {
    const userRef = doc(collection(db, 'users');
    const testEmail = `${role.toLowerCase()}_${this.leagueId}@test.com`;
    
    const userData = {
      email: testEmail,
      displayName: `Test ${role}`,
      role,
      uid: userRef.id,
      status: 'active',
      testAccount: true,
      createdAt: serverTimestamp(),
      lastLogin: serverTimestamp()
    });
    
    await setDoc(userRef, userData);
    console.log(`✅ Created test user: ${testEmail} (${role})`);
    
    return userRef.id;
  }
  
  // Verify data isolation
  async verifyDataIsolation(): Promise<boolean> {
    console.log(`🔍 Verifying data isolation for ${this.leagueName}`);
    
    try {
      // Check that data has correct league prefix
      const teamsRef = collection(db, 'teams');
      const teamsSnapshot = await getDocs(teamsRef);
      
      let allIsolated = true;
      teamsSnapshot.forEach(doc => {
        const data = doc.data();
        if (data.leagueId !== this.leagueId) {
          console.error(`❌ Found data from wrong league: ${data.leagueId}`);
          allIsolated = false;
        }
      });
      
      if (allIsolated) {
        console.log(`✅ Data isolation verified - all data belongs to ${this.leagueName}`);
      }
      
      return allIsolated;
    } catch (error) {
      console.error('❌ Error verifying data isolation:', error);
      return false;
    }
  }
}

// Export singleton for current league
export const testDataGenerator = new TestDataGenerator();

// Console helper for development
if (typeof window !== 'undefined') {
  (window as any).generateTestData = async (options?: GeneratorOptions) => {
    const generator = new TestDataGenerator();
    await generator.generateAll(options);
  };
  
  (window as any).verifyDataIsolation = async () => {
    const generator = new TestDataGenerator();
    return await generator.verifyDataIsolation();
  };
  
  console.log('%cTest Data Generator Available', 'color: #00ff00; font-weight: bold;');
  console.log('Use: generateTestData() or generateTestData({ numTeams: 10, numGames: 30 })');
  console.log('Verify: verifyDataIsolation()');
}

import { getDocs } from 'firebase/firestore';