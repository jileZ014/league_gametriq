import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  Bell, BellOff, Mail, MessageSquare, Clock,
  Smartphone, Volume2, Settings, Check, X
} from 'lucide-react';
import { notificationService, NotificationPreferences as INotificationPreferences } from '../services/NotificationService';
import { useAuth } from '../AuthContext';

export const NotificationPreferences: React.FC = () => {
  const { currentUser } = useAuth();
  const [preferences, setPreferences] = useState<INotificationPreferences | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [permissionGranted, setPermissionGranted] = useState(false);

  useEffect(() => {
    loadPreferences();
    checkPermission();
  }, [currentUser]);

  const loadPreferences = () => {
    const prefs = notificationService.getPreferences();
    if (prefs) {
      setPreferences(prefs);
    }
  };

  const checkPermission = () => {
    if ('Notification' in window) {
      setPermissionGranted(Notification.permission === 'granted');
    }
  };

  const handleRequestPermission = async () => {
    const granted = await notificationService.requestPermission();
    setPermissionGranted(granted);
  };

  const handleToggle = (field: keyof INotificationPreferences) => {
    if (!preferences) return;
    
    setPreferences({
      ...preferences,
      [field]: !preferences[field as keyof INotificationPreferences]
    });
  };

  const handleNotificationTypeToggle = (type: 'gameReminders' | 'scoreUpdates' | 'scheduleChanges' | 'paymentReminders') => {
    if (!preferences) return;
    
    setPreferences({
      ...preferences,
      [type]: !preferences[type]
    });
  };

  const handleQuietHoursToggle = () => {
    if (!preferences) return;
    
    setPreferences({
      ...preferences,
      quietHours: {
        ...preferences.quietHours,
        enabled: !preferences.quietHours.enabled
      }
    });
  };

  const handleQuietHoursTimeChange = (field: 'start' | 'end', value: string) => {
    if (!preferences) return;
    
    setPreferences({
      ...preferences,
      quietHours: {
        ...preferences.quietHours,
        [field]: value
      }
    });
  };

  const handleSave = async () => {
    if (!preferences || !currentUser) return;
    
    setSaving(true);
    try {
      await notificationService.savePreferences({
        ...preferences,
        userId: currentUser.uid
      });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (error) {
      console.error('Error saving preferences:', error);
    }
    setSaving(false);
  };

  const testNotification = () => {
    notificationService.sendNotification({
      userId: currentUser?.uid || '',
      type: 'system',
      title: 'Test Notification',
      message: 'This is a test notification to verify your settings are working correctly.',
      priority: 'medium'
    });
  };

  if (!preferences) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-basketball-orange-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Permission Status */}
      {!permissionGranted && (
        <Card variant="navy" className="border-yellow-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="h-6 w-6 text-yellow-500" />
                <div>
                  <p className="font-semibold text-white">Enable Browser Notifications</p>
                  <p className="text-sm text-gray-400">
                    Allow notifications to receive real-time updates about games and important events
                  </p>
                </div>
              </div>
              <Button variant="primary" onClick={handleRequestPermission}>
                Enable Notifications
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notification Channels */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Notification Channels</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div className="flex items-center gap-3">
                <Bell className="h-5 w-5 text-blue-500" />
                <div>
                  <p className="font-semibold text-white">Push Notifications</p>
                  <p className="text-sm text-gray-400">Receive notifications in your browser</p>
                </div>
              </div>
              <button
                onClick={() => handleToggle('push')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.push ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.push ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-green-500" />
                <div>
                  <p className="font-semibold text-white">Email Notifications</p>
                  <p className="text-sm text-gray-400">Receive updates via email</p>
                </div>
              </div>
              <button
                onClick={() => handleToggle('email')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.email ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.email ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div className="flex items-center gap-3">
                <MessageSquare className="h-5 w-5 text-purple-500" />
                <div>
                  <p className="font-semibold text-white">SMS Notifications</p>
                  <p className="text-sm text-gray-400">Receive text messages for urgent updates</p>
                </div>
              </div>
              <button
                onClick={() => handleToggle('sms')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.sms ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.sms ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notification Types */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Notification Types</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div>
                <p className="font-semibold text-white">Game Reminders</p>
                <p className="text-sm text-gray-400">Get notified before games start</p>
              </div>
              <button
                onClick={() => handleNotificationTypeToggle('gameReminders')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.gameReminders ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.gameReminders ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div>
                <p className="font-semibold text-white">Score Updates</p>
                <p className="text-sm text-gray-400">Real-time game score notifications</p>
              </div>
              <button
                onClick={() => handleNotificationTypeToggle('scoreUpdates')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.scoreUpdates ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.scoreUpdates ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div>
                <p className="font-semibold text-white">Schedule Changes</p>
                <p className="text-sm text-gray-400">Updates about game time or venue changes</p>
              </div>
              <button
                onClick={() => handleNotificationTypeToggle('scheduleChanges')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.scheduleChanges ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.scheduleChanges ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between p-4 bg-navy-800 rounded-lg">
              <div>
                <p className="font-semibold text-white">Payment Reminders</p>
                <p className="text-sm text-gray-400">Notifications about upcoming payments</p>
              </div>
              <button
                onClick={() => handleNotificationTypeToggle('paymentReminders')}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.paymentReminders ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.paymentReminders ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quiet Hours */}
      <Card variant="navy">
        <CardHeader>
          <CardTitle className="text-white">Quiet Hours</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Clock className="h-5 w-5 text-indigo-500" />
                <div>
                  <p className="font-semibold text-white">Enable Quiet Hours</p>
                  <p className="text-sm text-gray-400">Pause notifications during specific times</p>
                </div>
              </div>
              <button
                onClick={handleQuietHoursToggle}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  preferences.quietHours.enabled ? 'bg-basketball-orange-500' : 'bg-gray-600'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    preferences.quietHours.enabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>

            {preferences.quietHours.enabled && (
              <div className="grid grid-cols-2 gap-4 p-4 bg-navy-800 rounded-lg">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    Start Time
                  </label>
                  <input
                    type="time"
                    value={preferences.quietHours.start}
                    onChange={(e) => handleQuietHoursTimeChange('start', e.target.value)}
                    className="w-full p-2 bg-navy-700 border border-navy-600 rounded text-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">
                    End Time
                  </label>
                  <input
                    type="time"
                    value={preferences.quietHours.end}
                    onChange={(e) => handleQuietHoursTimeChange('end', e.target.value)}
                    className="w-full p-2 bg-navy-700 border border-navy-600 rounded text-white"
                  />
                </div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="flex justify-between items-center">
        <Button variant="secondary" onClick={testNotification}>
          <Volume2 className="h-4 w-4 mr-2" />
          Test Notification
        </Button>
        <div className="flex gap-2">
          {saved && (
            <Badge variant="success" className="py-2 px-4">
              <Check className="h-4 w-4 mr-1" />
              Saved Successfully
            </Badge>
          )}
          <Button 
            variant="primary" 
            onClick={handleSave}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Preferences'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default NotificationPreferences;