import React, { useState } from 'react';
import { useAuth } from '../AuthContext';
import { useNavigate } from 'react-router-dom';
import { doc, setDoc, updateDoc, getDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Trophy, Users, UserCheck, Flag, ClipboardList, Settings } from 'lucide-react';
import { leagueConfig } from '../config/league.config';

const RoleSelection: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [selectedRole, setSelectedRole] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const roles = [
    {
      id: 'coach',
      label: 'Coach',
      icon: Trophy,
      description: 'Manage team, roster, and practices',
      color: 'bg-blue-500'
    },
    {
      id: 'parent',
      label: 'Parent',
      icon: Users,
      description: 'View child\'s schedule and stats',
      color: 'bg-green-500'
    },
    {
      id: 'player',
      label: 'Player',
      icon: UserCheck,
      description: 'View games, stats, and team info',
      color: 'bg-purple-500'
    },
    {
      id: 'referee',
      label: 'Referee',
      icon: Flag,
      description: 'Manage game assignments',
      color: 'bg-yellow-500'
    },
    {
      id: 'scorekeeper',
      label: 'Scorekeeper',
      icon: ClipboardList,
      description: 'Enter and track live scores',
      color: 'bg-red-500'
    },
    {
      id: 'admin',
      label: 'Admin',
      icon: Settings,
      description: 'Full league administration',
      color: 'bg-gray-700'
    }
  ];

  const handleRoleSelection = async () => {
    if (!selectedRole || !currentUser) {
      setError('Please select a role');
      return;
    }

    setLoading(true);
    setError('');
    
    try {
      console.log('Saving role:', selectedRole, 'for user:', currentUser.uid);
      
      // Check if document exists
      const userDocRef = doc(db, 'users', currentUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      if (userDoc.exists()) {
        // Update existing document
        await updateDoc(userDocRef, {
          role: selectedRole,
          updatedAt: new Date().toISOString()
        });
        console.log('Updated existing user document');
      } else {
        // Create new document
        await setDoc(userDocRef, {
          uid: currentUser.uid,
          email: currentUser.email,
          displayName: currentUser.displayName,
          role: selectedRole,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        });
        console.log('Created new user document');
      }

      // Force page reload to update auth context
      window.location.href = '/dashboard';
      
    } catch (error: any) {
      console.error('Error setting role:', error);
      setError(`Failed to save role: ${error.message}`);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-navy flex items-center justify-center p-4">
      <Card variant="navy" className="max-w-4xl w-full shadow-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-display text-white">WELCOME TO {leagueConfig.leagueShortName}!</CardTitle>
          <p className="text-gray-400 mt-2">Please select your role to continue</p>
          {error && (
            <div className="mt-4 p-3 bg-red-900/20 border border-red-600 text-red-400 rounded">
              {error}
            </div>
          )}
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
            {roles.map(role => {
              const Icon = role.icon;
              return (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role.id)}
                  className={`p-6 rounded-xl border-2 transition-all transform hover:scale-105 ${
                    selectedRole === role.id
                      ? 'border-basketball-orange-500 bg-navy-800 shadow-lg'
                      : 'border-navy-700 hover:border-basketball-orange-300 bg-navy-800'
                  }`}
                >
                  <div className={`w-12 h-12 ${role.color} rounded-full flex items-center justify-center mb-4 mx-auto`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-bold text-lg mb-2 text-white">{role.label}</h3>
                  <p className="text-sm text-gray-400">{role.description}</p>
                </button>
              );
            })}
          </div>

          <Button
            onClick={handleRoleSelection}
            disabled={!selectedRole || loading}
            className="w-full btn-primary font-bold py-4 text-lg"
          >
            {loading ? 'Saving...' : `Continue as ${roles.find(r => r.id === selectedRole)?.label || '...'}`}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default RoleSelection;