import React, { useState, useMemo } from 'react';
import { Trophy, TrendingUp, Award, Target, Shield, Calendar } from 'lucide-react';
import PlayerCard from './PlayerCard';
import MVPCard from './MVPCard';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface PlayerStats {
  playerId: string;
  playerName: string;
  teamId: string;
  teamName: string;
  division: string;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  gamesPlayed: number;
  ppg: number;
  rpg: number;
  apg: number;
  spg: number;
  bpg: number;
  lastGame: {
    points: number;
    rebounds: number;
    assists: number;
    opponent: string;
    date: string;
  };
}

interface LeaderboardSectionProps {
  playerStats: PlayerStats[];
  weeklyMVPs: { [key: string]: PlayerStats };
  selectedDivision: string;
}

type StatCategory = 'points' | 'rebounds' | 'assists' | 'defense';
type Timeframe = 'season' | 'week' | 'month';

const LeaderboardSection: React.FC<LeaderboardSectionProps> = ({
  playerStats,
  weeklyMVPs,
  selectedDivision
}) => {
  const [category, setCategory] = useState<StatCategory>('points');
  const [timeframe, setTimeframe] = useState<Timeframe>('season');
  const [expandedCount, setExpandedCount] = useState(10);

  // Filter players by division
  const filteredPlayers = useMemo(() => {
    if (selectedDivision === 'all') return playerStats;
    return playerStats.filter(p => p.division === selectedDivision);
  }, [playerStats, selectedDivision]);

  // Sort players by selected category
  const sortedPlayers = useMemo(() => {
    const sorted = [...filteredPlayers];
    
    switch (category) {
      case 'points':
        return sorted.sort((a, b) => b.ppg - a.ppg);
      case 'rebounds':
        return sorted.sort((a, b) => b.rpg - a.rpg);
      case 'assists':
        return sorted.sort((a, b) => b.apg - a.apg);
      case 'defense':
        // Combined defensive rating (steals + blocks)
        return sorted.sort((a, b) => (b.spg + b.bpg) - (a.spg + a.bpg));
      default:
        return sorted;
    }
  }, [filteredPlayers, category]);

  // Get current MVP
  const currentMVP = useMemo(() => {
    if (selectedDivision === 'all') {
      // Get overall MVP (highest PPG across all divisions)
      return Object.values(weeklyMVPs).sort((a, b) => b.ppg - a.ppg)[0];
    }
    return weeklyMVPs[selectedDivision];
  }, [weeklyMVPs, selectedDivision]);

  const categories = [
    { value: 'points' as StatCategory, label: 'Points', icon: Target, color: 'text-red-400' },
    { value: 'rebounds' as StatCategory, label: 'Rebounds', icon: Trophy, color: 'text-blue-400' },
    { value: 'assists' as StatCategory, label: 'Assists', icon: TrendingUp, color: 'text-green-400' },
    { value: 'defense' as StatCategory, label: 'Defense', icon: Shield, color: 'text-purple-400' }
  ];

  const timeframes = [
    { value: 'season' as Timeframe, label: 'Season' },
    { value: 'week' as Timeframe, label: 'This Week' },
    { value: 'month' as Timeframe, label: 'This Month' }
  ];

  const getStatValue = (player: PlayerStats) => {
    switch (category) {
      case 'points': return player.ppg;
      case 'rebounds': return player.rpg;
      case 'assists': return player.apg;
      case 'defense': return (player.spg + player.bpg);
      default: return 0;
    }
  };

  const getStatLabel = () => {
    switch (category) {
      case 'points': return 'PPG';
      case 'rebounds': return 'RPG';
      case 'assists': return 'APG';
      case 'defense': return 'STL+BLK';
      default: return '';
    }
  };

  return (
    <div className="py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Award className="h-8 w-8 text-yellow-400" />
          <div>
            <h2 className="text-2xl font-bold text-white">Leaderboards</h2>
            <p className="text-sm text-gray-400">
              Through games of {new Date().toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric',
                year: 'numeric'
              })}
            </p>
          </div>
        </div>

        {/* Timeframe Selector */}
        <div className="flex gap-2">
          {timeframes.map(tf => (
            <button
              key={tf.value}
              onClick={() => setTimeframe(tf.value)}
              className={`
                px-3 py-1 rounded-lg text-sm font-medium transition-all
                ${timeframe === tf.value
                  ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/50'
                  : 'glass-button text-white hover:bg-white/10'
                }
              `}
            >
              {tf.label}
            </button>
          ))}
        </div>
      </div>

      {/* Weekly MVP Card */}
      {currentMVP && (
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-yellow-400" />
            Weekly MVP
          </h3>
          <MVPCard player={currentMVP} />
        </div>
      )}

      {/* Category Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {categories.map(cat => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.value}
              onClick={() => setCategory(cat.value)}
              className={`
                flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap
                ${category === cat.value
                  ? 'bg-gradient-to-r from-gray-800 to-gray-700 text-white shadow-lg'
                  : 'glass-button text-white hover:bg-white/10'
                }
              `}
            >
              <Icon className={`h-4 w-4 ${cat.color}`} />
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Leaders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {sortedPlayers.slice(0, expandedCount).map((player, index) => (
          <PlayerCard
            key={player.playerId}
            player={player}
            rank={index + 1}
            statCategory={category}
            statValue={getStatValue(player)}
            statLabel={getStatLabel()}
          />
        ))}
      </div>

      {/* Load More Button */}
      {sortedPlayers.length > expandedCount && (
        <div className="text-center">
          <button
            onClick={() => setExpandedCount(expandedCount + 10)}
            className="glass-button inline-flex items-center gap-2"
          >
            Show More Leaders
          </button>
        </div>
      )}

      {/* No Data Message */}
      {sortedPlayers.length === 0 && (
        <div className="glass-panel p-12 text-center">
          <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-xl text-white mb-2">No statistics available</p>
          <p className="text-gray-400">
            Player statistics will be available once games have been played
          </p>
        </div>
      )}

      {/* Stats Legend */}
      <div className="mt-8 glass-panel p-4">
        <h4 className="text-sm font-semibold text-gray-400 mb-3">Statistical Categories</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="text-red-400 font-semibold">PPG</span>
            <span className="text-gray-500 ml-2">Points Per Game</span>
          </div>
          <div>
            <span className="text-blue-400 font-semibold">RPG</span>
            <span className="text-gray-500 ml-2">Rebounds Per Game</span>
          </div>
          <div>
            <span className="text-green-400 font-semibold">APG</span>
            <span className="text-gray-500 ml-2">Assists Per Game</span>
          </div>
          <div>
            <span className="text-purple-400 font-semibold">STL+BLK</span>
            <span className="text-gray-500 ml-2">Steals + Blocks</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardSection;