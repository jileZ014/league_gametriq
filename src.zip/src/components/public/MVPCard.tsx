import React from 'react';
import { Trophy, Star, TrendingUp, Award, Zap } from 'lucide-react';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface MVPCardProps {
  player: {
    playerId: string;
    playerName: string;
    teamName: string;
    division: string;
    ppg: number;
    rpg: number;
    apg: number;
    spg: number;
    bpg: number;
    gamesPlayed: number;
  };
}

const MVPCard: React.FC<MVPCardProps> = ({ player }) => {
  const divisionConfig = DIVISIONS[player.division as keyof typeof DIVISIONS];
  const divisionColor = divisionConfig?.color || '#808080';

  const efficiencyRating = (
    player.ppg + 
    player.rpg * 1.2 + 
    player.apg * 1.5 + 
    player.spg * 2 + 
    player.bpg * 2
  ).toFixed(1);

  return (
    <div className="relative overflow-hidden">
      {/* Background Gradient */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          background: `linear-gradient(135deg, ${divisionColor} 0%, transparent 60%)`
        }}
      />
      
      <div className="glass-panel border-yellow-500/30 p-6 relative">
        {/* MVP Badge */}
        <div className="absolute top-4 right-4">
          <div className="relative">
            <div className="absolute inset-0 bg-yellow-400 blur-xl opacity-50 animate-pulse"></div>
            <div className="relative bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full p-3">
              <Trophy className="h-6 w-6 text-black" />
            </div>
          </div>
        </div>

        <div className="flex gap-6">
          {/* Player Photo Placeholder */}
          <div className="flex-shrink-0">
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center border-4 border-yellow-500/30">
              <Star className="h-12 w-12 md:h-16 md:w-16 text-yellow-400" />
            </div>
          </div>

          {/* Player Info */}
          <div className="flex-1">
            <div className="mb-4">
              <h3 className="text-2xl font-bold text-white mb-1">{player.playerName}</h3>
              <div className="flex items-center gap-3">
                <span className="text-gray-400">{player.teamName}</span>
                <span 
                  className="px-2 py-1 text-xs font-semibold rounded-full"
                  style={{
                    backgroundColor: `${divisionColor}20`,
                    color: divisionColor
                  }}
                >
                  {player.division}
                </span>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
              <div className="text-center">
                <div className="text-2xl font-bold text-red-400">{player.ppg.toFixed(1)}</div>
                <div className="text-xs text-gray-400">PPG</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-400">{player.rpg.toFixed(1)}</div>
                <div className="text-xs text-gray-400">RPG</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">{player.apg.toFixed(1)}</div>
                <div className="text-xs text-gray-400">APG</div>
              </div>
              <div className="text-center hidden md:block">
                <div className="text-2xl font-bold text-purple-400">{player.spg.toFixed(1)}</div>
                <div className="text-xs text-gray-400">SPG</div>
              </div>
              <div className="text-center hidden md:block">
                <div className="text-2xl font-bold text-orange-400">{player.bpg.toFixed(1)}</div>
                <div className="text-xs text-gray-400">BPG</div>
              </div>
            </div>

            {/* Efficiency Rating */}
            <div className="mt-4 flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Zap className="h-4 w-4 text-yellow-400" />
                <span className="text-sm text-gray-400">Efficiency:</span>
                <span className="text-lg font-bold text-yellow-400">{efficiencyRating}</span>
              </div>
              <div className="flex items-center gap-2">
                <Award className="h-4 w-4 text-cyan-400" />
                <span className="text-sm text-gray-400">Games:</span>
                <span className="text-lg font-bold text-white">{player.gamesPlayed}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Achievement Badges */}
        <div className="mt-4 flex gap-2">
          {player.ppg > 20 && (
            <span className="px-2 py-1 bg-red-500/20 text-red-400 text-xs font-semibold rounded-full">
              20+ PPG Scorer
            </span>
          )}
          {player.rpg > 10 && (
            <span className="px-2 py-1 bg-blue-500/20 text-blue-400 text-xs font-semibold rounded-full">
              Double-Digit Rebounder
            </span>
          )}
          {player.apg > 5 && (
            <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-semibold rounded-full">
              Elite Playmaker
            </span>
          )}
          <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-semibold rounded-full animate-pulse">
            Week's Best Player
          </span>
        </div>
      </div>
    </div>
  );
};

export default MVPCard;