import React, { useState, useEffect } from 'react';
import { X, Trophy, Calendar, Activity, Users, Home, Menu } from 'lucide-react';
import { leagueConfig } from '../../config/league.config';
import '../../styles/legacy-sports.css';

interface MobileMenuProps {
  activeSection: string;
  onNavigate: (section: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const MobileMenu: React.FC<MobileMenuProps> = ({ 
  activeSection, 
  onNavigate, 
  isOpen, 
  onClose 
}) => {
  const [isAnimating, setIsAnimating] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setIsAnimating(true);
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  const handleNavigate = (section: string) => {
    onNavigate(section);
    onClose();
  };

  const menuItems = [
    { id: 'home', label: 'Home', icon: Home, color: 'text-white' },
    { id: 'standings', label: 'Standings', icon: Trophy, color: 'text-yellow-400' },
    { id: 'schedule', label: 'Schedule', icon: Calendar, color: 'text-cyan-400' },
    { id: 'leaderboard', label: 'Leaderboard', icon: Activity, color: 'text-green-400' },
    { id: 'teams', label: 'Teams', icon: Users, color: 'text-purple-400' }
  ];

  if (!isOpen && !isAnimating) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className={`fixed inset-0 bg-black/80 backdrop-blur-sm z-40 transition-opacity duration-300 ${
          isOpen ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={onClose}
        onAnimationEnd={() => !isOpen && setIsAnimating(false)}
      />

      {/* Menu Panel */}
      <div 
        className={`fixed right-0 top-0 h-full w-80 max-w-[80vw] bg-gradient-to-b from-gray-900 to-black z-50 shadow-2xl transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="p-6 border-b border-gray-800">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-display text-white">MENU</h2>
              <p className="text-sm text-gray-400 mt-1">{leagueConfig.leagueName}</p>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 transition-colors spring-click"
            >
              <X className="w-6 h-6 text-white" />
            </button>
          </div>
        </div>

        {/* Menu Items */}
        <div className="p-4">
          {menuItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = activeSection === item.id;
            
            return (
              <button
                key={item.id}
                onClick={() => handleNavigate(item.id)}
                className={`w-full flex items-center gap-4 p-4 rounded-xl transition-all spring-click mb-2 ${
                  isActive 
                    ? 'bg-gradient-to-r from-yellow-400/20 to-transparent border-l-4 border-yellow-400' 
                    : 'hover:bg-white/5'
                } stagger-item`}
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className={`p-2 rounded-full bg-white/10 ${isActive ? 'scale-110' : ''}`}>
                  <Icon className={`w-6 h-6 ${item.color}`} />
                </div>
                <div className="text-left">
                  <p className={`font-heading font-bold ${isActive ? 'text-yellow-400' : 'text-white'}`}>
                    {item.label.toUpperCase()}
                  </p>
                  {isActive && (
                    <p className="text-xs text-gray-400">Currently Viewing</p>
                  )}
                </div>
                {isActive && (
                  <div className="ml-auto">
                    <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Quick Stats */}
        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-gray-800 bg-black/50 backdrop-blur">
          <div className="grid grid-cols-2 gap-4 text-center">
            <div>
              <p className="text-2xl font-display text-yellow-400">32</p>
              <p className="text-xs text-gray-400 uppercase">Teams</p>
            </div>
            <div>
              <p className="text-2xl font-display text-green-400">400+</p>
              <p className="text-xs text-gray-400 uppercase">Players</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default MobileMenu;