import React, { useState, useMemo, useEffect } from 'react';
import { Trophy, TrendingUp, TrendingDown, Crown, Flame, ChevronUp, ChevronDown } from 'lucide-react';
import type { ContractStanding } from '../../types/contract.types';
import { DIVISIONS } from '../../utils/mockDataGenerator';
import { useStaggerAnimation } from '../../hooks/useCountUp';
import '../../styles/legacy-sports.css';

interface TeamStandingsProps {
  standings: { [key: string]: ContractStanding[] };
  selectedDivision: string;
  onDivisionChange: (division: string) => void;
}

const TeamStandings: React.FC<TeamStandingsProps> = ({ 
  standings, 
  selectedDivision, 
  onDivisionChange 
}) => {
  const [sortColumn, setSortColumn] = useState<keyof ContractStanding>('position');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Get standings for selected division
  const currentStandings = useMemo(() => {
    if (selectedDivision === 'all') {
      const combined: ContractStanding[] = [];
      Object.values(standings).forEach(divisionStandings => {
        combined.push(...divisionStandings.slice(0, 3)); // Top 3 from each division
      });
      return combined.sort((a, b) => b.winPercentage - a.winPercentage);
    }
    return standings[selectedDivision] || [];
  }, [standings, selectedDivision]);

  // Sort standings
  const sortedStandings = useMemo(() => {
    const sorted = [...currentStandings];
    sorted.sort((a, b) => {
      const aVal = a[sortColumn];
      const bVal = b[sortColumn];
      
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
      }
      
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDirection === 'asc' 
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      
      return 0;
    });
    return sorted;
  }, [currentStandings, sortColumn, sortDirection]);

  // Animate rows on load
  const visibleRows = useStaggerAnimation(sortedStandings.length, 200, 50);

  const handleSort = (column: keyof ContractStanding) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('desc');
    }
  };

  const getTeamEmoji = (teamName: string) => {
    const emojis = ['🦅', '⚡', '🔥', '🌟', '🏀', '🐺', '🦁', '🐯', '🦈', '🎯'];
    return emojis[teamName.charCodeAt(0) % emojis.length];
  };

  const renderStreak = (streak: string) => {
    const type = streak[0];
    const count = parseInt(streak.substring(1));
    const isWin = type === 'W';
    
    if (isWin && count >= 3) {
      return (
        <div className="streak-hot flex items-center gap-1">
          <Flame className="w-4 h-4" />
          <span className="font-bold">{type}{count}</span>
        </div>
      );
    }
    
    return (
      <span className={`px-3 py-1 rounded-full text-xs font-bold ${
        isWin 
          ? 'bg-green-500/20 text-green-400' 
          : 'bg-red-500/20 text-red-400'
      }`}>
        {type}{count}
      </span>
    );
  };

  const renderLastFive = (lastFive: string) => {
    const [wins, losses] = lastFive.split('-').map(Number);
    const games = [];
    
    for (let i = 0; i < wins && i < 5; i++) {
      games.push('W');
    }
    for (let i = 0; i < losses && i < 5 - wins; i++) {
      games.push('L');
    }
    
    return (
      <div className="flex gap-1">
        {games.map((result, index) => (
          <div
            key={index}
            className={`w-2.5 h-2.5 rounded-full ${
              result === 'W' 
                ? 'bg-gradient-to-br from-green-400 to-green-600' 
                : 'bg-gradient-to-br from-red-400 to-red-600'
            }`}
            title={result === 'W' ? 'Win' : 'Loss'}
          />
        ))}
      </div>
    );
  };

  const SortIcon: React.FC<{ column: keyof ContractStanding }> = ({ column }) => {
    if (sortColumn !== column) {
      return <span className="text-gray-600 text-xs">—</span>;
    }
    return sortDirection === 'asc' 
      ? <ChevronUp className="h-3 w-3 text-yellow-400" />
      : <ChevronDown className="h-3 w-3 text-yellow-400" />;
  };

  const playoffLine = selectedDivision === 'all' ? -1 : 4;

  return (
    <div className="py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-3xl font-display text-white mb-2">TEAM STANDINGS</h2>
          <p className="text-gray-400">
            {selectedDivision === 'all' ? 'Top Teams Across All Divisions' : selectedDivision}
          </p>
        </div>

        {/* Division Selector */}
        <select
          value={selectedDivision}
          onChange={(e) => onDivisionChange(e.target.value)}
          className="glass-input px-4 py-2 pr-10 font-heading bg-black/50 border-gray-700 focus:border-yellow-400"
        >
          <option value="all">All Divisions</option>
          {Object.keys(DIVISIONS).map(division => (
            <option key={division} value={division}>
              {division}
            </option>
          ))}
        </select>
      </div>

      {/* Standings Table */}
      <div className="premium-card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-800 bg-black/50">
                <th className="text-left p-4 sticky left-0 bg-black/50 backdrop-blur z-10">
                  <button
                    onClick={() => handleSort('position')}
                    className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors font-heading"
                  >
                    RANK
                    <SortIcon column="position" />
                  </button>
                </th>
                <th className="text-left p-4">
                  <button
                    onClick={() => handleSort('teamName')}
                    className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors font-heading"
                  >
                    TEAM
                    <SortIcon column="teamName" />
                  </button>
                </th>
                {selectedDivision === 'all' && (
                  <th className="text-left p-4">
                    <span className="text-gray-400 font-heading">DIV</span>
                  </th>
                )}
                <th className="text-center p-4">
                  <button
                    onClick={() => handleSort('wins')}
                    className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors font-heading mx-auto"
                  >
                    W
                    <SortIcon column="wins" />
                  </button>
                </th>
                <th className="text-center p-4">
                  <button
                    onClick={() => handleSort('losses')}
                    className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors font-heading mx-auto"
                  >
                    L
                    <SortIcon column="losses" />
                  </button>
                </th>
                <th className="text-center p-4">
                  <button
                    onClick={() => handleSort('winPercentage')}
                    className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors font-heading mx-auto"
                  >
                    WIN%
                    <SortIcon column="winPercentage" />
                  </button>
                </th>
                <th className="text-center p-4">
                  <button
                    onClick={() => handleSort('gamesBack')}
                    className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors font-heading mx-auto"
                  >
                    GB
                    <SortIcon column="gamesBack" />
                  </button>
                </th>
                <th className="text-center p-4 hidden md:table-cell">
                  <span className="text-gray-400 font-heading">STRK</span>
                </th>
                <th className="text-center p-4 hidden lg:table-cell">
                  <span className="text-gray-400 font-heading">L5</span>
                </th>
              </tr>
            </thead>
            <tbody>
              {sortedStandings.map((standing, index) => {
                const divisionConfig = DIVISIONS[standing.division as keyof typeof DIVISIONS];
                const divisionColor = divisionConfig?.color || '#808080';
                const isVisible = visibleRows.includes(index);
                
                return (
                  <React.Fragment key={standing.teamId}>
                    <tr 
                      className={`
                        team-row border-b border-gray-800/50 cursor-pointer
                        ${index === 0 ? 'team-rank-1' : ''}
                        ${!isVisible ? 'opacity-0' : 'opacity-100'}
                      `}
                      style={{
                        animation: isVisible ? 'slideInRight 0.5s ease-out' : 'none',
                        animationDelay: `${index * 0.05}s`,
                        animationFillMode: 'both'
                      }}
                      onClick={() => console.log('View team:', standing.teamName)}
                    >
                      {/* Rank */}
                      <td className="p-4 sticky left-0 bg-black/90 backdrop-blur z-10">
                        <div className="flex items-center gap-2">
                          {index === 0 && (
                            <div className="relative">
                              <Crown className="w-6 h-6 text-yellow-400 animate-crown-pulse" />
                              <span className="absolute -bottom-1 -right-1 text-xs font-bold text-yellow-400">1</span>
                            </div>
                          )}
                          {index === 1 && (
                            <div className="w-7 h-7 bg-gradient-to-br from-gray-300 to-gray-500 rounded-full flex items-center justify-center">
                              <span className="text-black font-bold text-sm">2</span>
                            </div>
                          )}
                          {index === 2 && (
                            <div className="w-7 h-7 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center">
                              <span className="text-white font-bold text-sm">3</span>
                            </div>
                          )}
                          {index > 2 && (
                            <span className="text-white font-heading font-bold text-lg ml-1">{index + 1}</span>
                          )}
                        </div>
                      </td>

                      {/* Team */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <span className="text-2xl">{getTeamEmoji(standing.teamName)}</span>
                          <div>
                            <p className="font-heading font-bold text-white hover:text-yellow-400 transition-colors">
                              {standing.teamName}
                            </p>
                            {standing.clinched && (
                              <span className="text-xs text-green-400">
                                {standing.clinched === 'playoff' ? '✓ Playoff' : '✓ Division'}
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Division (if showing all) */}
                      {selectedDivision === 'all' && (
                        <td className="p-4">
                          <span 
                            className="px-2 py-1 text-xs font-bold rounded-full text-white"
                            style={{
                              background: `linear-gradient(135deg, ${divisionColor}, ${divisionColor}dd)`,
                              boxShadow: `0 2px 8px ${divisionColor}30`
                            }}
                          >
                            {divisionConfig?.shortName}
                          </span>
                        </td>
                      )}

                      {/* Stats */}
                      <td className="text-center p-4">
                        <span className="font-display text-xl text-white">{standing.wins}</span>
                      </td>
                      <td className="text-center p-4">
                        <span className="font-display text-xl text-gray-400">{standing.losses}</span>
                      </td>
                      <td className="text-center p-4">
                        <span className="font-display text-xl text-green-400">
                          .{Math.round(standing.winPercentage * 1000)}
                        </span>
                      </td>
                      <td className="text-center p-4">
                        <span className="text-gray-400">
                          {standing.gamesBack === 0 ? '—' : standing.gamesBack.toFixed(1)}
                        </span>
                      </td>
                      <td className="text-center p-4 hidden md:table-cell">
                        {renderStreak(standing.streak)}
                      </td>
                      <td className="text-center p-4 hidden lg:table-cell">
                        <div className="flex justify-center">
                          {renderLastFive(standing.lastFive)}
                        </div>
                      </td>
                    </tr>

                    {/* Playoff Line */}
                    {playoffLine > 0 && index === playoffLine - 1 && (
                      <tr>
                        <td colSpan={selectedDivision === 'all' ? 10 : 9} className="p-0">
                          <div className="playoff-line">
                            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-black px-4">
                              <span className="text-xs font-bold text-yellow-400 tracking-wider">
                                PLAYOFF LINE
                              </span>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default TeamStandings;