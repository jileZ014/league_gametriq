import React from 'react';
import { X, Trophy, Calendar, Users, BarChart3, Home } from 'lucide-react';

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (section: string) => void;
  socialLinks: Array<{ icon: any; href: string; label: string }>;
}

const MobileNav: React.FC<MobileNavProps> = ({ isOpen, onClose, onNavigate, socialLinks }) => {
  const menuItems = [
    { icon: Home, label: 'HOME', value: 'home' },
    { icon: Trophy, label: 'STANDINGS', value: 'standings' },
    { icon: Calendar, label: 'SCHEDULE', value: 'schedule' },
    { icon: BarChart3, label: 'LEADERBOARD', value: 'leaderboard' },
    { icon: Users, label: 'TEAMS', value: 'teams' }
  ];

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Slide-out Menu */}
      <div 
        className={`
          fixed top-0 right-0 h-full w-80 max-w-[85vw] z-50 
          glass-panel border-0 rounded-l-2xl
          transform transition-transform duration-300 ease-in-out lg:hidden
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        `}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <h2 className="text-xl font-bold text-white">Menu</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Close menu"
          >
            <X className="h-6 w-6 text-white" />
          </button>
        </div>

        {/* Navigation Items */}
        <nav className="p-6">
          <ul className="space-y-2">
            {menuItems.map(({ icon: Icon, label, value }) => (
              <li key={value}>
                <button
                  onClick={() => onNavigate(value)}
                  className="w-full flex items-center gap-4 p-3 rounded-lg hover:bg-white/10 transition-colors text-left"
                >
                  <Icon className="h-5 w-5 text-gray-400" />
                  <span className="text-white font-medium">{label}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>

        {/* Social Links */}
        <div className="absolute bottom-0 left-0 right-0 p-6 border-t border-gray-800">
          <p className="text-sm text-gray-400 mb-4">Follow Us</p>
          <div className="flex gap-4">
            {socialLinks.map(({ icon: Icon, href, label }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                className="p-3 glass-button rounded-lg"
                onClick={(e) => {
                  e.preventDefault();
                  console.log(`Navigate to ${label}`);
                }}
              >
                <Icon className="h-5 w-5 text-white" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default MobileNav;