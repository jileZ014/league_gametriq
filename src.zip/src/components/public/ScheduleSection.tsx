import React, { useState, useMemo } from 'react';
import { Calendar, Filter, ChevronDown, Trophy, Shield } from 'lucide-react';
import GameList from './GameList';
import FilterBar from './FilterBar';
import type { ContractGame, ContractTeam } from '../../types/contract.types';
import { getGamesByTimeframe } from '../../utils/mockDataGenerator';

interface ScheduleSectionProps {
  games: ContractGame[];
  teams: ContractTeam[];
  selectedDivision: string;
}

type ViewMode = 'today' | 'tomorrow' | 'week' | 'results';

const ScheduleSection: React.FC<ScheduleSectionProps> = ({ 
  games, 
  teams, 
  selectedDivision 
}) => {
  const [viewMode, setViewMode] = useState<ViewMode>('today');
  const [teamFilter, setTeamFilter] = useState<string>('all');
  const [showPlayoffOnly, setShowPlayoffOnly] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());

  // Filter games by division
  const divisionFilteredGames = useMemo(() => {
    if (selectedDivision === 'all') return games;
    return games.filter(g => g.division === selectedDivision);
  }, [games, selectedDivision]);

  // Get games for selected timeframe
  const timeframeGames = useMemo(() => {
    return getGamesByTimeframe(divisionFilteredGames, viewMode);
  }, [divisionFilteredGames, viewMode]);

  // Apply team filter
  const filteredGames = useMemo(() => {
    let filtered = timeframeGames;
    
    if (teamFilter !== 'all') {
      filtered = filtered.filter(g => 
        g.homeTeamId === teamFilter || g.awayTeamId === teamFilter
      );
    }
    
    if (showPlayoffOnly) {
      // Mock playoff games (random selection for demo)
      filtered = filtered.filter(() => Math.random() > 0.7);
    }
    
    return filtered;
  }, [timeframeGames, teamFilter, showPlayoffOnly]);

  // Group games by date
  const groupedGames = useMemo(() => {
    const groups: { [key: string]: ContractGame[] } = {};
    
    filteredGames.forEach(game => {
      if (!groups[game.date]) {
        groups[game.date] = [];
      }
      groups[game.date].push(game);
    });
    
    return groups;
  }, [filteredGames]);

  const toggleSection = (date: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(date)) {
      newExpanded.delete(date);
    } else {
      newExpanded.add(date);
    }
    setExpandedSections(newExpanded);
  };

  const formatDateHeader = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    }
    if (date.toDateString() === tomorrow.toDateString()) {
      return 'Tomorrow';
    }
    
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'short',
      day: 'numeric'
    });
  };

  const viewModes: { value: ViewMode; label: string; count: number }[] = [
    { value: 'today', label: 'Today', count: getGamesByTimeframe(divisionFilteredGames, 'today').length },
    { value: 'tomorrow', label: 'Tomorrow', count: getGamesByTimeframe(divisionFilteredGames, 'tomorrow').length },
    { value: 'week', label: 'This Week', count: getGamesByTimeframe(divisionFilteredGames, 'week').length },
    { value: 'results', label: 'Results', count: getGamesByTimeframe(divisionFilteredGames, 'results').length }
  ];

  // Get teams for selected division
  const divisionTeams = useMemo(() => {
    if (selectedDivision === 'all') return teams;
    return teams.filter(t => t.division === selectedDivision);
  }, [teams, selectedDivision]);

  return (
    <div className="py-8">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Calendar className="h-8 w-8 text-cyan-400" />
        <div>
          <h2 className="text-2xl font-bold text-white">Schedule & Results</h2>
          <p className="text-sm text-gray-400">
            {filteredGames.length} games {viewMode === 'results' ? 'completed' : 'scheduled'}
          </p>
        </div>
      </div>

      {/* View Mode Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {viewModes.map(mode => (
          <button
            key={mode.value}
            onClick={() => setViewMode(mode.value)}
            className={`
              px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap
              ${viewMode === mode.value
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/30'
                : 'glass-button text-white hover:bg-white/10'
              }
            `}
          >
            {mode.label}
            {mode.count > 0 && (
              <span className="ml-2 px-2 py-0.5 bg-black/30 rounded-full text-xs">
                {mode.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Filters */}
      <FilterBar
        teams={divisionTeams}
        teamFilter={teamFilter}
        onTeamFilterChange={setTeamFilter}
        showPlayoffOnly={showPlayoffOnly}
        onPlayoffFilterChange={setShowPlayoffOnly}
      />

      {/* Games List */}
      {Object.keys(groupedGames).length > 0 ? (
        <div className="space-y-6">
          {Object.entries(groupedGames)
            .sort((a, b) => {
              // Sort by date (ascending for upcoming, descending for results)
              if (viewMode === 'results') {
                return b[0].localeCompare(a[0]);
              }
              return a[0].localeCompare(b[0]);
            })
            .map(([date, dateGames], index) => {
              const isExpanded = expandedSections.has(date) || index < 2; // First 2 sections expanded by default
              
              return (
                <div key={date} className="glass-panel p-4">
                  {/* Date Header */}
                  <button
                    onClick={() => toggleSection(date)}
                    className="w-full flex items-center justify-between mb-4 hover:text-cyan-400 transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <h3 className="text-lg font-semibold text-white">
                        {formatDateHeader(date)}
                      </h3>
                      <span className="px-2 py-1 bg-cyan-500/20 text-cyan-400 text-xs font-semibold rounded-full">
                        {dateGames.length} {dateGames.length === 1 ? 'game' : 'games'}
                      </span>
                    </div>
                    <ChevronDown 
                      className={`h-5 w-5 text-gray-400 transition-transform ${
                        isExpanded ? 'rotate-180' : ''
                      }`}
                    />
                  </button>

                  {/* Games for this date */}
                  {isExpanded && (
                    <GameList 
                      games={dateGames}
                      showDate={false}
                    />
                  )}
                </div>
              );
            })}
        </div>
      ) : (
        <div className="glass-panel p-12 text-center">
          <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-xl text-white mb-2">No games found</p>
          <p className="text-gray-400">
            {teamFilter !== 'all' 
              ? 'No games found for the selected team'
              : `No games ${viewMode === 'results' ? 'completed' : 'scheduled'} for ${viewMode}`}
          </p>
        </div>
      )}

      {/* Special Games Indicators */}
      {filteredGames.some(() => Math.random() > 0.7) && (
        <div className="mt-6 flex flex-wrap gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Trophy className="h-4 w-4 text-yellow-400" />
            <span className="text-gray-400">Championship Game</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-purple-400" />
            <span className="text-gray-400">Playoff Game</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ScheduleSection;