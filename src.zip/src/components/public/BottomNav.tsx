import React from 'react';
import { Home, Trophy, Calendar, BarChart3, Users } from 'lucide-react';

interface BottomNavProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

const BottomNav: React.FC<BottomNavProps> = ({ activeSection, onNavigate }) => {
  const navItems = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'standings', label: 'Standings', icon: Trophy },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'leaderboard', label: 'Stats', icon: BarChart3 },
    { id: 'teams', label: 'Teams', icon: Users }
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 glass-panel border-0 rounded-t-2xl lg:hidden z-40">
      <div className="flex justify-around items-center py-2 px-4 safe-area-inset">
        {navItems.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => onNavigate(id)}
            className={`flex flex-col items-center justify-center p-2 rounded-lg transition-all min-w-[60px] ${
              activeSection === id
                ? 'text-cyan-400'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Icon className={`h-5 w-5 mb-1 ${
              activeSection === id ? 'scale-110' : ''
            }`} />
            <span className="text-xs font-medium">{label}</span>
            {activeSection === id && (
              <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-1 bg-cyan-400 rounded-full" />
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default BottomNav;