import React, { useState, useEffect } from 'react';
import { Menu, X, Instagram, Facebook, Twitter, LogIn } from 'lucide-react';
import DivisionTabs from './DivisionTabs';
import MobileNav from './MobileNav';
import { useNavigate } from 'react-router-dom';
import { leagueConfig } from '../../config/league.config';

interface HeaderProps {
  selectedDivision: string;
  onDivisionChange: (division: string) => void;
  onNavigate: (section: string) => void;
}

const Header: React.FC<HeaderProps> = ({ selectedDivision, onDivisionChange, onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = ['STANDINGS', 'SCHEDULE', 'LEADERBOARD', 'TEAMS'];
  const socialLinks = [
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Twitter, href: '#', label: 'Twitter' }
  ];

  return (
    <>
      <header 
        className={`sticky top-0 z-50 transition-all duration-300 ${
          isScrolled 
            ? 'glass-panel border-0 rounded-none backdrop-blur-xl shadow-xl' 
            : 'bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4">
          {/* Top Bar */}
          <div className="flex items-center justify-between py-4">
            {/* Logo and Season */}
            <div className="flex items-center gap-4">
              {/* Logo Image */}
              <img 
                src={leagueConfig.logoUrl}
                alt={`${leagueConfig.leagueName} Logo`}
                className="w-14 h-14 md:w-16 md:h-16 rounded-full object-cover shadow-lg shadow-yellow-400/30"
                style={{ animation: 'pulse-live 3s ease-in-out infinite' }}
              />
              <div 
                className="cursor-pointer" 
                onClick={() => onNavigate('home')}
              >
                <h1 className="text-2xl md:text-3xl font-bold text-gradient font-display tracking-wider">
                  {leagueConfig.leagueShortName}
                </h1>
                <p className="text-sm text-gray-400">{leagueConfig.location} {leagueConfig.sport} • {leagueConfig.season}</p>
              </div>
            </div>

            {/* Desktop Navigation and Login */}
            <div className="hidden lg:flex items-center gap-6">
              <nav className="flex items-center gap-6">
                {navItems.map(item => (
                  <button
                    key={item}
                    onClick={() => onNavigate(item.toLowerCase())}
                    className="text-white hover:text-yellow-400 transition-colors font-medium font-heading"
                  >
                    {item}
                  </button>
                ))}
              </nav>
              
              {/* Login Button */}
              <button
                onClick={() => navigate('/login')}
                className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-yellow-400 to-yellow-600 text-black font-bold rounded-full hover:scale-105 transition-transform font-heading"
              >
                <LogIn className="w-4 h-4" />
                LOGIN
              </button>
            </div>

            {/* Mobile Menu Toggle and Login */}
            <div className="lg:hidden flex items-center gap-2">
              <button
                onClick={() => navigate('/login')}
                className="p-2 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full text-black"
                aria-label="Login"
              >
                <LogIn className="h-5 w-5" />
              </button>
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-white p-2"
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </button>
            </div>
          </div>

          {/* Division Tabs */}
          <DivisionTabs 
            selectedDivision={selectedDivision}
            onDivisionChange={onDivisionChange}
          />
        </div>
      </header>

      {/* Mobile Navigation */}
      <MobileNav 
        isOpen={isMobileMenuOpen}
        onClose={() => setIsMobileMenuOpen(false)}
        onNavigate={(section) => {
          onNavigate(section);
          setIsMobileMenuOpen(false);
        }}
        socialLinks={socialLinks}
      />
    </>
  );
};

export default Header;