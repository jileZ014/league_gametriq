import React, { useState, useMemo } from 'react';
import { Trophy, TrendingUp, TrendingDown, RefreshCw } from 'lucide-react';
import StandingsTable from './StandingsTable';
import type { ContractStanding } from '../../types/contract.types';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface StandingsSectionProps {
  standings: { [key: string]: ContractStanding[] };
  selectedDivision: string;
  onDivisionChange: (division: string) => void;
}

const StandingsSection: React.FC<StandingsSectionProps> = ({ 
  standings, 
  selectedDivision, 
  onDivisionChange 
}) => {
  const [sortColumn, setSortColumn] = useState<keyof ContractStanding>('position');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [lastUpdated] = useState(new Date());

  // Get standings for selected division or combine all
  const currentStandings = useMemo(() => {
    if (selectedDivision === 'all') {
      // Combine all standings and re-sort by win percentage
      const combined: ContractStanding[] = [];
      Object.values(standings).forEach(divisionStandings => {
        combined.push(...divisionStandings);
      });
      return combined.sort((a, b) => b.winPercentage - a.winPercentage);
    }
    return standings[selectedDivision] || [];
  }, [standings, selectedDivision]);

  // Sort standings based on selected column
  const sortedStandings = useMemo(() => {
    const sorted = [...currentStandings];
    sorted.sort((a, b) => {
      const aVal = a[sortColumn];
      const bVal = b[sortColumn];
      
      if (typeof aVal === 'number' && typeof bVal === 'number') {
        return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
      }
      
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortDirection === 'asc' 
          ? aVal.localeCompare(bVal)
          : bVal.localeCompare(aVal);
      }
      
      return 0;
    });
    return sorted;
  }, [currentStandings, sortColumn, sortDirection]);

  const handleSort = (column: keyof ContractStanding) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('desc');
    }
  };

  // Find playoff line (typically top 4 or 6 teams)
  const playoffLine = selectedDivision === 'all' ? -1 : 4;

  return (
    <div className="py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Trophy className="h-8 w-8 text-yellow-400" />
          <div>
            <h2 className="text-2xl font-bold text-white">Standings</h2>
            <p className="text-sm text-gray-400">
              Last updated: {lastUpdated.toLocaleString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </p>
          </div>
        </div>

        {/* Division Selector Dropdown */}
        <div className="relative">
          <select
            value={selectedDivision}
            onChange={(e) => onDivisionChange(e.target.value)}
            className="glass-input pr-10 appearance-none cursor-pointer"
          >
            <option value="all">All Divisions</option>
            {Object.keys(DIVISIONS).map(division => (
              <option key={division} value={division}>
                {division}
              </option>
            ))}
          </select>
          <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
            <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 mb-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-green-500 rounded-full"></div>
          <span className="text-gray-400">Clinched Playoff</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
          <span className="text-gray-400">In Contention</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-red-500 rounded-full"></div>
          <span className="text-gray-400">Eliminated</span>
        </div>
        <div className="flex items-center gap-2">
          <TrendingUp className="h-4 w-4 text-green-400" />
          <span className="text-gray-400">Win Streak</span>
        </div>
        <div className="flex items-center gap-2">
          <TrendingDown className="h-4 w-4 text-red-400" />
          <span className="text-gray-400">Loss Streak</span>
        </div>
      </div>

      {/* Standings Table */}
      {sortedStandings.length > 0 ? (
        <StandingsTable 
          standings={sortedStandings}
          onSort={handleSort}
          sortColumn={sortColumn}
          sortDirection={sortDirection}
          playoffLine={playoffLine}
          showDivision={selectedDivision === 'all'}
        />
      ) : (
        <div className="glass-panel p-12 text-center">
          <Trophy className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-xl text-white mb-2">No standings available</p>
          <p className="text-gray-400">
            {selectedDivision === 'all' 
              ? 'No team standings are currently available'
              : `No standings found for ${selectedDivision}`}
          </p>
        </div>
      )}

      {/* Refresh Button */}
      <div className="mt-6 text-center">
        <button 
          onClick={() => console.log('Refresh standings')}
          className="glass-button inline-flex items-center gap-2"
        >
          <RefreshCw className="h-4 w-4" />
          Refresh Standings
        </button>
      </div>
    </div>
  );
};

export default StandingsSection;