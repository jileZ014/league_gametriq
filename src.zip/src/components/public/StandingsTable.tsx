import React from 'react';
import { ChevronUp, ChevronDown, Minus } from 'lucide-react';
import type { ContractStanding } from '../../types/contract.types';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface StandingsTableProps {
  standings: ContractStanding[];
  onSort: (column: keyof ContractStanding) => void;
  sortColumn: keyof ContractStanding;
  sortDirection: 'asc' | 'desc';
  playoffLine: number;
  showDivision?: boolean;
}

const StandingsTable: React.FC<StandingsTableProps> = ({
  standings,
  onSort,
  sortColumn,
  sortDirection,
  playoffLine,
  showDivision = false
}) => {
  const renderSortIcon = (column: keyof ContractStanding) => {
    if (sortColumn !== column) {
      return <Minus className="h-3 w-3 text-gray-600" />;
    }
    return sortDirection === 'asc' 
      ? <ChevronUp className="h-3 w-3 text-cyan-400" />
      : <ChevronDown className="h-3 w-3 text-cyan-400" />;
  };

  const renderStreak = (streak: string) => {
    const type = streak[0];
    const count = streak.substring(1);
    const isWin = type === 'W';
    
    return (
      <span className={`px-2 py-1 rounded text-xs font-semibold ${
        isWin ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
      }`}>
        {type}{count}
      </span>
    );
  };

  const renderLastFive = (lastFive: string) => {
    const [wins, losses] = lastFive.split('-').map(Number);
    const games = [];
    
    for (let i = 0; i < wins; i++) {
      games.push('W');
    }
    for (let i = 0; i < losses; i++) {
      games.push('L');
    }
    
    return (
      <div className="flex gap-1">
        {games.slice(0, 5).map((result, index) => (
          <div
            key={index}
            className={`w-2 h-2 rounded-full ${
              result === 'W' ? 'bg-green-400' : 'bg-red-400'
            }`}
            title={result === 'W' ? 'Win' : 'Loss'}
          />
        ))}
      </div>
    );
  };

  const getTeamRowClass = (standing: ContractStanding, index: number) => {
    if (standing.clinched === 'playoff' || standing.playoffSeed) {
      return 'bg-green-500/5 hover:bg-green-500/10';
    }
    if (standing.clinched === 'eliminated') {
      return 'bg-red-500/5 hover:bg-red-500/10';
    }
    return 'hover:bg-white/5';
  };

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-gray-800">
            <th className="text-left p-3">
              <button
                onClick={() => onSort('position')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors"
              >
                Rank
                {renderSortIcon('position')}
              </button>
            </th>
            <th className="text-left p-3">
              <button
                onClick={() => onSort('teamName')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors"
              >
                Team
                {renderSortIcon('teamName')}
              </button>
            </th>
            {showDivision && (
              <th className="text-left p-3">
                <button
                  onClick={() => onSort('division')}
                  className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors"
                >
                  Division
                  {renderSortIcon('division')}
                </button>
              </th>
            )}
            <th className="text-center p-3">
              <button
                onClick={() => onSort('wins')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors mx-auto"
              >
                W
                {renderSortIcon('wins')}
              </button>
            </th>
            <th className="text-center p-3">
              <button
                onClick={() => onSort('losses')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors mx-auto"
              >
                L
                {renderSortIcon('losses')}
              </button>
            </th>
            <th className="text-center p-3">
              <button
                onClick={() => onSort('winPercentage')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors mx-auto"
              >
                WIN%
                {renderSortIcon('winPercentage')}
              </button>
            </th>
            <th className="text-center p-3">
              <button
                onClick={() => onSort('gamesBack')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors mx-auto"
              >
                GB
                {renderSortIcon('gamesBack')}
              </button>
            </th>
            <th className="text-center p-3 hidden md:table-cell">
              <button
                onClick={() => onSort('differential')}
                className="flex items-center gap-1 text-gray-400 hover:text-white transition-colors mx-auto"
              >
                DIFF
                {renderSortIcon('differential')}
              </button>
            </th>
            <th className="text-center p-3 hidden lg:table-cell">
              <span className="text-gray-400">STRK</span>
            </th>
            <th className="text-center p-3 hidden lg:table-cell">
              <span className="text-gray-400">L5</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {standings.map((standing, index) => {
            const divisionConfig = DIVISIONS[standing.division as keyof typeof DIVISIONS];
            const isAbovePlayoffLine = playoffLine > 0 && index < playoffLine;
            const isBelowPlayoffLine = playoffLine > 0 && index === playoffLine;
            
            return (
              <React.Fragment key={standing.teamId}>
                <tr 
                  className={`border-b border-gray-800/50 transition-colors cursor-pointer ${getTeamRowClass(standing, index)}`}
                  onClick={() => console.log('View team:', standing.teamName)}
                >
                  {/* Rank */}
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      {index < 3 && (
                        <div 
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
                            ${index === 0 ? 'bg-yellow-500 text-black' : 
                              index === 1 ? 'bg-gray-400 text-black' : 
                              'bg-orange-600 text-white'}`}
                        >
                          {index + 1}
                        </div>
                      )}
                      {index >= 3 && (
                        <span className="text-white font-medium ml-1">{index + 1}</span>
                      )}
                      {standing.clinched === 'playoff' && (
                        <span className="text-green-400 text-xs">✓</span>
                      )}
                      {standing.clinched === 'eliminated' && (
                        <span className="text-red-400 text-xs">✗</span>
                      )}
                    </div>
                  </td>

                  {/* Team Name */}
                  <td className="p-3">
                    <div className="font-semibold text-white hover:text-cyan-400 transition-colors">
                      {standing.teamName}
                    </div>
                  </td>

                  {/* Division (if showing all) */}
                  {showDivision && (
                    <td className="p-3">
                      <span 
                        className="px-2 py-1 text-xs font-semibold rounded-full"
                        style={{
                          backgroundColor: `${divisionConfig?.color}20`,
                          color: divisionConfig?.color
                        }}
                      >
                        {divisionConfig?.shortName}
                      </span>
                    </td>
                  )}

                  {/* Wins */}
                  <td className="text-center p-3 text-white font-medium">
                    {standing.wins}
                  </td>

                  {/* Losses */}
                  <td className="text-center p-3 text-white font-medium">
                    {standing.losses}
                  </td>

                  {/* Win Percentage */}
                  <td className="text-center p-3">
                    <span className="text-green-400 font-semibold">
                      .{Math.round(standing.winPercentage * 1000)}
                    </span>
                  </td>

                  {/* Games Back */}
                  <td className="text-center p-3 text-gray-400">
                    {standing.gamesBack === 0 ? '-' : standing.gamesBack.toFixed(1)}
                  </td>

                  {/* Differential */}
                  <td className="text-center p-3 hidden md:table-cell">
                    <span className={standing.differential > 0 ? 'text-green-400' : 'text-red-400'}>
                      {standing.differential > 0 && '+'}{standing.differential}
                    </span>
                  </td>

                  {/* Streak */}
                  <td className="text-center p-3 hidden lg:table-cell">
                    {renderStreak(standing.streak)}
                  </td>

                  {/* Last 5 */}
                  <td className="text-center p-3 hidden lg:table-cell">
                    <div className="flex justify-center">
                      {renderLastFive(standing.lastFive)}
                    </div>
                  </td>
                </tr>

                {/* Playoff Line */}
                {isBelowPlayoffLine && (
                  <tr>
                    <td colSpan={showDivision ? 11 : 10} className="p-0">
                      <div className="relative py-2">
                        <div className="absolute inset-0 flex items-center">
                          <div className="w-full border-t-2 border-dashed border-yellow-500/50"></div>
                        </div>
                        <div className="relative flex justify-center">
                          <span className="bg-black px-3 text-xs text-yellow-500 font-semibold">
                            PLAYOFF LINE
                          </span>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default StandingsTable;