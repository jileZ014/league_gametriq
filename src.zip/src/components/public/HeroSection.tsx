import React, { useEffect, useState } from 'react';
import { Trophy, Users, MapPin, Activity, ChevronRight, Star } from 'lucide-react';
import { useCountUp } from '../../hooks/useCountUp';
import { leagueConfig } from '../../config/league.config';

interface HeroSectionProps {
  totalPlayers: number;
  totalTeams: number;
  totalDivisions: number;
  liveGamesCount: number;
  onNavigate: (section: string) => void;
}

const HeroSection: React.FC<HeroSectionProps> = ({
  totalPlayers = 400,
  totalTeams = 32,
  totalDivisions = 8,
  liveGamesCount = 0,
  onNavigate
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const playersCount = useCountUp(totalPlayers, isVisible);
  const teamsCount = useCountUp(totalTeams, isVisible);

  useEffect(() => {
    // Trigger animations after component mounts
    setTimeout(() => setIsVisible(true), 100);
  }, []);

  return (
    <section className="hero-section relative min-h-[60vh] md:min-h-[65vh] overflow-hidden">
      {/* Background with Court Pattern */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0"
          style={{
            background: 'linear-gradient(135deg, rgba(26,26,46,0.95) 0%, rgba(15,15,30,0.98) 100%)',
            zIndex: 1
          }}
        />
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'url(/court-pattern.svg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
            zIndex: 0
          }}
        />
      </div>

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden" style={{ zIndex: 1 }}>
        <div className="absolute top-10 left-10 w-64 h-64 bg-gradient-to-br from-yellow-500/10 to-transparent rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-10 right-10 w-96 h-96 bg-gradient-to-tl from-orange-500/10 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 py-16 md:py-20">
        <div className="text-center">
          {/* League Logo */}
          <div className="mb-6 inline-block">
            <div className="w-24 h-24 md:w-32 md:h-32 mx-auto mb-4 rounded-full bg-white flex items-center justify-center shadow-2xl animate-float overflow-hidden">
              <img 
                src={leagueConfig.logoUrl} 
                alt={`${leagueConfig.leagueName} Logo`} 
                className="w-full h-full object-contain"
              />
            </div>
          </div>

          {/* Main Title with Premium Typography */}
          <h1 className="hero-title mb-4 animate-fadeInScale" style={{ animationDelay: '0.2s' }}>
            {leagueConfig.leagueShortName}
          </h1>
          
          {/* Subtitle */}
          <div className="hero-subtitle mb-8 animate-fadeInScale" style={{ animationDelay: '0.3s' }}>
            <span className="text-yellow-400">{leagueConfig.leagueTagline}</span>
            <span className="mx-3 text-gray-600">•</span>
            <span>{leagueConfig.leagueSlogan}</span>
          </div>

          {/* Live Games Indicator */}
          {liveGamesCount > 0 && (
            <div className="mb-8 animate-fadeInScale" style={{ animationDelay: '0.4s' }}>
              <div className="live-indicator inline-flex">
                <span className="live-dot"></span>
                <span className="text-red-400 font-semibold">
                  {liveGamesCount} {liveGamesCount === 1 ? 'Game' : 'Games'} In Progress
                </span>
              </div>
            </div>
          )}

          {/* Stats Bar */}
          <div className="stats-bar inline-flex mb-10 animate-fadeInScale" style={{ animationDelay: '0.5s' }}>
            <div className="stats-bar-item">
              <Users className="w-5 h-5 text-yellow-400" />
              <span>{playersCount}+</span> Players
            </div>
            <div className="hidden md:block w-px h-6 bg-gray-700" />
            <div className="stats-bar-item">
              <Star className="w-5 h-5 text-yellow-400" />
              <span>{teamsCount}</span> Teams
            </div>
            <div className="hidden md:block w-px h-6 bg-gray-700" />
            <div className="stats-bar-item">
              <Trophy className="w-5 h-5 text-yellow-400" />
              <span>{totalDivisions}</span> Divisions
            </div>
            <div className="hidden md:block w-px h-6 bg-gray-700" />
            <div className="stats-bar-item">
              <MapPin className="w-5 h-5 text-yellow-400" />
              <span>5</span> Venues
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fadeInScale" style={{ animationDelay: '0.6s' }}>
            <button
              onClick={() => onNavigate('schedule')}
              className="btn-premium group"
            >
              View Today's Games
              <ChevronRight className="inline-block ml-2 w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
            
            <button
              onClick={() => onNavigate('standings')}
              className="px-8 py-4 rounded-full font-heading font-bold text-white border-2 border-white/20 hover:border-yellow-400/50 hover:bg-white/10 transition-all hover:scale-105 hover:shadow-lg"
            >
              See Standings
            </button>
            
            <button
              onClick={() => onNavigate('register')}
              className="px-8 py-4 rounded-full font-heading font-bold text-gray-400 border-2 border-gray-700 hover:border-gray-600 hover:text-white transition-all hover:scale-105"
            >
              Join Our League
            </button>
          </div>

          {/* Quick Links */}
          <div className="mt-12 flex justify-center gap-8 text-sm animate-fadeInScale" style={{ animationDelay: '0.7s' }}>
            <button 
              onClick={() => onNavigate('leaderboard')}
              className="text-gray-400 hover:text-yellow-400 transition-colors group"
            >
              <Activity className="w-4 h-4 inline-block mr-1 group-hover:animate-bounce" />
              Top Players
            </button>
            <button 
              onClick={() => onNavigate('schedule')}
              className="text-gray-400 hover:text-yellow-400 transition-colors group"
            >
              <Trophy className="w-4 h-4 inline-block mr-1 group-hover:animate-bounce" />
              Playoffs
            </button>
            <button 
              className="text-gray-400 hover:text-yellow-400 transition-colors group"
            >
              <Users className="w-4 h-4 inline-block mr-1 group-hover:animate-bounce" />
              Teams
            </button>
          </div>
        </div>
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent z-10" />
    </section>
  );
};

export default HeroSection;