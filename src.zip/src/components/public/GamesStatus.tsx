import React from 'react';
import { Clock, Activity, CheckCircle, Calendar, TrendingUp, AlertCircle } from 'lucide-react';
import GameCard from './GameCard';
import type { ContractGame } from '../../types/contract.types';

interface GamesStatusProps {
  games: ContractGame[];
  selectedDivision: string;
}

const GamesStatus: React.FC<GamesStatusProps> = ({ games, selectedDivision }) => {
  const today = new Date().toISOString().split('T')[0];
  const tomorrow = new Date(new Date().setDate(new Date().getDate() + 1)).toISOString().split('T')[0];
  const weekFromNow = new Date(new Date().setDate(new Date().getDate() + 7)).toISOString().split('T')[0];

  // Filter games by division if needed
  const filteredGames = selectedDivision === 'all' 
    ? games 
    : games.filter(g => g.division === selectedDivision);

  // Categorize games
  const upcomingGames = filteredGames.filter(g => 
    g.status === 'scheduled' && g.date >= today
  ).slice(0, 3);

  const inProgressGames = filteredGames.filter(g => 
    g.status === 'in_progress'
  );

  const completedGames = filteredGames.filter(g => 
    g.status === 'completed'
  ).slice(0, 3);

  // Calculate stats
  const todayGames = filteredGames.filter(g => g.date === today).length;
  const tomorrowGames = filteredGames.filter(g => g.date === tomorrow).length;
  const weekGames = filteredGames.filter(g => g.date >= today && g.date <= weekFromNow).length;

  // Check if any completed games have stats updated (mock - 70% have stats)
  const gamesWithStats = completedGames.filter(() => Math.random() > 0.3);

  return (
    <div className="py-8">
      {/* Game Counts */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="glass-panel p-4 text-center">
          <Calendar className="h-8 w-8 text-cyan-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{todayGames}</div>
          <div className="text-sm text-gray-400">Today</div>
        </div>
        <div className="glass-panel p-4 text-center">
          <TrendingUp className="h-8 w-8 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{tomorrowGames}</div>
          <div className="text-sm text-gray-400">Tomorrow</div>
        </div>
        <div className="glass-panel p-4 text-center">
          <Activity className="h-8 w-8 text-purple-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{weekGames}</div>
          <div className="text-sm text-gray-400">This Week</div>
        </div>
      </div>

      {/* In Progress Games - Priority Display */}
      {inProgressGames.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Activity className="h-6 w-6 text-orange-400 animate-pulse" />
            <h3 className="text-xl font-bold text-white">Live Games</h3>
            <span className="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs font-semibold rounded-full animate-pulse">
              LIVE
            </span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {inProgressGames.map(game => (
              <GameCard key={game.id} game={game} variant="live" />
            ))}
          </div>
        </div>
      )}

      {/* Completed Games with Stats Indicator */}
      {completedGames.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <CheckCircle className="h-6 w-6 text-green-400" />
            <h3 className="text-xl font-bold text-white">Recently Completed</h3>
            {gamesWithStats.length > 0 && (
              <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-semibold rounded-full flex items-center gap-1">
                <CheckCircle className="h-3 w-3" />
                {gamesWithStats.length} with stats
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {completedGames.map(game => (
              <GameCard 
                key={game.id} 
                game={game} 
                variant="completed"
                hasStats={Math.random() > 0.3}
              />
            ))}
          </div>
        </div>
      )}

      {/* Upcoming Games */}
      {upcomingGames.length > 0 && (
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-4">
            <Clock className="h-6 w-6 text-blue-400" />
            <h3 className="text-xl font-bold text-white">Upcoming Games</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {upcomingGames.map(game => (
              <GameCard key={game.id} game={game} variant="upcoming" />
            ))}
          </div>
        </div>
      )}

      {/* No Games Message */}
      {filteredGames.length === 0 && (
        <div className="glass-panel p-12 text-center">
          <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
          <p className="text-xl text-white mb-2">No games found</p>
          <p className="text-gray-400">
            {selectedDivision === 'all' 
              ? 'No games are currently scheduled'
              : `No games found for ${selectedDivision}`}
          </p>
        </div>
      )}
    </div>
  );
};

export default GamesStatus;