import React, { useState, useRef } from 'react';
import { Clock, MapPin, Calendar, Trophy, Shield, Activity, ChevronLeft, ChevronRight, Star } from 'lucide-react';
import type { ContractGame } from '../../types/contract.types';
import { DIVISIONS } from '../../utils/mockDataGenerator';
import '../../styles/legacy-sports.css';

interface GameShowcaseProps {
  games: ContractGame[];
  selectedDivision: string;
}

const GameShowcase: React.FC<GameShowcaseProps> = ({ games, selectedDivision }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  const today = new Date().toISOString().split('T')[0];
  
  // Filter games by division
  const filteredGames = selectedDivision === 'all' 
    ? games 
    : games.filter(g => g.division === selectedDivision);

  // Categorize games
  const liveGames = filteredGames.filter(g => g.status === 'in_progress');
  const upcomingToday = filteredGames.filter(g => 
    g.status === 'scheduled' && g.date === today
  ).slice(0, 6);
  const completedToday = filteredGames.filter(g => 
    g.status === 'completed' && g.date === today
  ).slice(0, 3);

  // Combine for showcase (prioritize live games)
  const showcaseGames = [...liveGames, ...upcomingToday, ...completedToday].slice(0, 8);
  
  // Select featured game (first live game or first upcoming)
  const featuredGame = liveGames[0] || upcomingToday[0] || completedToday[0];

  const checkScrollButtons = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 1);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 320;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
      setTimeout(checkScrollButtons, 300);
    }
  };

  const getTeamEmoji = (teamName: string) => {
    const emojis = ['🦅', '⚡', '🔥', '🌟', '🏀', '🐺', '🦁', '🐯', '🦈', '🎯'];
    return emojis[teamName.charCodeAt(0) % emojis.length];
  };

  const GameCard: React.FC<{ game: ContractGame; isFeatured?: boolean }> = ({ game, isFeatured = false }) => {
    const divisionConfig = DIVISIONS[game.division as keyof typeof DIVISIONS];
    const divisionColor = divisionConfig?.color || '#808080';
    const isLive = game.status === 'in_progress';
    const isCompleted = game.status === 'completed';

    return (
      <div 
        className={`
          game-card premium-card interactive-card
          ${isFeatured ? 'game-card-featured hover-glow' : ''}
          ${isLive ? 'game-card-live pulse-hover' : ''}
          ${isFeatured ? 'md:col-span-2 md:row-span-2' : ''}
        `}
        style={{ animationDelay: `${Math.random() * 0.3}s` }}
      >
        {/* Featured Badge */}
        {isFeatured && (
          <div className="absolute top-4 right-4 z-10">
            <div className="flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full badge-bounce">
              <Star className="w-4 h-4 text-black" />
              <span className="text-xs font-bold text-black">GAME OF THE DAY</span>
            </div>
          </div>
        )}

        {/* Division & Status */}
        <div className="flex items-center justify-between mb-4">
          <span 
            className="px-3 py-1 text-xs font-bold rounded-full text-white"
            style={{
              background: `linear-gradient(135deg, ${divisionColor}, ${divisionColor}dd)`,
              boxShadow: `0 2px 10px ${divisionColor}40`
            }}
          >
            {game.division}
          </span>
          
          {isLive && (
            <div className="live-indicator">
              <span className="live-dot"></span>
              <span className="text-xs font-bold text-red-400">LIVE</span>
            </div>
          )}

          {isCompleted && (
            <span className="px-3 py-1 bg-green-500/20 text-green-400 text-xs font-bold rounded-full">
              FINAL
            </span>
          )}
        </div>

        {/* Teams */}
        <div className={`space-y-${isFeatured ? '4' : '3'}`}>
          {/* Home Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className={`${isFeatured ? 'text-3xl' : 'text-2xl'}`}>
                {getTeamEmoji(game.homeTeamName)}
              </span>
              <div>
                <p className={`font-heading font-bold text-white ${isFeatured ? 'text-xl' : 'text-lg'}`}>
                  {game.homeTeamName}
                </p>
                <p className="text-xs text-gray-500">HOME</p>
              </div>
            </div>
            {(isLive || isCompleted) && (
              <span className={`font-display ${isFeatured ? 'text-5xl' : 'text-3xl'} ${
                isCompleted && game.homeScore > game.awayScore ? 'text-yellow-400' : 'text-white'
              }`}>
                {game.homeScore}
              </span>
            )}
          </div>

          {/* VS Divider */}
          <div className="flex items-center justify-center">
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent"></div>
            <span className="px-3 text-xs text-gray-500 font-bold">VS</span>
            <div className="flex-1 h-px bg-gradient-to-r from-transparent via-gray-700 to-transparent"></div>
          </div>

          {/* Away Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className={`${isFeatured ? 'text-3xl' : 'text-2xl'}`}>
                {getTeamEmoji(game.awayTeamName)}
              </span>
              <div>
                <p className={`font-heading font-bold text-white ${isFeatured ? 'text-xl' : 'text-lg'}`}>
                  {game.awayTeamName}
                </p>
                <p className="text-xs text-gray-500">AWAY</p>
              </div>
            </div>
            {(isLive || isCompleted) && (
              <span className={`font-display ${isFeatured ? 'text-5xl' : 'text-3xl'} ${
                isCompleted && game.awayScore > game.homeScore ? 'text-yellow-400' : 'text-white'
              }`}>
                {game.awayScore}
              </span>
            )}
          </div>
        </div>

        {/* Game Info */}
        <div className={`mt-${isFeatured ? '6' : '4'} pt-${isFeatured ? '6' : '4'} border-t border-gray-800`}>
          <div className="flex items-center justify-between text-sm text-gray-400">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4" />
              <span>{game.time}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4" />
              <span>{game.venue}</span>
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (showcaseGames.length === 0) {
    return (
      <div className="py-12">
        <div className="premium-card p-12 text-center">
          <Calendar className="w-16 h-16 text-gray-600 mx-auto mb-4" />
          <h3 className="text-2xl font-heading text-white mb-2">No Games Today</h3>
          <p className="text-gray-400">Check back tomorrow for more exciting matchups!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-3xl font-display text-white mb-2">TODAY'S GAMES</h2>
          <p className="text-gray-400">
            {liveGames.length > 0 && (
              <span className="text-red-400 font-semibold">
                {liveGames.length} LIVE • 
              </span>
            )}
            {upcomingToday.length} Upcoming • {completedToday.length} Completed
          </p>
        </div>
        
        {/* Mobile Scroll Buttons */}
        <div className="flex gap-2 lg:hidden">
          <button
            onClick={() => scroll('left')}
            disabled={!canScrollLeft}
            className={`p-2 rounded-full ${
              canScrollLeft 
                ? 'bg-white/10 hover:bg-white/20' 
                : 'bg-white/5 opacity-50 cursor-not-allowed'
            } transition-all`}
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => scroll('right')}
            disabled={!canScrollRight}
            className={`p-2 rounded-full ${
              canScrollRight 
                ? 'bg-white/10 hover:bg-white/20' 
                : 'bg-white/5 opacity-50 cursor-not-allowed'
            } transition-all`}
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Desktop Grid / Mobile Scroll */}
      <div className="hidden lg:grid lg:grid-cols-3 gap-6">
        {featuredGame && (
          <GameCard game={featuredGame} isFeatured={true} />
        )}
        {showcaseGames
          .filter(g => g.id !== featuredGame?.id)
          .slice(0, 4)
          .map(game => (
            <GameCard key={game.id} game={game} />
          ))}
      </div>

      {/* Mobile Horizontal Scroll */}
      <div 
        ref={scrollRef}
        onScroll={checkScrollButtons}
        className="lg:hidden flex gap-4 overflow-x-auto scrollbar-hide pb-4"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {showcaseGames.map(game => (
          <div key={game.id} className="flex-shrink-0 w-80">
            <GameCard game={game} isFeatured={game.id === featuredGame?.id} />
          </div>
        ))}
      </div>

      {/* View All Games Link */}
      <div className="text-center mt-8">
        <button className="text-gray-400 hover:text-yellow-400 transition-colors font-heading font-semibold group">
          View Full Schedule
          <ChevronRight className="inline-block ml-1 w-4 h-4 transition-transform group-hover:translate-x-1" />
        </button>
      </div>
    </div>
  );
};

export default GameShowcase;