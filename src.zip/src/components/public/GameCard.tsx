import React from 'react';
import { MapPin, Clock, Calendar, CheckCircle, BarChart3, Bell, Navigation, Activity } from 'lucide-react';
import type { ContractGame } from '../../types/contract.types';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface GameCardProps {
  game: ContractGame;
  variant: 'upcoming' | 'live' | 'completed';
  hasStats?: boolean;
}

const GameCard: React.FC<GameCardProps> = ({ game, variant, hasStats = false }) => {
  const divisionConfig = DIVISIONS[game.division as keyof typeof DIVISIONS];
  const divisionColor = divisionConfig?.color || '#808080';

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      weekday: 'short'
    });
  };

  const getCardStyles = () => {
    switch (variant) {
      case 'live':
        return 'border-orange-500/50 animate-pulse-border';
      case 'completed':
        return 'border-green-500/30';
      case 'upcoming':
      default:
        return 'border-gray-700/50';
    }
  };

  return (
    <div className={`glass-panel ${getCardStyles()} overflow-hidden`}>
      {/* Division Badge */}
      <div 
        className="h-1 w-full"
        style={{ backgroundColor: divisionColor }}
      />
      
      <div className="p-4">
        {/* Status Badge */}
        <div className="flex items-center justify-between mb-3">
          <span 
            className="px-2 py-1 text-xs font-semibold rounded-full"
            style={{
              backgroundColor: `${divisionColor}20`,
              color: divisionColor
            }}
          >
            {game.division}
          </span>
          
          {variant === 'live' && (
            <span className="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs font-semibold rounded-full animate-pulse flex items-center gap-1">
              <span className="w-2 h-2 bg-orange-400 rounded-full animate-pulse"></span>
              LIVE
            </span>
          )}
          
          {variant === 'completed' && hasStats && (
            <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-semibold rounded-full flex items-center gap-1">
              <CheckCircle className="h-3 w-3" />
              Stats Updated
            </span>
          )}

          {variant === 'completed' && !hasStats && (
            <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-semibold rounded-full">
              Stats Pending
            </span>
          )}
        </div>

        {/* Teams */}
        <div className="space-y-3 mb-4">
          {/* Home Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">HOME</span>
              <span className="font-semibold text-white">{game.homeTeamName}</span>
            </div>
            {(variant === 'live' || variant === 'completed') && (
              <span className="text-2xl font-bold text-white">{game.homeScore}</span>
            )}
          </div>

          {/* Away Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-400">AWAY</span>
              <span className="font-semibold text-white">{game.awayTeamName}</span>
            </div>
            {(variant === 'live' || variant === 'completed') && (
              <span className="text-2xl font-bold text-white">{game.awayScore}</span>
            )}
          </div>
        </div>

        {/* Game Info */}
        <div className="space-y-2 text-sm text-gray-400">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            <span>{formatDate(game.date)}</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span>{game.time}</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span>{game.venue}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-4 flex gap-2">
          {variant === 'upcoming' && (
            <>
              <button 
                onClick={() => console.log('Set reminder for', game.id)}
                className="flex-1 glass-button py-2 px-3 text-xs font-medium flex items-center justify-center gap-1"
              >
                <Bell className="h-3 w-3" />
                Reminder
              </button>
              <button 
                onClick={() => console.log('Get directions for', game.venue)}
                className="flex-1 glass-button py-2 px-3 text-xs font-medium flex items-center justify-center gap-1"
              >
                <Navigation className="h-3 w-3" />
                Directions
              </button>
            </>
          )}
          
          {variant === 'completed' && hasStats && (
            <button 
              onClick={() => console.log('View box score for', game.id)}
              className="w-full glass-button py-2 px-3 text-xs font-medium flex items-center justify-center gap-1"
            >
              <BarChart3 className="h-3 w-3" />
              View Box Score
            </button>
          )}

          {variant === 'live' && (
            <button 
              onClick={() => console.log('View live stats for', game.id)}
              className="w-full glass-button py-2 px-3 text-xs font-medium flex items-center justify-center gap-1 animate-pulse"
            >
              <Activity className="h-3 w-3" />
              Live Stats
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default GameCard;