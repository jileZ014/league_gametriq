import React from 'react';
import '../../styles/legacy-sports.css';

interface LoadingSkeletonProps {
  type?: 'game-card' | 'standings-row' | 'player-card' | 'hero' | 'full';
  count?: number;
}

const LoadingSkeleton: React.FC<LoadingSkeletonProps> = ({ type = 'full', count = 1 }) => {
  const GameCardSkeleton = () => (
    <div className="premium-card p-6 animate-pulse">
      <div className="flex justify-between mb-4">
        <div className="skeleton h-6 w-24 rounded-full"></div>
        <div className="skeleton h-6 w-16 rounded-full"></div>
      </div>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="skeleton w-12 h-12 rounded-full"></div>
            <div className="skeleton h-6 w-32"></div>
          </div>
          <div className="skeleton h-10 w-10"></div>
        </div>
        <div className="skeleton h-px w-full"></div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="skeleton w-12 h-12 rounded-full"></div>
            <div className="skeleton h-6 w-32"></div>
          </div>
          <div className="skeleton h-10 w-10"></div>
        </div>
      </div>
      <div className="mt-4 pt-4 border-t border-gray-800">
        <div className="flex justify-between">
          <div className="skeleton h-4 w-20"></div>
          <div className="skeleton h-4 w-24"></div>
        </div>
      </div>
    </div>
  );

  const StandingsRowSkeleton = () => (
    <tr className="border-b border-gray-800/50">
      <td className="p-4">
        <div className="skeleton h-7 w-7 rounded-full"></div>
      </td>
      <td className="p-4">
        <div className="flex items-center gap-3">
          <div className="skeleton w-8 h-8 rounded-full"></div>
          <div className="skeleton h-5 w-32"></div>
        </div>
      </td>
      <td className="p-4 text-center">
        <div className="skeleton h-6 w-8 mx-auto"></div>
      </td>
      <td className="p-4 text-center">
        <div className="skeleton h-6 w-8 mx-auto"></div>
      </td>
      <td className="p-4 text-center">
        <div className="skeleton h-6 w-12 mx-auto"></div>
      </td>
      <td className="p-4 text-center">
        <div className="skeleton h-6 w-10 mx-auto"></div>
      </td>
      <td className="p-4 text-center hidden md:table-cell">
        <div className="skeleton h-5 w-12 mx-auto rounded-full"></div>
      </td>
      <td className="p-4 text-center hidden lg:table-cell">
        <div className="flex gap-1 justify-center">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="skeleton w-2.5 h-2.5 rounded-full"></div>
          ))}
        </div>
      </td>
    </tr>
  );

  const PlayerCardSkeleton = () => (
    <div className="premium-card p-5">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="skeleton w-10 h-10 rounded-full"></div>
          <div className="skeleton w-14 h-14 rounded-full"></div>
          <div>
            <div className="skeleton h-5 w-32 mb-2"></div>
            <div className="skeleton h-3 w-24"></div>
          </div>
        </div>
      </div>
      <div className="text-center py-4 border-y border-gray-800/50">
        <div className="skeleton h-10 w-20 mx-auto mb-2"></div>
        <div className="skeleton h-3 w-12 mx-auto"></div>
      </div>
      <div className="mt-4 space-y-2">
        <div className="flex justify-between">
          <div className="skeleton h-4 w-24"></div>
          <div className="skeleton h-4 w-8"></div>
        </div>
      </div>
    </div>
  );

  const HeroSkeleton = () => (
    <div className="hero-section flex items-center justify-center">
      <div className="text-center z-10 px-4 py-20">
        <div className="skeleton h-20 w-96 mx-auto mb-4"></div>
        <div className="skeleton h-8 w-64 mx-auto mb-8"></div>
        <div className="skeleton h-12 w-80 mx-auto rounded-full mb-12"></div>
        <div className="flex justify-center gap-8">
          <div className="skeleton h-20 w-24"></div>
          <div className="skeleton h-20 w-24"></div>
          <div className="skeleton h-20 w-24"></div>
          <div className="skeleton h-20 w-24"></div>
        </div>
      </div>
    </div>
  );

  const FullPageSkeleton = () => (
    <div className="min-h-screen bg-black">
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          {/* Animated Logo/Spinner */}
          <div className="relative w-32 h-32 mx-auto mb-8">
            <div className="absolute inset-0 rounded-full border-4 border-gray-800"></div>
            <div className="absolute inset-0 rounded-full border-4 border-yellow-400/30 border-t-yellow-400 animate-spin"></div>
            <div className="absolute inset-2 rounded-full border-4 border-gray-800"></div>
            <div className="absolute inset-2 rounded-full border-4 border-green-400/30 border-r-green-400 animate-spin" style={{ animationDirection: 'reverse', animationDuration: '1.5s' }}></div>
            <div className="absolute inset-4 rounded-full border-4 border-gray-800"></div>
            <div className="absolute inset-4 rounded-full border-4 border-red-400/30 border-b-red-400 animate-spin" style={{ animationDuration: '2s' }}></div>
          </div>
          
          {/* Loading Text */}
          <h2 className="text-2xl font-display text-white mb-4 animate-pulse">
            LOADING LEAGUE DATA
          </h2>
          
          {/* Progress Bar */}
          <div className="w-64 h-2 bg-gray-800 rounded-full mx-auto overflow-hidden">
            <div className="h-full bg-gradient-to-r from-yellow-400 to-green-400 rounded-full" 
                 style={{
                   width: '70%',
                   animation: 'shimmer 1.5s infinite'
                 }}></div>
          </div>
          
          {/* Tip Text */}
          <p className="text-gray-500 text-sm mt-8 animate-pulse">
            Preparing your premium sports experience...
          </p>
        </div>
      </div>
    </div>
  );

  if (type === 'full') {
    return <FullPageSkeleton />;
  }

  if (type === 'hero') {
    return <HeroSkeleton />;
  }

  const renderSkeleton = () => {
    switch (type) {
      case 'game-card':
        return <GameCardSkeleton />;
      case 'standings-row':
        return <StandingsRowSkeleton />;
      case 'player-card':
        return <PlayerCardSkeleton />;
      default:
        return <GameCardSkeleton />;
    }
  };

  return (
    <>
      {[...Array(count)].map((_, index) => (
        <div key={index} className="stagger-item" style={{ animationDelay: `${index * 0.1}s` }}>
          {renderSkeleton()}
        </div>
      ))}
    </>
  );
};

export default LoadingSkeleton;