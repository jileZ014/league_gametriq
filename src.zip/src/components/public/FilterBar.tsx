import React from 'react';
import { Filter, Shield, Users } from 'lucide-react';
import type { ContractTeam } from '../../types/contract.types';

interface FilterBarProps {
  teams: ContractTeam[];
  teamFilter: string;
  onTeamFilterChange: (teamId: string) => void;
  showPlayoffOnly: boolean;
  onPlayoffFilterChange: (show: boolean) => void;
}

const FilterBar: React.FC<FilterBarProps> = ({
  teams,
  teamFilter,
  onTeamFilterChange,
  showPlayoffOnly,
  onPlayoffFilterChange
}) => {
  return (
    <div className="flex flex-wrap gap-4 mb-6">
      {/* Team Filter */}
      <div className="flex items-center gap-2">
        <Users className="h-4 w-4 text-gray-400" />
        <select
          value={teamFilter}
          onChange={(e) => onTeamFilterChange(e.target.value)}
          className="glass-input text-sm"
        >
          <option value="all">All Teams</option>
          {teams.map(team => (
            <option key={team.id} value={team.id}>
              {team.name}
            </option>
          ))}
        </select>
      </div>

      {/* Playoff Filter */}
      <button
        onClick={() => onPlayoffFilterChange(!showPlayoffOnly)}
        className={`
          flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all
          ${showPlayoffOnly
            ? 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
            : 'glass-button text-white hover:bg-white/10'
          }
        `}
      >
        <Shield className="h-4 w-4" />
        Playoff Games Only
      </button>

      {/* Active Filters Count */}
      {(teamFilter !== 'all' || showPlayoffOnly) && (
        <div className="flex items-center gap-2 px-3 py-2 bg-cyan-500/10 rounded-lg">
          <Filter className="h-4 w-4 text-cyan-400" />
          <span className="text-sm text-cyan-400">
            {[teamFilter !== 'all' && 'Team', showPlayoffOnly && 'Playoffs']
              .filter(Boolean)
              .join(', ')} filtered
          </span>
          <button
            onClick={() => {
              onTeamFilterChange('all');
              onPlayoffFilterChange(false);
            }}
            className="ml-2 text-xs text-gray-400 hover:text-white transition-colors"
          >
            Clear
          </button>
        </div>
      )}
    </div>
  );
};

export default FilterBar;