import React, { useRef, useEffect, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { DIVISIONS } from '../../utils/mockDataGenerator';
import '../../styles/legacy-sports.css';

interface DivisionTabsProps {
  selectedDivision: string;
  onDivisionChange: (division: string) => void;
}

const DivisionTabs: React.FC<DivisionTabsProps> = ({ selectedDivision, onDivisionChange }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const divisionArray = Object.entries(DIVISIONS).sort((a, b) => a[1].order - b[1].order);

  const checkScrollButtons = () => {
    if (scrollContainerRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollContainerRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 1);
    }
  };

  useEffect(() => {
    checkScrollButtons();
    window.addEventListener('resize', checkScrollButtons);
    return () => window.removeEventListener('resize', checkScrollButtons);
  }, []);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const scrollAmount = 200;
      scrollContainerRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
      setTimeout(checkScrollButtons, 300);
    }
  };

  return (
    <div className="relative pb-4">
      {/* Scroll Left Button */}
      {canScrollLeft && (
        <button
          onClick={() => scroll('left')}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-black/80 backdrop-blur-sm p-1 rounded-full shadow-lg lg:hidden"
          aria-label="Scroll left"
        >
          <ChevronLeft className="h-5 w-5 text-white" />
        </button>
      )}

      {/* Division Tabs Container */}
      <div
        ref={scrollContainerRef}
        onScroll={checkScrollButtons}
        className="flex gap-2 overflow-x-auto scrollbar-hide pb-2"
        style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
      >
        {/* All Divisions Tab */}
        <button
          onClick={() => onDivisionChange('all')}
          className={`
            division-pill
            ${selectedDivision === 'all'
              ? 'active bg-gradient-to-r from-yellow-400 to-yellow-600 text-black shadow-lg shadow-yellow-400/30'
              : 'bg-gradient-to-r from-gray-800 to-gray-700 text-white hover:from-gray-700 hover:to-gray-600'
            }
          `}
        >
          All Divisions
        </button>

        {/* Individual Division Tabs */}
        {divisionArray.map(([division, config]) => {
          // Map shortName to CSS class
          const getDivisionClass = () => {
            const name = config.shortName.toLowerCase();
            if (name === 'fresh') return 'division-freshman';
            if (name === 'jv') return 'division-jv';
            return `division-${name}`;
          };
          const divisionClass = getDivisionClass();
          
          return (
            <button
              key={division}
              onClick={() => onDivisionChange(division)}
              className={`
                division-pill ${divisionClass}
                ${selectedDivision === division
                  ? 'active text-white'
                  : 'opacity-70 hover:opacity-100 text-white'
                }
              `}
            >
              {config.shortName === 'Fresh' ? 'Freshman' :
               config.shortName === 'JV' ? 'JV' :
               `${config.shortName} Grade`}
            </button>
          );
        })}
      </div>

      {/* Scroll Right Button */}
      {canScrollRight && (
        <button
          onClick={() => scroll('right')}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-black/80 backdrop-blur-sm p-1 rounded-full shadow-lg lg:hidden"
          aria-label="Scroll right"
        >
          <ChevronRight className="h-5 w-5 text-white" />
        </button>
      )}

      {/* Desktop Indicator Line */}
      <div className="hidden lg:block absolute bottom-0 left-0 right-0 h-0.5 bg-gray-800">
        <div 
          className="h-full bg-gradient-to-r from-green-400 to-cyan-400 transition-all duration-300"
          style={{
            width: `${100 / (divisionArray.length + 1)}%`,
            transform: `translateX(${
              selectedDivision === 'all' 
                ? 0 
                : (divisionArray.findIndex(([d]) => d === selectedDivision) + 1) * 100
            }%)`
          }}
        />
      </div>
    </div>
  );
};

export default DivisionTabs;