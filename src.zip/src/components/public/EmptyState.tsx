import React from 'react';
import { Calendar, Trophy, Users, Activity, AlertCircle, RefreshCw } from 'lucide-react';
import '../../styles/legacy-sports.css';

interface EmptyStateProps {
  type: 'games' | 'standings' | 'players' | 'teams' | 'error' | 'no-data';
  message?: string;
  actionLabel?: string;
  onAction?: () => void;
}

const EmptyState: React.FC<EmptyStateProps> = ({ 
  type, 
  message, 
  actionLabel, 
  onAction 
}) => {
  const getContent = () => {
    switch (type) {
      case 'games':
        return {
          icon: Calendar,
          title: 'No Games Scheduled',
          description: message || 'There are no games scheduled for this date.',
          color: 'text-cyan-400',
          bgColor: 'from-cyan-400/20 to-cyan-600/20'
        };
      case 'standings':
        return {
          icon: Trophy,
          title: 'No Standings Available',
          description: message || 'Standings will be updated after the first games.',
          color: 'text-yellow-400',
          bgColor: 'from-yellow-400/20 to-yellow-600/20'
        };
      case 'players':
        return {
          icon: Activity,
          title: 'No Player Stats',
          description: message || 'Player statistics will appear after games are played.',
          color: 'text-green-400',
          bgColor: 'from-green-400/20 to-green-600/20'
        };
      case 'teams':
        return {
          icon: Users,
          title: 'No Teams Found',
          description: message || 'No teams match your current filters.',
          color: 'text-purple-400',
          bgColor: 'from-purple-400/20 to-purple-600/20'
        };
      case 'error':
        return {
          icon: AlertCircle,
          title: 'Something Went Wrong',
          description: message || 'We encountered an error loading this content.',
          color: 'text-red-400',
          bgColor: 'from-red-400/20 to-red-600/20'
        };
      case 'no-data':
      default:
        return {
          icon: Activity,
          title: 'No Data Available',
          description: message || 'Check back later for updates.',
          color: 'text-gray-400',
          bgColor: 'from-gray-400/20 to-gray-600/20'
        };
    }
  };

  const content = getContent();
  const Icon = content.icon;

  return (
    <div className="premium-card p-12 text-center page-transition">
      {/* Animated Icon Container */}
      <div className="relative inline-block mb-6">
        {/* Glow Effect */}
        <div className={`absolute inset-0 bg-gradient-to-br ${content.bgColor} rounded-full blur-xl opacity-50 animate-pulse`}></div>
        
        {/* Icon Circle */}
        <div className={`relative w-24 h-24 bg-gradient-to-br ${content.bgColor} rounded-full flex items-center justify-center`}>
          <Icon className={`w-12 h-12 ${content.color}`} />
        </div>
      </div>

      {/* Title */}
      <h3 className="text-2xl font-display text-white mb-3">
        {content.title}
      </h3>

      {/* Description */}
      <p className="text-gray-400 mb-8 max-w-md mx-auto">
        {content.description}
      </p>

      {/* Action Button */}
      {onAction && (
        <button
          onClick={onAction}
          className="btn-premium spring-click inline-flex items-center gap-2"
        >
          {type === 'error' && <RefreshCw className="w-4 h-4" />}
          {actionLabel || 'Try Again'}
        </button>
      )}

      {/* Decorative Elements */}
      <div className="absolute top-4 left-4 w-20 h-20 bg-gradient-to-br from-white/5 to-transparent rounded-full blur-xl"></div>
      <div className="absolute bottom-4 right-4 w-32 h-32 bg-gradient-to-tl from-white/5 to-transparent rounded-full blur-xl"></div>
    </div>
  );
};

export default EmptyState;