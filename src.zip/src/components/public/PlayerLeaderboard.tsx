import React, { useState, useMemo } from 'react';
import { Trophy, Target, Shield, TrendingUp, Star, Crown, Flame, Award } from 'lucide-react';
import { useCountUp } from '../../hooks/useCountUp';
import { DIVISIONS } from '../../utils/mockDataGenerator';
import '../../styles/legacy-sports.css';

interface PlayerStats {
  playerId: string;
  playerName: string;
  teamId: string;
  teamName: string;
  division: string;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  gamesPlayed: number;
  ppg: number;
  rpg: number;
  apg: number;
  spg: number;
  bpg: number;
  lastGame: {
    points: number;
    rebounds: number;
    assists: number;
    opponent: string;
    date: string;
  };
}

interface PlayerLeaderboardProps {
  playerStats: PlayerStats[];
  weeklyMVPs: { [key: string]: PlayerStats };
  selectedDivision: string;
}

type StatCategory = 'points' | 'rebounds' | 'assists' | 'defense';

const PlayerLeaderboard: React.FC<PlayerLeaderboardProps> = ({
  playerStats,
  weeklyMVPs,
  selectedDivision
}) => {
  const [category, setCategory] = useState<StatCategory>('points');
  const [expandedCards, setExpandedCards] = useState<Set<string>>(new Set());

  // Filter players by division
  const filteredPlayers = useMemo(() => {
    if (selectedDivision === 'all') return playerStats;
    return playerStats.filter(p => p.division === selectedDivision);
  }, [playerStats, selectedDivision]);

  // Sort players by selected category
  const sortedPlayers = useMemo(() => {
    const sorted = [...filteredPlayers];
    
    switch (category) {
      case 'points':
        return sorted.sort((a, b) => b.ppg - a.ppg);
      case 'rebounds':
        return sorted.sort((a, b) => b.rpg - a.rpg);
      case 'assists':
        return sorted.sort((a, b) => b.apg - a.apg);
      case 'defense':
        return sorted.sort((a, b) => (b.spg + b.bpg) - (a.spg + a.bpg));
      default:
        return sorted;
    }
  }, [filteredPlayers, category]);

  // Get current MVP
  const currentMVP = useMemo(() => {
    if (selectedDivision === 'all') {
      return Object.values(weeklyMVPs).sort((a, b) => b.ppg - a.ppg)[0];
    }
    return weeklyMVPs[selectedDivision];
  }, [weeklyMVPs, selectedDivision]);

  const categories = [
    { value: 'points' as StatCategory, label: 'POINTS', icon: Target, color: '#EF4444' },
    { value: 'rebounds' as StatCategory, label: 'REBOUNDS', icon: Trophy, color: '#3B82F6' },
    { value: 'assists' as StatCategory, label: 'ASSISTS', icon: TrendingUp, color: '#10B981' },
    { value: 'defense' as StatCategory, label: 'DEFENSE', icon: Shield, color: '#8B5CF6' }
  ];

  const getStatValue = (player: PlayerStats) => {
    switch (category) {
      case 'points': return player.ppg;
      case 'rebounds': return player.rpg;
      case 'assists': return player.apg;
      case 'defense': return (player.spg + player.bpg);
      default: return 0;
    }
  };

  const getStatLabel = () => {
    switch (category) {
      case 'points': return 'PPG';
      case 'rebounds': return 'RPG';
      case 'assists': return 'APG';
      case 'defense': return 'STL+BLK';
      default: return '';
    }
  };

  const toggleCardExpansion = (playerId: string) => {
    const newExpanded = new Set(expandedCards);
    if (newExpanded.has(playerId)) {
      newExpanded.delete(playerId);
    } else {
      newExpanded.add(playerId);
    }
    setExpandedCards(newExpanded);
  };

  const MVPCard: React.FC<{ player: PlayerStats }> = ({ player }) => {
    const [showStats, setShowStats] = useState(true);
    const divisionConfig = DIVISIONS[player.division as keyof typeof DIVISIONS];
    const divisionColor = divisionConfig?.color || '#808080';
    
    const ppgAnimated = useCountUp(player.ppg, showStats, 1500);
    const rpgAnimated = useCountUp(player.rpg, showStats, 1500, 0);
    const apgAnimated = useCountUp(player.apg, showStats, 1500, 0);

    const efficiencyRating = (
      player.ppg + 
      player.rpg * 1.2 + 
      player.apg * 1.5 + 
      player.spg * 2 + 
      player.bpg * 2
    ).toFixed(1);

    return (
      <div className="player-card-mvp premium-card relative overflow-hidden">
        {/* Background Pattern */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 35px, rgba(255,215,0,0.1) 35px, rgba(255,215,0,0.1) 70px)'
          }}
        />

        {/* MVP Badge */}
        <div className="absolute top-4 right-4 z-10">
          <div className="relative">
            <div className="absolute inset-0 bg-yellow-400 blur-2xl opacity-50 animate-pulse"></div>
            <div className="relative bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full p-4">
              <Crown className="h-8 w-8 text-black" />
            </div>
          </div>
        </div>

        <div className="relative z-10">
          <div className="flex gap-6 mb-6">
            {/* Player Avatar */}
            <div className="flex-shrink-0">
              <div className="w-28 h-28 md:w-36 md:h-36 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center border-4 border-yellow-500/30 relative">
                <Star className="h-16 w-16 md:h-20 md:w-20 text-yellow-400" />
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-3 py-1 bg-gradient-to-r from-yellow-400 to-yellow-600 rounded-full">
                  <span className="text-xs font-bold text-black">MVP</span>
                </div>
              </div>
            </div>

            {/* Player Info */}
            <div className="flex-1">
              <h3 className="text-3xl font-display text-white mb-1">{player.playerName}</h3>
              <div className="flex items-center gap-3 mb-4">
                <span className="text-lg text-gray-300 font-heading">{player.teamName}</span>
                <span 
                  className="px-3 py-1 text-xs font-bold rounded-full text-white"
                  style={{
                    background: `linear-gradient(135deg, ${divisionColor}, ${divisionColor}dd)`,
                    boxShadow: `0 2px 10px ${divisionColor}40`
                  }}
                >
                  {player.division}
                </span>
              </div>

              {/* Main Stats */}
              <div className="grid grid-cols-3 md:grid-cols-5 gap-4">
                <div className="text-center">
                  <div className="stat-number text-red-400">{ppgAnimated.toFixed(1)}</div>
                  <div className="text-xs text-gray-400 font-heading">PPG</div>
                </div>
                <div className="text-center">
                  <div className="stat-number text-blue-400">{rpgAnimated.toFixed(1)}</div>
                  <div className="text-xs text-gray-400 font-heading">RPG</div>
                </div>
                <div className="text-center">
                  <div className="stat-number text-green-400">{apgAnimated.toFixed(1)}</div>
                  <div className="text-xs text-gray-400 font-heading">APG</div>
                </div>
                <div className="text-center hidden md:block">
                  <div className="stat-number text-purple-400">{player.spg.toFixed(1)}</div>
                  <div className="text-xs text-gray-400 font-heading">SPG</div>
                </div>
                <div className="text-center hidden md:block">
                  <div className="stat-number text-orange-400">{player.bpg.toFixed(1)}</div>
                  <div className="text-xs text-gray-400 font-heading">BPG</div>
                </div>
              </div>
            </div>
          </div>

          {/* Achievement Badges */}
          <div className="flex flex-wrap gap-2">
            {player.ppg > 20 && (
              <span className="px-3 py-1 bg-red-500/20 text-red-400 text-xs font-bold rounded-full flex items-center gap-1">
                <Flame className="w-3 h-3" />
                20+ PPG Elite Scorer
              </span>
            )}
            {player.rpg > 10 && (
              <span className="px-3 py-1 bg-blue-500/20 text-blue-400 text-xs font-bold rounded-full">
                Double-Digit Rebounder
              </span>
            )}
            {player.apg > 5 && (
              <span className="px-3 py-1 bg-green-500/20 text-green-400 text-xs font-bold rounded-full">
                Elite Playmaker
              </span>
            )}
            <span className="px-3 py-1 bg-gradient-to-r from-yellow-500/20 to-yellow-600/20 text-yellow-400 text-xs font-bold rounded-full animate-pulse">
              Week's Best Player
            </span>
          </div>
        </div>
      </div>
    );
  };

  const PlayerCard: React.FC<{ player: PlayerStats; rank: number }> = ({ player, rank }) => {
    const divisionConfig = DIVISIONS[player.division as keyof typeof DIVISIONS];
    const divisionColor = divisionConfig?.color || '#808080';
    const statValue = getStatValue(player);
    const isExpanded = expandedCards.has(player.playerId);
    
    const getRankBadge = () => {
      if (rank === 1) {
        return (
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center shadow-lg shadow-yellow-400/30 badge-bounce">
            <span className="text-black font-bold">1</span>
          </div>
        );
      }
      if (rank === 2) {
        return (
          <div className="w-10 h-10 bg-gradient-to-br from-gray-300 to-gray-500 rounded-full flex items-center justify-center shadow-lg badge-bounce">
            <span className="text-black font-bold">2</span>
          </div>
        );
      }
      if (rank === 3) {
        return (
          <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center shadow-lg badge-bounce">
            <span className="text-white font-bold">3</span>
          </div>
        );
      }
      return (
        <div className="w-10 h-10 glass-panel flex items-center justify-center">
          <span className="text-white font-bold">{rank}</span>
        </div>
      );
    };

    return (
      <div 
        className="player-card premium-card interactive-card spring-click cursor-pointer stagger-item"
        onClick={() => toggleCardExpansion(player.playerId)}
        style={{ 
          animationDelay: `${rank * 0.05}s`
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            {getRankBadge()}
            
            {/* Player Avatar */}
            <div className="w-14 h-14 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
              <span className="text-2xl">👤</span>
            </div>
            
            <div>
              <h4 className="font-heading font-bold text-white hover:text-yellow-400 transition-colors">
                {player.playerName}
              </h4>
              <div className="flex items-center gap-2 text-xs">
                <span className="text-gray-400">{player.teamName}</span>
                <span 
                  className="px-2 py-0.5 rounded-full text-white"
                  style={{
                    background: `linear-gradient(135deg, ${divisionColor}99, ${divisionColor}66)`,
                  }}
                >
                  {divisionConfig?.shortName}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Stat Display */}
        <div className="text-center py-4 border-y border-gray-800/50">
          <div className="text-4xl font-display" style={{ color: categories.find(c => c.value === category)?.color }}>
            {statValue.toFixed(1)}
          </div>
          <div className="text-xs text-gray-400 font-heading mt-1">{getStatLabel()}</div>
        </div>

        {/* Additional Info */}
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Games Played</span>
            <span className="text-white font-heading font-bold">{player.gamesPlayed}</span>
          </div>
          
          {/* Expandable Last Game Stats */}
          {isExpanded && (
            <div className="pt-3 mt-3 border-t border-gray-800/50 animate-fadeInScale">
              <div className="text-xs text-gray-500 mb-2">Last Game vs {player.lastGame.opponent}</div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="text-center">
                  <div className="text-white font-bold">{player.lastGame.points}</div>
                  <div className="text-gray-500">PTS</div>
                </div>
                <div className="text-center">
                  <div className="text-white font-bold">{player.lastGame.rebounds}</div>
                  <div className="text-gray-500">REB</div>
                </div>
                <div className="text-center">
                  <div className="text-white font-bold">{player.lastGame.assists}</div>
                  <div className="text-gray-500">AST</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="py-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-display text-white mb-2">PLAYER LEADERBOARD</h2>
        <p className="text-gray-400">
          Top performers across {selectedDivision === 'all' ? 'all divisions' : selectedDivision}
        </p>
      </div>

      {/* Weekly MVP Card */}
      {currentMVP && (
        <div className="mb-10">
          <div className="flex items-center gap-2 mb-4">
            <Award className="h-6 w-6 text-yellow-400" />
            <h3 className="text-xl font-heading font-bold text-white">WEEKLY MVP</h3>
          </div>
          <MVPCard player={currentMVP} />
        </div>
      )}

      {/* Category Selector */}
      <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
        {categories.map(cat => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.value}
              onClick={() => setCategory(cat.value)}
              className={`
                flex items-center gap-2 px-6 py-3 rounded-full font-heading font-bold transition-all
                ${category === cat.value
                  ? 'text-black shadow-lg'
                  : 'bg-gray-800/50 text-white hover:bg-gray-700/50'
                }
              `}
              style={
                category === cat.value
                  ? {
                      background: `linear-gradient(135deg, ${cat.color}, ${cat.color}dd)`,
                      boxShadow: `0 8px 25px ${cat.color}40`
                    }
                  : {}
              }
            >
              <Icon className="h-5 w-5" />
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Player Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sortedPlayers.slice(0, 9).map((player, index) => (
          <PlayerCard 
            key={player.playerId} 
            player={player} 
            rank={index + 1}
          />
        ))}
      </div>

      {/* View More Button */}
      {sortedPlayers.length > 9 && (
        <div className="text-center mt-8">
          <button className="btn-premium">
            View All Leaders
          </button>
        </div>
      )}
    </div>
  );
};

export default PlayerLeaderboard;