import React from 'react';
import { Clock, MapPin, Trophy, Shield, CheckCircle, AlertCircle } from 'lucide-react';
import type { ContractGame } from '../../types/contract.types';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface GameListProps {
  games: ContractGame[];
  showDate?: boolean;
}

const GameList: React.FC<GameListProps> = ({ games, showDate = true }) => {
  const isPlayoffGame = () => Math.random() > 0.8;
  const isChampionshipGame = () => Math.random() > 0.95;
  const hasStats = () => Math.random() > 0.3;

  const formatTime = (time: string) => {
    return time; // Already formatted in mock data
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-3">
      {games.map(game => {
        const divisionConfig = DIVISIONS[game.division as keyof typeof DIVISIONS];
        const divisionColor = divisionConfig?.color || '#808080';
        const isPlayoff = isPlayoffGame();
        const isChampionship = isChampionshipGame();
        const gameHasStats = game.status === 'completed' && hasStats();

        return (
          <div 
            key={game.id}
            className="glass-panel p-4 hover:bg-white/5 transition-all cursor-pointer"
            onClick={() => console.log('View game details:', game.id)}
          >
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              {/* Left: Teams and Scores */}
              <div className="flex-1">
                <div className="flex items-start gap-4">
                  {/* Division/Status Badge */}
                  <div className="flex flex-col gap-2">
                    <span 
                      className="px-2 py-1 text-xs font-semibold rounded-full"
                      style={{
                        backgroundColor: `${divisionColor}20`,
                        color: divisionColor
                      }}
                    >
                      {divisionConfig?.shortName}
                    </span>
                    
                    {/* Special Game Badges */}
                    {isChampionship && (
                      <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-semibold rounded-full flex items-center gap-1">
                        <Trophy className="h-3 w-3" />
                        FINAL
                      </span>
                    )}
                    {isPlayoff && !isChampionship && (
                      <span className="px-2 py-1 bg-purple-500/20 text-purple-400 text-xs font-semibold rounded-full flex items-center gap-1">
                        <Shield className="h-3 w-3" />
                        PLAYOFF
                      </span>
                    )}
                  </div>

                  {/* Teams */}
                  <div className="flex-1">
                    <div className="space-y-2">
                      {/* Home Team */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500">H</span>
                          <span className="font-medium text-white">{game.homeTeamName}</span>
                        </div>
                        {game.status !== 'scheduled' && (
                          <span className={`text-xl font-bold ${
                            game.status === 'completed' && game.homeScore > game.awayScore 
                              ? 'text-green-400' 
                              : 'text-white'
                          }`}>
                            {game.homeScore}
                          </span>
                        )}
                      </div>

                      {/* Away Team */}
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500">A</span>
                          <span className="font-medium text-white">{game.awayTeamName}</span>
                        </div>
                        {game.status !== 'scheduled' && (
                          <span className={`text-xl font-bold ${
                            game.status === 'completed' && game.awayScore > game.homeScore 
                              ? 'text-green-400' 
                              : 'text-white'
                          }`}>
                            {game.awayScore}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Game Status */}
                    <div className="mt-2">
                      {game.status === 'in_progress' && (
                        <span className="px-2 py-1 bg-orange-500/20 text-orange-400 text-xs font-semibold rounded-full animate-pulse">
                          LIVE
                        </span>
                      )}
                      {game.status === 'completed' && (
                        <span className="px-2 py-1 bg-green-500/20 text-green-400 text-xs font-semibold rounded-full">
                          FINAL
                        </span>
                      )}
                      {game.status === 'postponed' && (
                        <span className="px-2 py-1 bg-yellow-500/20 text-yellow-400 text-xs font-semibold rounded-full">
                          POSTPONED
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Right: Game Info */}
              <div className="flex flex-col gap-2 text-sm text-gray-400">
                {showDate && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span>{formatDate(game.date)}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span>{formatTime(game.time)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span>{game.venue}</span>
                </div>
                
                {/* Stats Indicator */}
                {gameHasStats && (
                  <div className="flex items-center gap-2 text-green-400">
                    <CheckCircle className="h-4 w-4" />
                    <span className="text-xs">Stats Available</span>
                  </div>
                )}
                {game.status === 'completed' && !gameHasStats && (
                  <div className="flex items-center gap-2 text-yellow-400">
                    <AlertCircle className="h-4 w-4" />
                    <span className="text-xs">Stats Pending</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default GameList;