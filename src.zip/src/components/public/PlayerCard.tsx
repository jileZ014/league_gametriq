import React from 'react';
import { User, TrendingUp, Calendar, Users } from 'lucide-react';
import { DIVISIONS } from '../../utils/mockDataGenerator';

interface PlayerCardProps {
  player: {
    playerId: string;
    playerName: string;
    teamName: string;
    division: string;
    gamesPlayed: number;
    lastGame: {
      points: number;
      rebounds: number;
      assists: number;
      opponent: string;
      date: string;
    };
  };
  rank: number;
  statCategory: string;
  statValue: number;
  statLabel: string;
}

const PlayerCard: React.FC<PlayerCardProps> = ({
  player,
  rank,
  statCategory,
  statValue,
  statLabel
}) => {
  const divisionConfig = DIVISIONS[player.division as keyof typeof DIVISIONS];
  const divisionColor = divisionConfig?.color || '#808080';

  const getRankBadge = () => {
    if (rank === 1) {
      return (
        <div className="w-8 h-8 bg-gradient-to-br from-yellow-400 to-yellow-600 rounded-full flex items-center justify-center shadow-lg">
          <span className="text-black font-bold text-sm">1</span>
        </div>
      );
    }
    if (rank === 2) {
      return (
        <div className="w-8 h-8 bg-gradient-to-br from-gray-300 to-gray-500 rounded-full flex items-center justify-center shadow-lg">
          <span className="text-black font-bold text-sm">2</span>
        </div>
      );
    }
    if (rank === 3) {
      return (
        <div className="w-8 h-8 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center shadow-lg">
          <span className="text-white font-bold text-sm">3</span>
        </div>
      );
    }
    return (
      <div className="w-8 h-8 glass-panel flex items-center justify-center">
        <span className="text-white font-bold text-sm">{rank}</span>
      </div>
    );
  };

  const getCategoryColor = () => {
    switch (statCategory) {
      case 'points': return 'text-red-400';
      case 'rebounds': return 'text-blue-400';
      case 'assists': return 'text-green-400';
      case 'defense': return 'text-purple-400';
      default: return 'text-white';
    }
  };

  return (
    <div className="glass-panel p-4 hover:bg-white/5 transition-all cursor-pointer">
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          {getRankBadge()}
          
          {/* Player Photo Placeholder */}
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-700 to-gray-900 flex items-center justify-center">
            <User className="h-6 w-6 text-gray-400" />
          </div>
          
          <div>
            <h4 className="font-semibold text-white hover:text-cyan-400 transition-colors">
              {player.playerName}
            </h4>
            <div className="flex items-center gap-2 text-xs text-gray-400">
              <span>{player.teamName}</span>
              <span 
                className="px-2 py-0.5 rounded-full"
                style={{
                  backgroundColor: `${divisionColor}20`,
                  color: divisionColor
                }}
              >
                {divisionConfig?.shortName}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Stat */}
      <div className="text-center py-3 border-y border-gray-800/50">
        <div className={`text-3xl font-bold ${getCategoryColor()}`}>
          {statValue.toFixed(1)}
        </div>
        <div className="text-xs text-gray-400 mt-1">{statLabel}</div>
      </div>

      {/* Additional Info */}
      <div className="mt-3 space-y-2 text-sm">
        <div className="flex items-center justify-between text-gray-400">
          <div className="flex items-center gap-1">
            <Calendar className="h-3 w-3" />
            <span>Games Played</span>
          </div>
          <span className="text-white font-medium">{player.gamesPlayed}</span>
        </div>

        {/* Last Game Performance */}
        <div className="pt-2 border-t border-gray-800/50">
          <div className="text-xs text-gray-500 mb-1">Last Game vs {player.lastGame.opponent}</div>
          <div className="flex justify-between text-xs">
            <span className="text-gray-400">
              PTS: <span className="text-white font-medium">{player.lastGame.points}</span>
            </span>
            <span className="text-gray-400">
              REB: <span className="text-white font-medium">{player.lastGame.rebounds}</span>
            </span>
            <span className="text-gray-400">
              AST: <span className="text-white font-medium">{player.lastGame.assists}</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlayerCard;