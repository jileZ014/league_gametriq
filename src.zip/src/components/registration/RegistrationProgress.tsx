import React from 'react';
import { Check } from 'lucide-react';

interface RegistrationProgressProps {
  steps: string[];
  currentStep: number;
}

const RegistrationProgress: React.FC<RegistrationProgressProps> = ({ steps, currentStep }) => {
  return (
    <div className="glass-panel p-6">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <React.Fragment key={step}>
            <div className="flex flex-col items-center">
              <div 
                className={`
                  w-10 h-10 rounded-full flex items-center justify-center font-semibold
                  transition-all duration-300
                  ${index < currentStep 
                    ? 'bg-green-500 text-white' 
                    : index === currentStep 
                    ? 'bg-blue-500 text-white animate-pulse' 
                    : 'bg-gray-700 text-gray-400'
                  }
                `}
              >
                {index < currentStep ? (
                  <Check className="h-5 w-5" />
                ) : (
                  <span>{index + 1}</span>
                )}
              </div>
              <span className={`
                text-xs mt-2 text-center hidden md:block
                ${index === currentStep ? 'text-white font-semibold' : 'text-gray-400'}
              `}>
                {step}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div 
                className={`
                  flex-1 h-1 mx-2 rounded-full transition-all duration-300
                  ${index < currentStep ? 'bg-green-500' : 'bg-gray-700'}
                `}
              />
            )}
          </React.Fragment>
        ))}
      </div>
      
      {/* Mobile step indicator */}
      <div className="md:hidden mt-4 text-center">
        <span className="text-white font-semibold">{steps[currentStep]}</span>
        <span className="text-gray-400 ml-2">({currentStep + 1} of {steps.length})</span>
      </div>
    </div>
  );
};

export default RegistrationProgress;