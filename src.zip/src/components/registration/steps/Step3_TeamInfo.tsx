import React, { useState } from 'react';
// // import { Input } from '../../ui/input'; // FIXED BUILD ERROR
// // import { Label } from '../../ui/input'; // FIXED BUILD ERROR
// // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
// // import { Card } from '../../ui/input'; // FIXED BUILD ERROR
import { Plus, Trash2, AlertCircle } from 'lucide-react';

interface Step3Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step3_TeamInfo: React.FC<Step3Props> = ({ data, onUpdate, onNext }) => {
  const isOrganization = data.registrationType === 'organization';
  const [teams, setTeams] = useState(data.teams?.length > 0 ? data.teams : [{
    teamId: Date.now().toString(),
    teamName: '',
    division: '',
    gradeLevel: '',
    ageGroup: '',
    homeVenue: '',
    practiceSchedule: ''
  }]);

  const [errors, setErrors] = useState<any>({});

  const divisions = [
    '3rd-4th Grade Boys',
    '3rd-4th Grade Girls',
    '5th-6th Grade Boys',
    '5th-6th Grade Girls',
    '7th-8th Grade Boys',
    '7th-8th Grade Girls',
    'JV Boys',
    'JV Girls',
    'Varsity Boys',
    'Varsity Girls'
  ];

  const venues = [
    'Phoenix Sports Complex',
    'Desert Vista Recreation Center',
    'Scottsdale Community Center',
    'Mesa Family YMCA',
    'Chandler High School',
    'Gilbert Parks & Rec'
  ];

  const addTeam = () => {
    setTeams([...teams, {
      teamId: Date.now().toString(),
      teamName: '',
      division: '',
      gradeLevel: '',
      ageGroup: '',
      homeVenue: '',
      practiceSchedule: ''
    }]);
  };

  const removeTeam = (index: number) => {
    if (teams.length > 1) {
      setTeams(teams.filter((_, i) => i !== index));
    }
  };

  const updateTeam = (index: number, field: string, value: string) => {
    const updatedTeams = [...teams];
    updatedTeams[index] = { ...updatedTeams[index], [field]: value };
    setTeams(updatedTeams);
  };

  const validateForm = () => {
    const newErrors: any = {};

    teams.forEach((team, index) => {
      if (!team.teamName) {
        newErrors[`team${index}_name`] = 'Team name is required';
      }
      if (!team.division) {
        newErrors[`team${index}_division`] = 'Division is required';
      }
      if (!team.gradeLevel) {
        newErrors[`team${index}_grade`] = 'Grade level is required';
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onUpdate(teams, 'teams');
      onNext();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-white">
          {isOrganization ? 'Teams Information' : 'Team Information'}
        </h3>
        {isOrganization && (
          <Button
            type="button"
            onClick={addTeam}
            className="glass-button"
            size="sm"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Team
          </Button>
        )}
      </div>

      {teams.map((team, index) => (
        <Card key={team.teamId} className="glass-panel p-6">
          {isOrganization && (
            <div className="flex justify-between items-center mb-4">
              <h4 className="text-white font-semibold">Team {index + 1}</h4>
              {teams.length > 1 && (
                <Button
                  type="button"
                  onClick={() => removeTeam(index)}
                  variant="ghost"
                  size="sm"
                  className="text-red-400 hover:text-red-300"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor={`teamName${index}`} className="text-white">
                Team Name *
              </Label>
              <Input
                id={`teamName${index}`}
                value={team.teamName}
                onChange={(e) => updateTeam(index, 'teamName', e.target.value)}
                className="glass-input"
                placeholder="Phoenix Thunder"
              />
              {errors[`team${index}_name`] && (
                <p className="text-red-400 text-sm mt-1">{errors[`team${index}_name`]}</p>
              )}
            </div>

            <div>
              <Label htmlFor={`division${index}`} className="text-white">
                Division *
              </Label>
              <select
                id={`division${index}`}
                value={team.division}
                onChange={(e) => updateTeam(index, 'division', e.target.value)}
                className="glass-input w-full"
              >
                <option value="">Select Division</option>
                {divisions.map(div => (
                  <option key={div} value={div}>{div}</option>
                ))}
              </select>
              {errors[`team${index}_division`] && (
                <p className="text-red-400 text-sm mt-1">{errors[`team${index}_division`]}</p>
              )}
            </div>

            <div>
              <Label htmlFor={`gradeLevel${index}`} className="text-white">
                Grade Level *
              </Label>
              <select
                id={`gradeLevel${index}`}
                value={team.gradeLevel}
                onChange={(e) => updateTeam(index, 'gradeLevel', e.target.value)}
                className="glass-input w-full"
              >
                <option value="">Select Grade</option>
                <option value="3rd">3rd Grade</option>
                <option value="4th">4th Grade</option>
                <option value="5th">5th Grade</option>
                <option value="6th">6th Grade</option>
                <option value="7th">7th Grade</option>
                <option value="8th">8th Grade</option>
                <option value="9th">9th Grade</option>
                <option value="10th">10th Grade</option>
                <option value="11th">11th Grade</option>
                <option value="12th">12th Grade</option>
                <option value="mixed">Mixed Grades</option>
              </select>
              {errors[`team${index}_grade`] && (
                <p className="text-red-400 text-sm mt-1">{errors[`team${index}_grade`]}</p>
              )}
            </div>

            <div>
              <Label htmlFor={`ageGroup${index}`} className="text-white">
                Age Group
              </Label>
              <select
                id={`ageGroup${index}`}
                value={team.ageGroup}
                onChange={(e) => updateTeam(index, 'ageGroup', e.target.value)}
                className="glass-input w-full"
              >
                <option value="">Select Age Group</option>
                <option value="8-9">8-9 years</option>
                <option value="10-11">10-11 years</option>
                <option value="12-13">12-13 years</option>
                <option value="14-15">14-15 years</option>
                <option value="16-17">16-17 years</option>
                <option value="18+">18+ years</option>
              </select>
            </div>

            <div>
              <Label htmlFor={`homeVenue${index}`} className="text-white">
                Preferred Home Venue
              </Label>
              <select
                id={`homeVenue${index}`}
                value={team.homeVenue}
                onChange={(e) => updateTeam(index, 'homeVenue', e.target.value)}
                className="glass-input w-full"
              >
                <option value="">Select Venue</option>
                {venues.map(venue => (
                  <option key={venue} value={venue}>{venue}</option>
                ))}
              </select>
            </div>

            <div>
              <Label htmlFor={`practiceSchedule${index}`} className="text-white">
                Practice Availability
              </Label>
              <Input
                id={`practiceSchedule${index}`}
                value={team.practiceSchedule}
                onChange={(e) => updateTeam(index, 'practiceSchedule', e.target.value)}
                className="glass-input"
                placeholder="Tues/Thurs 6-8pm"
              />
            </div>
          </div>
        </Card>
      ))}

      {/* Multi-team discount info */}
      {isOrganization && teams.length >= 3 && (
        <div className="glass-panel border-green-500/30 p-4">
          <div className="flex gap-3">
            <AlertCircle className="h-5 w-5 text-green-400 mt-0.5" />
            <div className="text-sm">
              <p className="text-green-400 font-semibold">Multi-Team Discount Applied!</p>
              <p className="text-gray-400">You qualify for a 10% discount with {teams.length} teams.</p>
            </div>
          </div>
        </div>
      )}

      {/* Division Age Requirements */}
      <div className="glass-panel border-blue-500/30 p-4">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-blue-400 mt-0.5" />
          <div className="text-sm text-gray-400">
            <p className="text-blue-400 font-semibold mb-2">Division Requirements</p>
            <p>Players must meet age and grade requirements as of September 1st of the current season. 
               Birth certificates may be required for age verification.</p>
          </div>
        </div>
      </div>

      <Button 
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Coaching Staff
      </Button>
    </form>
  );
};

export default Step3_TeamInfo;


