import React, { useState, useEffect } from 'react';
// Commented out UI imports that cause build errors
// // // import { Input } from '../../ui/input'; // FIXED BUILD ERROR
// // // import { Label } from '../../ui/input'; // FIXED BUILD ERROR
// // // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
import { AlertCircle } from 'lucide-react';

// Inline component replacements
const Input = ({ className = '', ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input className={`px-3 py-2 rounded-lg border border-gray-600 bg-gray-800/50 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${className}`} {...props} />
);

const Button = ({ children, className = '', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button className={`inline-flex items-center justify-center rounded-lg font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 px-4 py-2 ${className}`} {...props}>
    {children}
  </button>
);

interface Step2Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step2_OrganizationInfo: React.FC<Step2Props> = ({ data, onUpdate, onNext }) => {
  const [orgData, setOrgData] = useState(data.organization || {
    name: '',
    type: 'school',
    taxId: '',
    website: '',
    primaryContact: {
      name: '',
      title: '',
      email: '',
      phone: ''
    }
  });

  const [errors, setErrors] = useState<any>({});

  const validateForm = () => {
    const newErrors: any = {};
    
    if (!orgData.name) newErrors.name = 'Organization name is required';
    if (!orgData.primaryContact.name) newErrors.contactName = 'Contact name is required';
    if (!orgData.primaryContact.email) newErrors.contactEmail = 'Contact email is required';
    if (!orgData.primaryContact.phone) newErrors.contactPhone = 'Contact phone is required';

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (orgData.primaryContact.email && !emailRegex.test(orgData.primaryContact.email)) {
      newErrors.contactEmail = 'Invalid email format';
    }

    // Phone validation
    const phoneRegex = /^\d{3}-?\d{3}-?\d{4}$/;
    if (orgData.primaryContact.phone && !phoneRegex.test(orgData.primaryContact.phone.replace(/[^\d-]/g, ''))) {
      newErrors.contactPhone = 'Phone must be 10 digits (xxx-xxx-xxxx)';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onUpdate(orgData, 'organization');
      onNext();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Organization Details</h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="orgName" className="block text-sm font-medium text-white mb-1">
              Organization Name *
            </label>
            <Input
              id="orgName"
              value={orgData.name}
              onChange={(e) => setOrgData({...orgData, name: e.target.value})}
              className="glass-input"
              placeholder="Lincoln Elementary School"
            />
            {errors.name && (
              <p className="text-red-400 text-sm mt-1">{errors.name}</p>
            )}
          </div>

          <div>
            <label htmlFor="orgType" className="block text-sm font-medium text-white mb-1">
              Organization Type *
            </label>
            <select
              id="orgType"
              value={orgData.type}
              onChange={(e) => setOrgData({...orgData, type: e.target.value})}
              className="glass-input w-full px-3 py-2 rounded-lg border border-gray-600 bg-gray-800/50 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="school">School</option>
              <option value="club">Sports Club</option>
              <option value="community">Community Center</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label htmlFor="taxId" className="block text-sm font-medium text-white mb-1">
              Tax ID (EIN) - Optional
            </label>
            <Input
              id="taxId"
              value={orgData.taxId}
              onChange={(e) => setOrgData({...orgData, taxId: e.target.value})}
              className="glass-input"
              placeholder="XX-XXXXXXX"
            />
            <p className="text-xs text-gray-400 mt-1">For 501(c)(3) discount eligibility</p>
          </div>

          <div>
            <label htmlFor="website" className="block text-sm font-medium text-white mb-1">
              Website - Optional
            </label>
            <Input
              id="website"
              value={orgData.website}
              onChange={(e) => setOrgData({...orgData, website: e.target.value})}
              className="glass-input"
              placeholder="https://www.example.org"
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-white">Primary Contact</h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="contactName" className="block text-sm font-medium text-white mb-1">
              Full Name *
            </label>
            <Input
              id="contactName"
              value={orgData.primaryContact.name}
              onChange={(e) => setOrgData({
                ...orgData,
                primaryContact: {...orgData.primaryContact, name: e.target.value}
              })}
              className="glass-input"
              placeholder="John Smith"
            />
            {errors.contactName && (
              <p className="text-red-400 text-sm mt-1">{errors.contactName}</p>
            )}
          </div>

          <div>
            <label htmlFor="contactTitle" className="block text-sm font-medium text-white mb-1">
              Title/Position
            </label>
            <Input
              id="contactTitle"
              value={orgData.primaryContact.title}
              onChange={(e) => setOrgData({
                ...orgData,
                primaryContact: {...orgData.primaryContact, title: e.target.value}
              })}
              className="glass-input"
              placeholder="Athletic Director"
            />
          </div>

          <div>
            <label htmlFor="contactEmail" className="block text-sm font-medium text-white mb-1">
              Email Address *
            </label>
            <Input
              id="contactEmail"
              type="email"
              value={orgData.primaryContact.email}
              onChange={(e) => setOrgData({
                ...orgData,
                primaryContact: {...orgData.primaryContact, email: e.target.value}
              })}
              className="glass-input"
              placeholder="john.smith@example.org"
            />
            {errors.contactEmail && (
              <p className="text-red-400 text-sm mt-1">{errors.contactEmail}</p>
            )}
          </div>

          <div>
            <label htmlFor="contactPhone" className="block text-sm font-medium text-white mb-1">
              Phone Number *
            </label>
            <Input
              id="contactPhone"
              value={orgData.primaryContact.phone}
              onChange={(e) => setOrgData({
                ...orgData,
                primaryContact: {...orgData.primaryContact, phone: e.target.value}
              })}
              className="glass-input"
              placeholder="(602) 555-0123"
            />
            {errors.contactPhone && (
              <p className="text-red-400 text-sm mt-1">{errors.contactPhone}</p>
            )}
          </div>
        </div>
      </div>

      {/* Info Box */}
      <div className="glass-panel border-blue-500/30 p-4">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-blue-400 mt-0.5" />
          <div className="text-sm text-gray-400">
            <p className="text-blue-400 font-semibold mb-1">Organization Benefits</p>
            <ul className="space-y-1">
              <li>• 10% discount for 3+ teams</li>
              <li>• Consolidated billing and invoicing</li>
              <li>• Priority scheduling requests</li>
              <li>• Organization-wide communication tools</li>
            </ul>
          </div>
        </div>
      </div>

      <Button
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Team Details
      </Button>
    </form>
  );
};

export default Step2_OrganizationInfo;


