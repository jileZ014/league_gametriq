import React, { useState } from 'react';
// // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
// // import { Card } from '../../ui/input'; // FIXED BUILD ERROR
import { CreditCard, DollarSign, Heart, AlertCircle } from 'lucide-react';

interface Step8Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step8_Payment: React.FC<Step8Props> = ({ data, onUpdate, onNext }) => {
  const [paymentMethod, setPaymentMethod] = useState(data.payment?.method || 'credit_card');
  const [requestScholarship, setRequestScholarship] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const paymentData = {
      ...data.payment,
      method: paymentMethod,
      scholarship: requestScholarship ? {
        requested: true,
        reason: 'Financial hardship',
        approved: false
      } : null
    };
    onUpdate(paymentData, 'payment');
    onNext();
  };

  const fees = data.payment?.fees || {
    registrationFee: 150,
    uniformFee: 50,
    facilityFee: 25,
    insuranceFee: 15,
    subtotal: 240,
    totalDue: 240
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h3 className="text-lg font-semibold text-white">Payment Information</h3>
      
      {/* Fee Breakdown */}
      <Card className="glass-panel p-6">
        <h4 className="text-white font-semibold mb-4">Registration Fees</h4>
        <div className="space-y-2">
          <div className="flex justify-between text-gray-400">
            <span>Registration Fee</span>
            <span>${fees.registrationFee}</span>
          </div>
          <div className="flex justify-between text-gray-400">
            <span>Uniform Fee</span>
            <span>${fees.uniformFee}</span>
          </div>
          <div className="flex justify-between text-gray-400">
            <span>Facility Fee</span>
            <span>${fees.facilityFee}</span>
          </div>
          <div className="flex justify-between text-gray-400">
            <span>Insurance Fee</span>
            <span>${fees.insuranceFee}</span>
          </div>
          <div className="border-t border-gray-700 pt-2 mt-2">
            <div className="flex justify-between text-white font-semibold">
              <span>Total Due</span>
              <span>${fees.totalDue}</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Payment Method */}
      <div className="space-y-4">
        <h4 className="text-white font-semibold">Payment Method</h4>
        <div className="grid md:grid-cols-2 gap-4">
          <Card 
            className={`glass-panel p-4 cursor-pointer transition-all ${
              paymentMethod === 'credit_card' ? 'border-blue-400 bg-blue-500/10' : ''
            }`}
            onClick={() => setPaymentMethod('credit_card')}
          >
            <div className="flex items-center gap-3">
              <CreditCard className="h-5 w-5 text-blue-400" />
              <div>
                <p className="text-white font-semibold">Credit/Debit Card</p>
                <p className="text-xs text-gray-400">Pay online securely</p>
              </div>
            </div>
          </Card>

          <Card 
            className={`glass-panel p-4 cursor-pointer transition-all ${
              paymentMethod === 'check' ? 'border-blue-400 bg-blue-500/10' : ''
            }`}
            onClick={() => setPaymentMethod('check')}
          >
            <div className="flex items-center gap-3">
              <DollarSign className="h-5 w-5 text-green-400" />
              <div>
                <p className="text-white font-semibold">Check/Cash</p>
                <p className="text-xs text-gray-400">Pay at first practice</p>
              </div>
            </div>
          </Card>

          <Card 
            className={`glass-panel p-4 cursor-pointer transition-all ${
              paymentMethod === 'payment_plan' ? 'border-blue-400 bg-blue-500/10' : ''
            }`}
            onClick={() => setPaymentMethod('payment_plan')}
          >
            <div className="flex items-center gap-3">
              <DollarSign className="h-5 w-5 text-yellow-400" />
              <div>
                <p className="text-white font-semibold">Payment Plan</p>
                <p className="text-xs text-gray-400">3 monthly installments</p>
              </div>
            </div>
          </Card>

          <Card 
            className={`glass-panel p-4 cursor-pointer transition-all ${
              paymentMethod === 'scholarship' ? 'border-blue-400 bg-blue-500/10' : ''
            }`}
            onClick={() => {
              setPaymentMethod('scholarship');
              setRequestScholarship(true);
            }}
          >
            <div className="flex items-center gap-3">
              <Heart className="h-5 w-5 text-red-400" />
              <div>
                <p className="text-white font-semibold">Scholarship</p>
                <p className="text-xs text-gray-400">Apply for financial aid</p>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Scholarship Info */}
      {requestScholarship && (
        <div className="glass-panel border-green-500/30 p-4">
          <div className="flex gap-3">
            <Heart className="h-5 w-5 text-green-400" />
            <div className="text-sm">
              <p className="text-green-400 font-semibold">Financial Aid Available</p>
              <p className="text-gray-400 mt-1">
                We believe every child should have the opportunity to play. Scholarships 
                are available based on financial need. Your application will be reviewed 
                within 2-3 business days.
              </p>
            </div>
          </div>
        </div>
      )}

      <Button 
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Terms & Consent
      </Button>
    </form>
  );
};

export default Step8_Payment;


