import React, { useState } from 'react';
// Commented out UI imports that cause build errors
// // // import { Input } from '../../ui/input'; // FIXED BUILD ERROR
// // // import { Label } from '../../ui/input'; // FIXED BUILD ERROR
// // // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
// // // import { Card } from '../../ui/input'; // FIXED BUILD ERROR
// // // import { Badge } from '../../ui/input'; // FIXED BUILD ERROR
import { Plus, Trash2, Shield, AlertTriangle } from 'lucide-react';

// Inline component replacements
const Input = ({ className = '', ...props }: React.InputHTMLAttributes<HTMLInputElement>) => (
  <input className={`px-3 py-2 rounded-lg border border-gray-600 bg-gray-800/50 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 ${className}`} {...props} />
);

const Button = ({ children, className = '', variant = 'default', size = 'default', ...props }: any) => {
  const baseClasses = 'inline-flex items-center justify-center rounded-lg font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500';
  const variantClasses = variant === 'ghost' ? 'hover:bg-gray-800/50' : 'bg-blue-500/20 hover:bg-blue-500/30';
  const sizeClasses = size === 'sm' ? 'px-3 py-1.5 text-sm' : 'px-4 py-2';
  return (
    <button className={`${baseClasses} ${variantClasses} ${sizeClasses} ${className}`} {...props}>
      {children}
    </button>
  );
};

const Card = ({ children, className = '' }: any) => (
  <div className={`rounded-lg border border-gray-700 bg-gray-900/50 ${className}`}>
    {children}
  </div>
);

const Badge = ({ children, className = '' }: any) => (
  <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${className}`}>
    {children}
  </span>
);

interface Step4Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step4_CoachingStaff: React.FC<Step4Props> = ({ data, onUpdate, onNext }) => {
  const [coaches, setCoaches] = useState(data.coaches?.length > 0 ? data.coaches : [{
    id: Date.now().toString(),
    role: 'head',
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    dateOfBirth: '',
    backgroundCheck: {
      status: 'pending',
      completedDate: null,
      expirationDate: null
    },
    certifications: {
      safeSport: false,
      safeSportDate: '',
      firstAid: false,
      firstAidExpiry: '',
      cpr: false,
      cprExpiry: '',
      coachingLicense: '',
      licensingBody: ''
    }
  }]);

  const [errors, setErrors] = useState<any>({});

  const addCoach = () => {
    setCoaches([...coaches, {
      id: Date.now().toString(),
      role: 'assistant',
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      dateOfBirth: '',
      backgroundCheck: {
        status: 'pending',
        completedDate: null,
        expirationDate: null
      },
      certifications: {
        safeSport: false,
        safeSportDate: '',
        firstAid: false,
        firstAidExpiry: '',
        cpr: false,
        cprExpiry: '',
        coachingLicense: '',
        licensingBody: ''
      }
    }]);
  };

  const removeCoach = (index: number) => {
    if (coaches.length > 1) {
      setCoaches(coaches.filter((_, i) => i !== index));
    }
  };

  const updateCoach = (index: number, field: string, value: any) => {
    const updatedCoaches = [...coaches];
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      updatedCoaches[index][parent] = {
        ...updatedCoaches[index][parent],
        [child]: value
      };
    } else {
      updatedCoaches[index][field] = value;
    }
    setCoaches(updatedCoaches);
  };

  const validateForm = () => {
    const newErrors: any = {};
    let hasHeadCoach = false;

    coaches.forEach((coach, index) => {
      if (!coach.firstName) newErrors[`coach${index}_firstName`] = 'First name required';
      if (!coach.lastName) newErrors[`coach${index}_lastName`] = 'Last name required';
      if (!coach.email) newErrors[`coach${index}_email`] = 'Email required';
      if (!coach.phone) newErrors[`coach${index}_phone`] = 'Phone required';
      if (!coach.dateOfBirth) newErrors[`coach${index}_dob`] = 'Date of birth required';

      if (coach.role === 'head') hasHeadCoach = true;
    });

    if (!hasHeadCoach) {
      newErrors.headCoach = 'At least one head coach is required';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onUpdate(coaches, 'coaches');
      onNext();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-white">Coaching Staff</h3>
        <Button
          type="button"
          onClick={addCoach}
          className="glass-button"
          size="sm"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Coach
        </Button>
      </div>

      {/* Background Check Warning */}
      <div className="glass-panel border-yellow-500/50 p-4">
        <div className="flex gap-3">
          <AlertTriangle className="h-5 w-5 text-yellow-400 mt-0.5" />
          <div className="text-sm">
            <p className="text-yellow-400 font-semibold">Background Check Required</p>
            <p className="text-gray-400 mt-1">
              All coaches must complete a background check and SafeSport certification before 
              being allowed to participate. Processing typically takes 3-5 business days.
            </p>
          </div>
        </div>
      </div>

      {errors.headCoach && (
        <p className="text-red-400">{errors.headCoach}</p>
      )}

      {coaches.map((coach, index) => (
        <Card key={coach.id} className="glass-panel p-6">
          <div className="flex justify-between items-start mb-4">
            <div className="flex items-center gap-3">
              <Shield className="h-5 w-5 text-blue-400" />
              <h4 className="text-white font-semibold">
                {coach.role === 'head' ? 'Head Coach' : 
                 coach.role === 'assistant' ? 'Assistant Coach' : 'Volunteer Coach'}
              </h4>
            </div>
            {coaches.length > 1 && (
              <Button
                type="button"
                onClick={() => removeCoach(index)}
                variant="ghost"
                size="sm"
                className="text-red-400 hover:text-red-300"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-white mb-1">Role *</label>
              <select
                value={coach.role}
                onChange={(e) => updateCoach(index, 'role', e.target.value)}
                className="glass-input w-full px-3 py-2 rounded-lg border border-gray-600 bg-gray-800/50 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="head">Head Coach</option>
                <option value="assistant">Assistant Coach</option>
                <option value="volunteer">Volunteer Coach</option>
              </select>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-white mb-1">First Name *</label>
                <Input
                  value={coach.firstName}
                  onChange={(e) => updateCoach(index, 'firstName', e.target.value)}
                  className="glass-input"
                  placeholder="John"
                />
                {errors[`coach${index}_firstName`] && (
                  <p className="text-red-400 text-sm mt-1">{errors[`coach${index}_firstName`]}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-1">Last Name *</label>
                <Input
                  value={coach.lastName}
                  onChange={(e) => updateCoach(index, 'lastName', e.target.value)}
                  className="glass-input"
                  placeholder="Smith"
                />
                {errors[`coach${index}_lastName`] && (
                  <p className="text-red-400 text-sm mt-1">{errors[`coach${index}_lastName`]}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-1">Email *</label>
                <Input
                  type="email"
                  value={coach.email}
                  onChange={(e) => updateCoach(index, 'email', e.target.value)}
                  className="glass-input"
                  placeholder="coach@email.com"
                />
                {errors[`coach${index}_email`] && (
                  <p className="text-red-400 text-sm mt-1">{errors[`coach${index}_email`]}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-1">Phone *</label>
                <Input
                  value={coach.phone}
                  onChange={(e) => updateCoach(index, 'phone', e.target.value)}
                  className="glass-input"
                  placeholder="(602) 555-0123"
                />
                {errors[`coach${index}_phone`] && (
                  <p className="text-red-400 text-sm mt-1">{errors[`coach${index}_phone`]}</p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-1">Date of Birth *</label>
                <Input
                  type="date"
                  value={coach.dateOfBirth}
                  onChange={(e) => updateCoach(index, 'dateOfBirth', e.target.value)}
                  className="glass-input"
                />
                {errors[`coach${index}_dob`] && (
                  <p className="text-red-400 text-sm mt-1">{errors[`coach${index}_dob`]}</p>
                )}
              </div>
            </div>

            {/* Certifications */}
            <div className="space-y-3">
              <h5 className="text-white font-semibold">Certifications</h5>
              <div className="grid md:grid-cols-2 gap-3">
                <label className="flex items-center gap-2 text-gray-400">
                  <input
                    type="checkbox"
                    checked={coach.certifications.safeSport}
                    onChange={(e) => updateCoach(index, 'certifications.safeSport', e.target.checked)}
                    className="rounded"
                  />
                  SafeSport Certified
                </label>

                <label className="flex items-center gap-2 text-gray-400">
                  <input
                    type="checkbox"
                    checked={coach.certifications.firstAid}
                    onChange={(e) => updateCoach(index, 'certifications.firstAid', e.target.checked)}
                    className="rounded"
                  />
                  First Aid Certified
                </label>

                <label className="flex items-center gap-2 text-gray-400">
                  <input
                    type="checkbox"
                    checked={coach.certifications.cpr}
                    onChange={(e) => updateCoach(index, 'certifications.cpr', e.target.checked)}
                    className="rounded"
                  />
                  CPR Certified
                </label>
              </div>
            </div>

            {/* Background Check Status */}
            <div className="flex items-center justify-between p-3 bg-gray-900/50 rounded-lg">
              <span className="text-sm text-gray-400">Background Check Status:</span>
              <Badge className={`
                ${coach.backgroundCheck.status === 'cleared' ? 'bg-green-500/20 text-green-400' :
                  coach.backgroundCheck.status === 'failed' ? 'bg-red-500/20 text-red-400' :
                  'bg-yellow-500/20 text-yellow-400'}
              `}>
                {coach.backgroundCheck.status === 'cleared' ? 'Cleared' :
                 coach.backgroundCheck.status === 'failed' ? 'Failed' : 'Pending'}
              </Badge>
            </div>
          </div>
        </Card>
      ))}

      <Button
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Player Roster
      </Button>
    </form>
  );
};

export default Step4_CoachingStaff;


