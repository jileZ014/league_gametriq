import React from 'react';
// // import { Card } from '../../ui/input'; // FIXED BUILD ERROR
import { Building, Users, User, ChevronRight } from 'lucide-react';

interface Step1Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step1_RegistrationType: React.FC<Step1Props> = ({ data, onUpdate, onNext }) => {
  const handleTypeSelect = (type: 'organization' | 'team' | 'individual') => {
    onUpdate(type, 'registrationType');
    setTimeout(() => onNext(), 300); // Auto-advance after selection
  };

  return (
    <div className="space-y-6">
      <p className="text-gray-300">
        Please select how you would like to register for the league. Organizations can register 
        multiple teams, while teams and individuals register independently.
      </p>

      <div className="grid md:grid-cols-3 gap-4">
        {/* Organization Registration */}
        <Card 
          className={`
            glass-panel cursor-pointer transition-all hover:scale-105 hover:border-blue-400/50
            ${data.registrationType === 'organization' ? 'border-blue-400 bg-blue-500/10' : ''}
          `}
          onClick={() => handleTypeSelect('organization')}
        >
          <div className="p-6 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 flex items-center justify-center">
              <Building className="h-8 w-8 text-purple-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Organization</h3>
            <p className="text-sm text-gray-400 mb-4">
              Register multiple teams under one organization (schools, clubs, etc.)
            </p>
            <ul className="text-xs text-left space-y-1 text-gray-500">
              <li>• Multiple team discount</li>
              <li>• Unified billing</li>
              <li>• Bulk player management</li>
              <li>• Organization dashboard</li>
            </ul>
            {data.registrationType === 'organization' && (
              <div className="mt-4 text-blue-400 font-semibold">Selected</div>
            )}
          </div>
        </Card>

        {/* Team Registration */}
        <Card 
          className={`
            glass-panel cursor-pointer transition-all hover:scale-105 hover:border-blue-400/50
            ${data.registrationType === 'team' ? 'border-blue-400 bg-blue-500/10' : ''}
          `}
          onClick={() => handleTypeSelect('team')}
        >
          <div className="p-6 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-blue-500/20 to-blue-700/20 flex items-center justify-center">
              <Users className="h-8 w-8 text-blue-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Team</h3>
            <p className="text-sm text-gray-400 mb-4">
              Register a single team with full roster
            </p>
            <ul className="text-xs text-left space-y-1 text-gray-500">
              <li>• 10-15 players</li>
              <li>• Coaching staff</li>
              <li>• Team management</li>
              <li>• Standard pricing</li>
            </ul>
            {data.registrationType === 'team' && (
              <div className="mt-4 text-blue-400 font-semibold">Selected</div>
            )}
          </div>
        </Card>

        {/* Individual Registration */}
        <Card 
          className={`
            glass-panel cursor-pointer transition-all hover:scale-105 hover:border-blue-400/50
            ${data.registrationType === 'individual' ? 'border-blue-400 bg-blue-500/10' : ''}
          `}
          onClick={() => handleTypeSelect('individual')}
        >
          <div className="p-6 text-center">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-green-500/20 to-green-700/20 flex items-center justify-center">
              <User className="h-8 w-8 text-green-400" />
            </div>
            <h3 className="text-xl font-bold text-white mb-2">Individual</h3>
            <p className="text-sm text-gray-400 mb-4">
              Register as a free agent or individual player
            </p>
            <ul className="text-xs text-left space-y-1 text-gray-500">
              <li>• Team placement</li>
              <li>• Skills evaluation</li>
              <li>• Individual pricing</li>
              <li>• Free agent pool</li>
            </ul>
            {data.registrationType === 'individual' && (
              <div className="mt-4 text-blue-400 font-semibold">Selected</div>
            )}
          </div>
        </Card>
      </div>

      {/* Information Box */}
      <div className="glass-panel border-blue-500/30 p-4">
        <h4 className="text-sm font-semibold text-blue-400 mb-2">Need Help Choosing?</h4>
        <div className="space-y-2 text-sm text-gray-400">
          <p>
            <strong className="text-white">Choose Organization</strong> if you're registering 
            2 or more teams from the same school, club, or community group.
          </p>
          <p>
            <strong className="text-white">Choose Team</strong> if you have a group of 
            10-15 players ready to play together as a team.
          </p>
          <p>
            <strong className="text-white">Choose Individual</strong> if you're a single 
            player looking to join a team or be placed on one.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Step1_RegistrationType;


