import React, { useState } from 'react';
// // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
import { Shield, FileText, Camera, AlertCircle } from 'lucide-react';

interface Step9Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step9_Terms: React.FC<Step9Props> = ({ data, onUpdate, onNext }) => {
  const [consents, setConsents] = useState({
    termsAccepted: false,
    liabilityWaiver: false,
    medicalRelease: false,
    photoRelease: false,
    transportAuthorization: false,
    electronicSignature: ''
  });

  const [errors, setErrors] = useState<any>({});

  const validateForm = () => {
    const newErrors: any = {};
    
    if (!consents.termsAccepted) newErrors.terms = 'You must accept the terms and conditions';
    if (!consents.liabilityWaiver) newErrors.liability = 'Liability waiver is required';
    if (!consents.medicalRelease) newErrors.medical = 'Medical release is required';
    if (!consents.electronicSignature) newErrors.signature = 'Electronic signature is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      const consentData = {
        ...consents,
        termsAcceptedAt: new Date().toISOString(),
        termsVersion: '1.0',
        signedBy: consents.electronicSignature,
        signedAt: new Date().toISOString()
      };
      onUpdate(consentData, 'consents');
      onNext();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <h3 className="text-lg font-semibold text-white">Terms & Consent</h3>

      <div className="space-y-4">
        {/* Terms and Conditions */}
        <div className="glass-panel p-4">
          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={consents.termsAccepted}
              onChange={(e) => setConsents({...consents, termsAccepted: e.target.checked})}
              className="mt-1 rounded"
            />
            <div>
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-4 w-4 text-blue-400" />
                <span className="text-white font-semibold">Terms and Conditions *</span>
              </div>
              <p className="text-sm text-gray-400">
                I have read and agree to the league terms and conditions, including rules 
                of play, code of conduct, and participation requirements.
              </p>
            </div>
          </label>
          {errors.terms && <p className="text-red-400 text-sm mt-2">{errors.terms}</p>}
        </div>

        {/* Liability Waiver */}
        <div className="glass-panel p-4">
          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={consents.liabilityWaiver}
              onChange={(e) => setConsents({...consents, liabilityWaiver: e.target.checked})}
              className="mt-1 rounded"
            />
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-yellow-400" />
                <span className="text-white font-semibold">Liability Waiver *</span>
              </div>
              <p className="text-sm text-gray-400">
                I understand the risks associated with participation in basketball activities 
                and release the league from liability for injuries that may occur during 
                sanctioned activities.
              </p>
            </div>
          </label>
          {errors.liability && <p className="text-red-400 text-sm mt-2">{errors.liability}</p>}
        </div>

        {/* Medical Release */}
        <div className="glass-panel p-4">
          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={consents.medicalRelease}
              onChange={(e) => setConsents({...consents, medicalRelease: e.target.checked})}
              className="mt-1 rounded"
            />
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-red-400" />
                <span className="text-white font-semibold">Medical Release *</span>
              </div>
              <p className="text-sm text-gray-400">
                I authorize league officials and coaches to seek emergency medical treatment 
                for my child if I cannot be reached. I have provided accurate medical 
                information and emergency contacts.
              </p>
            </div>
          </label>
          {errors.medical && <p className="text-red-400 text-sm mt-2">{errors.medical}</p>}
        </div>

        {/* Photo Release */}
        <div className="glass-panel p-4">
          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={consents.photoRelease}
              onChange={(e) => setConsents({...consents, photoRelease: e.target.checked})}
              className="mt-1 rounded"
            />
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Camera className="h-4 w-4 text-green-400" />
                <span className="text-white font-semibold">Photo/Video Release (Optional)</span>
              </div>
              <p className="text-sm text-gray-400">
                I grant permission for photos and videos of my child to be used for league 
                promotional purposes, including website, social media, and marketing materials.
              </p>
            </div>
          </label>
        </div>

        {/* Transport Authorization */}
        <div className="glass-panel p-4">
          <label className="flex items-start gap-3">
            <input
              type="checkbox"
              checked={consents.transportAuthorization}
              onChange={(e) => setConsents({...consents, transportAuthorization: e.target.checked})}
              className="mt-1 rounded"
            />
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Shield className="h-4 w-4 text-purple-400" />
                <span className="text-white font-semibold">Transportation Authorization (Optional)</span>
              </div>
              <p className="text-sm text-gray-400">
                I authorize my child to be transported by approved coaches or team parents 
                to and from games and practices when necessary.
              </p>
            </div>
          </label>
        </div>
      </div>

      {/* Electronic Signature */}
      <div className="glass-panel p-4">
        <label>
          <span className="text-white font-semibold">Electronic Signature *</span>
          <p className="text-sm text-gray-400 mb-3">
            Type your full legal name to serve as your electronic signature
          </p>
          <input
            type="text"
            value={consents.electronicSignature}
            onChange={(e) => setConsents({...consents, electronicSignature: e.target.value})}
            className="glass-input w-full"
            placeholder="John Doe"
          />
        </label>
        {errors.signature && <p className="text-red-400 text-sm mt-2">{errors.signature}</p>}
      </div>

      {/* Legal Notice */}
      <div className="glass-panel border-blue-500/30 p-4">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-blue-400 mt-0.5" />
          <div className="text-sm text-gray-400">
            <p className="text-blue-400 font-semibold mb-1">Legal Notice</p>
            <p>
              By providing your electronic signature above, you agree that it has the same 
              legal effect as a handwritten signature. You confirm that you are the legal 
              guardian of the player(s) being registered and have authority to agree to 
              these terms on their behalf.
            </p>
          </div>
        </div>
      </div>

      <Button 
        type="submit"
        className="glass-button bg-green-500/20 hover:bg-green-500/30 w-full"
      >
        Review & Submit Registration
      </Button>
    </form>
  );
};

export default Step9_Terms;


