import React from 'react';
// // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
import { Phone, AlertCircle } from 'lucide-react';

interface Step6Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step6_EmergencyContacts: React.FC<Step6Props> = ({ data, onUpdate, onNext }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Update players with emergency contacts
    const playersWithContacts = (data.players || []).map((player: any) => ({
      ...player,
      emergencyContacts: [
        {
          id: '1',
          name: 'Emergency Contact',
          relationship: 'Grandparent',
          phone: '(602) 555-9999',
          alternatePhone: '',
          isPrimary: true,
          canPickup: true,
          medicalDecisions: true
        }
      ]
    }));
    onUpdate(playersWithContacts, 'players');
    onNext();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="glass-panel border-red-500/50 p-4">
        <div className="flex gap-3">
          <Phone className="h-5 w-5 text-red-400" />
          <div>
            <p className="text-red-400 font-semibold">Emergency Contacts Required</p>
            <p className="text-sm text-gray-400 mt-1">
              Each player must have at least 2 emergency contacts who can be reached during 
              games and practices. These contacts should be different from parents/guardians.
            </p>
          </div>
        </div>
      </div>
      
      <Button 
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Guardian Information
      </Button>
    </form>
  );
};

export default Step6_EmergencyContacts;


