import React from 'react';
// // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
import { User, AlertCircle } from 'lucide-react';

interface Step7Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step7_GuardianInfo: React.FC<Step7Props> = ({ data, onUpdate, onNext }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Update players with guardian info
    const playersWithGuardians = (data.players || []).map((player: any) => ({
      ...player,
      guardians: [
        {
          id: '1',
          type: 'parent',
          relationship: 'mother',
          firstName: 'Jane',
          lastName: 'Doe',
          email: 'jane.doe@email.com',
          phone: '(602) 555-0123',
          address: {
            street: '123 Main St',
            city: 'Phoenix',
            state: 'AZ',
            zip: '85001'
          },
          isPrimaryContact: true,
          hasLegalCustody: true,
          canAuthorize: true
        }
      ]
    }));
    onUpdate(playersWithGuardians, 'players');
    onNext();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="glass-panel border-blue-500/50 p-4">
        <div className="flex gap-3">
          <User className="h-5 w-5 text-blue-400" />
          <div>
            <p className="text-blue-400 font-semibold">Guardian Information</p>
            <p className="text-sm text-gray-400 mt-1">
              Complete guardian details including custody status and authorization for 
              medical decisions. All guardians must be verified.
            </p>
          </div>
        </div>
      </div>
      
      <Button 
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Payment
      </Button>
    </form>
  );
};

export default Step7_GuardianInfo;


