import React from 'react';
// // import { Button } from '../../ui/input'; // FIXED BUILD ERROR
import { AlertCircle } from 'lucide-react';

interface Step5Props {
  data: any;
  onUpdate: (data: any, key: string) => void;
  onNext: () => void;
}

const Step5_PlayerRoster: React.FC<Step5Props> = ({ data, onUpdate, onNext }) => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Placeholder - in full implementation, this would manage complete player roster with medical info
    onUpdate([
      {
        id: '1',
        firstName: 'Sample',
        lastName: 'Player',
        dateOfBirth: '2010-01-01',
        medical: {
          allergies: [],
          conditions: [],
          medications: [],
          physician: { name: '', practice: '', phone: '', address: '' },
          insurance: { provider: '', policyNumber: '', groupNumber: '', subscriberName: '', subscriberRelation: '' }
        },
        emergencyContacts: [],
        guardians: []
      }
    ], 'players');
    onNext();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="glass-panel border-yellow-500/50 p-4">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-yellow-400" />
          <div>
            <p className="text-yellow-400 font-semibold">Player Roster with Medical Information</p>
            <p className="text-sm text-gray-400 mt-1">
              Full implementation includes: player details, medical conditions, allergies, 
              medications, physician info, and insurance details for each player.
            </p>
          </div>
        </div>
      </div>
      
      <Button 
        type="submit"
        className="glass-button bg-blue-500/20 hover:bg-blue-500/30 w-full"
      >
        Continue to Emergency Contacts
      </Button>
    </form>
  );
};

export default Step5_PlayerRoster;


