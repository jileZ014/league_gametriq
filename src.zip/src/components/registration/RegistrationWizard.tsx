import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Users, Building, User, ChevronRight, ChevronLeft, 
  Check, Save, AlertCircle, Shield, Heart, Phone
} from 'lucide-react';
import { db } from '../../firebase';
import { collection, addDoc, updateDoc, doc, serverTimestamp } from 'firebase/firestore';

// Import step components
import Step1_RegistrationType from './steps/Step1_RegistrationType';
import Step2_OrganizationInfo from './steps/Step2_OrganizationInfo';
import Step3_TeamInfo from './steps/Step3_TeamInfo';
import Step4_CoachingStaff from './steps/Step4_CoachingStaff';
import Step5_PlayerRoster from './steps/Step5_PlayerRoster';
import Step6_EmergencyContacts from './steps/Step6_EmergencyContacts';
import Step7_GuardianInfo from './steps/Step7_GuardianInfo';
import Step8_Payment from './steps/Step8_Payment';
import Step9_Terms from './steps/Step9_Terms';
import RegistrationProgress from './RegistrationProgress';
import RegistrationSummary from './RegistrationSummary';

interface RegistrationWizardProps {
  initialType: 'organization' | 'team' | 'individual' | null;
  onTypeChange: (type: 'organization' | 'team' | 'individual' | null) => void;
}

export interface RegistrationData {
  registrationType: 'organization' | 'team' | 'individual';
  status: 'draft' | 'pending' | 'approved' | 'rejected';
  organization?: any;
  teams: any[];
  coaches: any[];
  players: any[];
  payment: any;
  consents: any;
  admin?: any;
}

const RegistrationWizard: React.FC<RegistrationWizardProps> = ({ 
  initialType, 
  onTypeChange 
}) => {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(0);
  const [showSummary, setShowSummary] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [registrationId, setRegistrationId] = useState<string | null>(null);
  
  // Form data state
  const [formData, setFormData] = useState<RegistrationData>({
    registrationType: initialType || 'team',
    status: 'draft',
    teams: [],
    coaches: [],
    players: [],
    payment: {
      method: null,
      status: 'pending',
      fees: {
        registrationFee: 150,
        uniformFee: 50,
        facilityFee: 25,
        insuranceFee: 15,
        subtotal: 240,
        totalDue: 240
      },
      transactions: []
    },
    consents: {}
  });

  // Define steps based on registration type
  const getSteps = () => {
    const baseSteps = [
      { 
        title: 'Registration Type', 
        icon: Users,
        component: Step1_RegistrationType,
        required: true
      }
    ];

    if (formData.registrationType === 'organization') {
      return [
        ...baseSteps,
        { title: 'Organization Info', icon: Building, component: Step2_OrganizationInfo, required: true },
        { title: 'Team Details', icon: Users, component: Step3_TeamInfo, required: true },
        { title: 'Coaching Staff', icon: Shield, component: Step4_CoachingStaff, required: true },
        { title: 'Player Roster', icon: Users, component: Step5_PlayerRoster, required: true },
        { title: 'Emergency Contacts', icon: Phone, component: Step6_EmergencyContacts, required: true },
        { title: 'Guardian Info', icon: User, component: Step7_GuardianInfo, required: true },
        { title: 'Payment', icon: Heart, component: Step8_Payment, required: true },
        { title: 'Terms & Consent', icon: Shield, component: Step9_Terms, required: true }
      ];
    } else if (formData.registrationType === 'team') {
      return [
        ...baseSteps,
        { title: 'Team Details', icon: Users, component: Step3_TeamInfo, required: true },
        { title: 'Coaching Staff', icon: Shield, component: Step4_CoachingStaff, required: true },
        { title: 'Player Roster', icon: Users, component: Step5_PlayerRoster, required: true },
        { title: 'Emergency Contacts', icon: Phone, component: Step6_EmergencyContacts, required: true },
        { title: 'Guardian Info', icon: User, component: Step7_GuardianInfo, required: true },
        { title: 'Payment', icon: Heart, component: Step8_Payment, required: true },
        { title: 'Terms & Consent', icon: Shield, component: Step9_Terms, required: true }
      ];
    } else {
      return [
        ...baseSteps,
        { title: 'Player Info', icon: User, component: Step5_PlayerRoster, required: true },
        { title: 'Emergency Contacts', icon: Phone, component: Step6_EmergencyContacts, required: true },
        { title: 'Guardian Info', icon: User, component: Step7_GuardianInfo, required: true },
        { title: 'Payment', icon: Heart, component: Step8_Payment, required: true },
        { title: 'Terms & Consent', icon: Shield, component: Step9_Terms, required: true }
      ];
    }
  };

  const steps = getSteps();
  const CurrentStepComponent = steps[currentStep]?.component;

  // Auto-save to localStorage
  useEffect(() => {
    const saveTimer = setTimeout(() => {
      localStorage.setItem('registrationDraft', JSON.stringify(formData));
      localStorage.setItem('registrationStep', currentStep.toString());
    }, 1000);

    return () => clearTimeout(saveTimer);
  }, [formData, currentStep]);

  // Load saved draft on mount
  useEffect(() => {
    const savedData = localStorage.getItem('registrationDraft');
    const savedStep = localStorage.getItem('registrationStep');
    
    if (savedData) {
      try {
        const parsed = JSON.parse(savedData);
        setFormData(parsed);
        if (savedStep) {
          setCurrentStep(parseInt(savedStep));
        }
      } catch (e) {
        console.error('Error loading saved draft:', e);
      }
    }
  }, []);

  const updateFormData = (stepData: any, stepKey: string) => {
    setFormData(prev => ({
      ...prev,
      [stepKey]: stepData
    }));
  };

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowSummary(true);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    setError(null);

    try {
      // Add registration to Firestore
      const registrationData = {
        ...formData,
        status: 'pending',
        submittedAt: serverTimestamp(),
        lastModified: serverTimestamp()
      };

      const docRef = await addDoc(collection(db, 'registrations'), registrationData);
      setRegistrationId(docRef.id);

      // Clear localStorage
      localStorage.removeItem('registrationDraft');
      localStorage.removeItem('registrationStep');

      // Show success message
      alert('Registration submitted successfully! You will receive a confirmation email shortly.');
      
      // Navigate to home after delay
      setTimeout(() => {
        navigate('/');
      }, 3000);

    } catch (err: any) {
      console.error('Error submitting registration:', err);
      setError('Failed to submit registration. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (showSummary) {
    return (
      <RegistrationSummary
        data={formData}
        onEdit={(stepIndex) => {
          setCurrentStep(stepIndex);
          setShowSummary(false);
        }}
        onSubmit={handleSubmit}
        isSubmitting={isSubmitting}
        error={error}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Progress Indicator */}
      <RegistrationProgress 
        steps={steps.map(s => s.title)}
        currentStep={currentStep}
      />

      {/* Safety Notice */}
      {(currentStep === 4 || currentStep === 5) && (
        <div className="glass-panel border-yellow-500/50 p-4">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-yellow-400 mt-0.5" />
            <div>
              <p className="text-yellow-400 font-semibold">Safety First</p>
              <p className="text-sm text-gray-400 mt-1">
                Emergency contacts and medical information are required for all players. 
                This ensures we can provide proper care in case of emergencies.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Current Step */}
      <Card className="glass-panel">
        <div className="p-6">
          <div className="flex items-center gap-3 mb-6">
            {React.createElement(steps[currentStep].icon, { 
              className: "h-6 w-6 text-blue-400" 
            })}
            <h2 className="text-2xl font-bold text-white">
              {steps[currentStep].title}
            </h2>
            {steps[currentStep].required && (
              <Badge className="glass-badge border-red-500/50">Required</Badge>
            )}
          </div>

          {CurrentStepComponent && (
            <CurrentStepComponent
              data={formData}
              onUpdate={updateFormData}
              onNext={handleNext}
            />
          )}
        </div>

        {/* Navigation */}
        <div className="border-t border-gray-800 p-6">
          <div className="flex justify-between items-center">
            <Button
              onClick={handlePrevious}
              disabled={currentStep === 0}
              variant="ghost"
              className="text-white"
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>

            <div className="flex gap-2">
              <Button
                onClick={() => {
                  localStorage.setItem('registrationDraft', JSON.stringify(formData));
                  alert('Draft saved! You can return later to complete your registration.');
                }}
                variant="outline"
                className="glass-button"
              >
                <Save className="h-4 w-4 mr-2" />
                Save Draft
              </Button>

              <Button
                onClick={handleNext}
                className="glass-button bg-blue-500/20 hover:bg-blue-500/30"
              >
                {currentStep === steps.length - 1 ? (
                  <>
                    Review & Submit
                    <Check className="h-4 w-4 ml-2" />
                  </>
                ) : (
                  <>
                    Next
                    <ChevronRight className="h-4 w-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>
      </Card>

      {/* Error Display */}
      {error && (
        <div className="glass-panel border-red-500/50 p-4">
          <div className="flex items-center gap-2 text-red-400">
            <AlertCircle className="h-5 w-5" />
            <p>{error}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default RegistrationWizard;