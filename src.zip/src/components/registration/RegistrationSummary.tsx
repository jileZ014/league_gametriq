import React from 'react';
import { Card } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Check, Edit, Building, Users, Shield, Phone, 
  User, DollarSign, FileText, AlertCircle 
} from 'lucide-react';

interface RegistrationSummaryProps {
  data: any;
  onEdit: (stepIndex: number) => void;
  onSubmit: () => void;
  isSubmitting: boolean;
  error: string | null;
}

const RegistrationSummary: React.FC<RegistrationSummaryProps> = ({
  data,
  onEdit,
  onSubmit,
  isSubmitting,
  error
}) => {
  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Registration Summary</h2>
        <p className="text-gray-400">Please review your information before submitting</p>
      </div>

      {/* Registration Type */}
      <Card className="glass-panel p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold text-white mb-2">Registration Type</h3>
            <Badge className="glass-badge">
              {data.registrationType === 'organization' ? 'Organization' :
               data.registrationType === 'team' ? 'Team' : 'Individual'}
            </Badge>
          </div>
          <Button 
            onClick={() => onEdit(0)} 
            variant="ghost" 
            size="sm"
            className="text-blue-400"
          >
            <Edit className="h-4 w-4" />
          </Button>
        </div>
      </Card>

      {/* Organization Info (if applicable) */}
      {data.organization && (
        <Card className="glass-panel p-6">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <Building className="h-5 w-5 text-purple-400" />
                <h3 className="text-lg font-semibold text-white">Organization</h3>
              </div>
              <div className="space-y-1 text-sm">
                <p className="text-gray-300">{data.organization.name}</p>
                <p className="text-gray-400">{data.organization.primaryContact.name}</p>
                <p className="text-gray-400">{data.organization.primaryContact.email}</p>
              </div>
            </div>
            <Button 
              onClick={() => onEdit(1)} 
              variant="ghost" 
              size="sm"
              className="text-blue-400"
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Teams */}
      {data.teams && data.teams.length > 0 && (
        <Card className="glass-panel p-6">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-5 w-5 text-blue-400" />
                <h3 className="text-lg font-semibold text-white">
                  {data.teams.length === 1 ? 'Team' : `Teams (${data.teams.length})`}
                </h3>
              </div>
              <div className="space-y-2">
                {data.teams.map((team: any, index: number) => (
                  <div key={index} className="text-sm">
                    <p className="text-gray-300">{team.teamName}</p>
                    <p className="text-gray-400">{team.division} • {team.gradeLevel}</p>
                  </div>
                ))}
              </div>
            </div>
            <Button 
              onClick={() => onEdit(data.registrationType === 'organization' ? 2 : 1)} 
              variant="ghost" 
              size="sm"
              className="text-blue-400"
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Coaches */}
      {data.coaches && data.coaches.length > 0 && (
        <Card className="glass-panel p-6">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <Shield className="h-5 w-5 text-yellow-400" />
                <h3 className="text-lg font-semibold text-white">
                  Coaching Staff ({data.coaches.length})
                </h3>
              </div>
              <div className="space-y-2">
                {data.coaches.map((coach: any, index: number) => (
                  <div key={index} className="text-sm">
                    <p className="text-gray-300">
                      {coach.firstName} {coach.lastName}
                      <Badge className="ml-2 text-xs">
                        {coach.role === 'head' ? 'Head Coach' : 
                         coach.role === 'assistant' ? 'Assistant' : 'Volunteer'}
                      </Badge>
                    </p>
                    <p className="text-gray-400">{coach.email}</p>
                  </div>
                ))}
              </div>
            </div>
            <Button 
              onClick={() => onEdit(data.registrationType === 'organization' ? 3 : 2)} 
              variant="ghost" 
              size="sm"
              className="text-blue-400"
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Players */}
      {data.players && data.players.length > 0 && (
        <Card className="glass-panel p-6">
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-5 w-5 text-green-400" />
                <h3 className="text-lg font-semibold text-white">
                  Players ({data.players.length})
                </h3>
              </div>
              <div className="text-sm text-gray-400">
                <p>{data.players.length} players registered</p>
                <p className="text-green-400">✓ Medical information provided</p>
                <p className="text-green-400">✓ Emergency contacts added</p>
                <p className="text-green-400">✓ Guardian information complete</p>
              </div>
            </div>
            <Button 
              onClick={() => onEdit(4)} 
              variant="ghost" 
              size="sm"
              className="text-blue-400"
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Payment */}
      {data.payment && (
        <Card className="glass-panel p-6">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <DollarSign className="h-5 w-5 text-green-400" />
                <h3 className="text-lg font-semibold text-white">Payment</h3>
              </div>
              <div className="space-y-1 text-sm">
                <p className="text-gray-300">
                  Method: {data.payment.method === 'credit_card' ? 'Credit Card' :
                          data.payment.method === 'check' ? 'Check/Cash' :
                          data.payment.method === 'payment_plan' ? 'Payment Plan' :
                          'Scholarship'}
                </p>
                <p className="text-gray-400">Total Due: ${data.payment.fees?.totalDue || 240}</p>
              </div>
            </div>
            <Button 
              onClick={() => onEdit(7)} 
              variant="ghost" 
              size="sm"
              className="text-blue-400"
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Terms & Consents */}
      {data.consents && (
        <Card className="glass-panel p-6">
          <div className="flex justify-between items-start">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <FileText className="h-5 w-5 text-purple-400" />
                <h3 className="text-lg font-semibold text-white">Terms & Consents</h3>
              </div>
              <div className="space-y-1 text-sm">
                {data.consents.termsAccepted && (
                  <p className="text-green-400">✓ Terms accepted</p>
                )}
                {data.consents.liabilityWaiver && (
                  <p className="text-green-400">✓ Liability waiver signed</p>
                )}
                {data.consents.medicalRelease && (
                  <p className="text-green-400">✓ Medical release authorized</p>
                )}
                {data.consents.electronicSignature && (
                  <p className="text-gray-400">Signed by: {data.consents.electronicSignature}</p>
                )}
              </div>
            </div>
            <Button 
              onClick={() => onEdit(8)} 
              variant="ghost" 
              size="sm"
              className="text-blue-400"
            >
              <Edit className="h-4 w-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Important Notice */}
      <div className="glass-panel border-yellow-500/50 p-4">
        <div className="flex gap-3">
          <AlertCircle className="h-5 w-5 text-yellow-400 mt-0.5" />
          <div className="text-sm">
            <p className="text-yellow-400 font-semibold mb-1">Before You Submit</p>
            <ul className="text-gray-400 space-y-1">
              <li>• All information provided will be verified</li>
              <li>• Background checks will be initiated for all coaches</li>
              <li>• You will receive a confirmation email within 24 hours</li>
              <li>• Registration approval typically takes 2-3 business days</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Error Display */}
      {error && (
        <div className="glass-panel border-red-500/50 p-4">
          <div className="flex items-center gap-2 text-red-400">
            <AlertCircle className="h-5 w-5" />
            <p>{error}</p>
          </div>
        </div>
      )}

      {/* Submit Button */}
      <div className="flex justify-center">
        <Button
          onClick={onSubmit}
          disabled={isSubmitting}
          className="glass-button bg-green-500/20 hover:bg-green-500/30 px-8 py-4 text-lg"
        >
          {isSubmitting ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-3" />
              Submitting Registration...
            </>
          ) : (
            <>
              <Check className="h-5 w-5 mr-2" />
              Submit Registration
            </>
          )}
        </Button>
      </div>
    </div>
  );
};

export default RegistrationSummary;