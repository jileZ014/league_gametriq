import React, { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { doc, updateDoc, getDoc } from 'firebase/firestore';

interface Player {
  id: string;
  name: string;
  jerseyNumber?: string;
}

interface GameStats {
  points: number;
  fieldGoalsMade: number;
  fieldGoalsAttempted: number;
  threePointersMade: number;
  threePointersAttempted: number;
  freeThrowsMade: number;
  freeThrowsAttempted: number;
  assists: number;
  rebounds: number;
  steals: number;
  blocks: number;
  turnovers: number;
  fouls: number;
}

interface StatAction {
  type: string;
  playerId: string;
  value: number;
  timestamp: Date;
}

interface ComprehensiveStatTrackerProps {
  gameId: string;
  players: Player[];
  onComplete: () => void;
}

export default function ComprehensiveStatTracker({ gameId, players, onComplete }: ComprehensiveStatTrackerProps) {
  const [selectedPlayerIndex, setSelectedPlayerIndex] = useState(0);
  const [playerStats, setPlayerStats] = useState<Record<string, GameStats>>({});
  const [actionHistory, setActionHistory] = useState<StatAction[]>([]);
  const [animatingStats, setAnimatingStats] = useState<Set<string>>(new Set());
  
  const selectedPlayer = players[selectedPlayerIndex];

  // Initialize player stats
  useEffect(() => {
    const initialStats: Record<string, GameStats> = {};
    players.forEach(player => {
      initialStats[player.id] = {
        points: 0,
        fieldGoalsMade: 0,
        fieldGoalsAttempted: 0,
        threePointersMade: 0,
        threePointersAttempted: 0,
        freeThrowsMade: 0,
        freeThrowsAttempted: 0,
        assists: 0,
        rebounds: 0,
        steals: 0,
        blocks: 0,
        turnovers: 0,
        fouls: 0
      };
    });
    setPlayerStats(initialStats);
  }, [players]);

  const currentStats = selectedPlayer ? playerStats[selectedPlayer.id] : null;

  // Calculate shooting percentages
  const calculatePercentage = (made: number, attempted: number) => {
    if (attempted === 0) return 0;
    return Math.round((made / attempted) * 100);
  };

  const fgPercentage = currentStats ? calculatePercentage(currentStats.fieldGoalsMade, currentStats.fieldGoalsAttempted) : 0;
  const ftPercentage = currentStats ? calculatePercentage(currentStats.freeThrowsMade, currentStats.freeThrowsAttempted) : 0;
  const threePtPercentage = currentStats ? calculatePercentage(currentStats.threePointersMade, currentStats.threePointersAttempted) : 0;

  // Get performance color based on percentage
  const getPerformanceColor = (percentage: number) => {
    if (percentage >= 70) return '#22c55e';
    if (percentage >= 50) return '#f59e0b';
    return '#ef4444';
  };

  // Animate stat change
  const animateStat = (statKey: string) => {
    setAnimatingStats(prev => new Set([...prev, statKey]));
    setTimeout(() => {
      setAnimatingStats(prev => {
        const newSet = new Set(prev);
        newSet.delete(statKey);
        return newSet;
      });
    }, 300);
  };

  // Handle primary shot (2-pointers)
  const handlePrimaryShot = (made: boolean) => {
    if (!selectedPlayer || !currentStats) return;

    const updates = { ...currentStats };
    updates.fieldGoalsAttempted++;
    if (made) {
      updates.fieldGoalsMade++;
      updates.points += 2;
      animateStat('points');
    }

    updatePlayerStats(selectedPlayer.id, updates);
    addToHistory('2pt', made ? 2 : 0);
    animateStat('fg');
  };

  // Handle free throws
  const handleFreeThrow = (made: boolean) => {
    if (!selectedPlayer || !currentStats) return;

    const updates = { ...currentStats };
    updates.freeThrowsAttempted++;
    if (made) {
      updates.freeThrowsMade++;
      updates.points += 1;
      animateStat('points');
    }

    updatePlayerStats(selectedPlayer.id, updates);
    addToHistory('ft', made ? 1 : 0);
    animateStat('ft');
  };

  // Handle 3-pointers
  const handleThreePointer = (made: boolean) => {
    if (!selectedPlayer || !currentStats) return;

    const updates = { ...currentStats };
    updates.threePointersAttempted++;
    updates.fieldGoalsAttempted++;
    if (made) {
      updates.threePointersMade++;
      updates.fieldGoalsMade++;
      updates.points += 3;
      animateStat('points');
    }

    updatePlayerStats(selectedPlayer.id, updates);
    addToHistory('3pt', made ? 3 : 0);
    animateStat('3pt');
  };

  // Handle other stats
  const handleStatChange = (stat: keyof GameStats, increment: boolean) => {
    if (!selectedPlayer || !currentStats) return;

    const updates = { ...currentStats };
    const change = increment ? 1 : -1;
    (updates[stat] as number) += change;
    if ((updates[stat] as number) < 0) (updates[stat] as number) = 0;

    updatePlayerStats(selectedPlayer.id, updates);
    addToHistory(stat, change);
    animateStat(stat);
  };

  const updatePlayerStats = (playerId: string, stats: GameStats) => {
    setPlayerStats(prev => ({
      ...prev,
      [playerId]: stats
    }));
    saveStats();
  };

  const addToHistory = (type: string, value: number) => {
    setActionHistory(prev => [...prev, {
      type,
      playerId: selectedPlayer.id,
      value,
      timestamp: new Date()
    }]);
  };

  // Undo last action
  const handleUndo = () => {
    if (actionHistory.length === 0) return;

    const lastAction = actionHistory[actionHistory.length - 1];
    const stats = { ...playerStats[lastAction.playerId] };

    // Reverse the last action
    switch (lastAction.type) {
      case '2pt':
        stats.fieldGoalsAttempted--;
        if (lastAction.value > 0) {
          stats.fieldGoalsMade--;
          stats.points -= 2;
        }
        break;
      case 'ft':
        stats.freeThrowsAttempted--;
        if (lastAction.value > 0) {
          stats.freeThrowsMade--;
          stats.points -= 1;
        }
        break;
      case '3pt':
        stats.threePointersAttempted--;
        stats.fieldGoalsAttempted--;
        if (lastAction.value > 0) {
          stats.threePointersMade--;
          stats.fieldGoalsMade--;
          stats.points -= 3;
        }
        break;
      default:
        (stats[lastAction.type as keyof GameStats] as number) -= lastAction.value;
        if ((stats[lastAction.type as keyof GameStats] as number) < 0) {
          (stats[lastAction.type as keyof GameStats] as number) = 0;
        }
    }

    setPlayerStats(prev => ({
      ...prev,
      [lastAction.playerId]: stats
    }));

    setActionHistory(prev => prev.slice(0, -1));
    saveStats();
  };

  // Clear all stats for current player
  const handleClearAll = () => {
    if (!selectedPlayer) return;

    setPlayerStats(prev => ({
      ...prev,
      [selectedPlayer.id]: {
        points: 0,
        fieldGoalsMade: 0,
        fieldGoalsAttempted: 0,
        threePointersMade: 0,
        threePointersAttempted: 0,
        freeThrowsMade: 0,
        freeThrowsAttempted: 0,
        assists: 0,
        rebounds: 0,
        steals: 0,
        blocks: 0,
        turnovers: 0,
        fouls: 0
      }
    }));

    setActionHistory(prev => prev.filter(action => action.playerId !== selectedPlayer.id));
    saveStats();
  };

  // Navigate between players
  const navigatePlayer = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      setSelectedPlayerIndex(prev => prev > 0 ? prev - 1 : players.length - 1);
    } else {
      setSelectedPlayerIndex(prev => prev < players.length - 1 ? prev + 1 : 0);
    }
  };

  const saveStats = async () => {
    if (!auth.currentUser) return;

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (!userDoc.exists()) return;

      const userData = userDoc.data();
      const games = userData.games || [];
      
      const updatedGames = games.map((game: any) => {
        if (game.id === gameId) {
          return {
            ...game,
            stats: playerStats,
            lastUpdated: new Date().toISOString(),
            status: 'in_progress'
          };
        }
        return game;
      });

      await updateDoc(doc(db, 'users', auth.currentUser.uid), {
        games: updatedGames
      });
    } catch (error) {
      console.error('Error saving stats:', error);
    }
  };

  const completeGame = async () => {
    if (!auth.currentUser) return;

    try {
      const userDoc = await getDoc(doc(db, 'users', auth.currentUser.uid));
      if (!userDoc.exists()) return;

      const userData = userDoc.data();
      const games = userData.games || [];
      const players = userData.players || [];
      
      const updatedGames = games.map((game: any) => {
        if (game.id === gameId) {
          return {
            ...game,
            status: 'completed',
            stats: playerStats,
            completedAt: new Date().toISOString()
          };
        }
        return game;
      });

      // Update player season stats
      const updatedPlayers = players.map((player: any) => {
        const gameStats = playerStats[player.id];
        if (gameStats) {
          return {
            ...player,
            stats: {
              points: (player.stats?.points || 0) + gameStats.points,
              assists: (player.stats?.assists || 0) + gameStats.assists,
              rebounds: (player.stats?.rebounds || 0) + gameStats.rebounds,
              steals: (player.stats?.steals || 0) + gameStats.steals,
              blocks: (player.stats?.blocks || 0) + gameStats.blocks,
              fouls: (player.stats?.fouls || 0) + gameStats.fouls
            }
          };
        }
        return player;
      });

      await updateDoc(doc(db, 'users', auth.currentUser.uid), {
        games: updatedGames,
        players: updatedPlayers
      });
      
      onComplete();
    } catch (error) {
      console.error('Error completing game:', error);
    }
  };

  if (!selectedPlayer || !currentStats) {
    return <div className="min-h-screen bg-navy-950 text-white p-4 flex items-center justify-center">
      <div className="text-center">
        <p className="text-xl mb-4">No players available</p>
        <button onClick={onComplete} className="px-6 py-2 bg-basketball-orange-500 rounded-lg">
          Back to Dashboard
        </button>
      </div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-navy-950 text-white relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute inset-0 bg-gradient-to-br from-basketball-orange-500/10 via-transparent to-blue-500/10" />
      </div>

      <div className="relative z-10 max-w-md mx-auto p-4 pb-24">
        {/* Player Header */}
        <div className="mb-6 text-center">
          <div className="flex items-center justify-between mb-4">
            <button
              onClick={() => navigatePlayer('prev')}
              className="p-3 rounded-2xl bg-navy-800 border border-navy-700 hover:border-basketball-orange-500 transition-all"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            
            <div className="flex-1">
              <h1 className="text-2xl font-bold">
                {selectedPlayer.name}
              </h1>
              {selectedPlayer.jerseyNumber && (
                <div className="text-sm text-gray-400">
                  #{selectedPlayer.jerseyNumber}
                </div>
              )}
            </div>

            <button
              onClick={() => navigatePlayer('next')}
              className="p-3 rounded-2xl bg-navy-800 border border-navy-700 hover:border-basketball-orange-500 transition-all"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          {/* Points Display */}
          <div className={`inline-flex items-center justify-center transition-all duration-300 ${animatingStats.has('points') ? 'scale-110' : ''}`}>
            <span className="text-6xl font-bold text-basketball-orange-500">
              {currentStats.points}
            </span>
            <span className="text-2xl font-medium text-gray-400 ml-2">PTS</span>
          </div>
        </div>

        {/* SHOOTING ZONE */}
        <div className="mb-6 rounded-xl bg-navy-800 border border-navy-700 p-5">
          <h2 className="text-lg font-bold mb-4 text-basketball-orange-500">Shooting Zone</h2>

          {/* Field Goals */}
          <div className={`mb-6 transition-all duration-300 ${animatingStats.has('fg') ? 'scale-102' : ''}`}>
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-gray-400">Field Goals</span>
              <span className="text-lg font-bold">{fgPercentage}%</span>
            </div>
            <div className="mb-3">
              <div className="h-2 bg-navy-900 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${fgPercentage}%`,
                    backgroundColor: getPerformanceColor(fgPercentage)
                  }}
                />
              </div>
              <div className="mt-1 text-center text-sm text-gray-500">
                {currentStats.fieldGoalsMade}/{currentStats.fieldGoalsAttempted}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handlePrimaryShot(true)}
                className="py-3 rounded-lg font-bold text-white bg-green-600 hover:bg-green-700 transition-all"
              >
                MADE
              </button>
              <button
                onClick={() => handlePrimaryShot(false)}
                className="py-3 rounded-lg font-bold text-white bg-red-600 hover:bg-red-700 transition-all"
              >
                MISSED
              </button>
            </div>
          </div>

          {/* Free Throws */}
          <div className={`mb-6 pb-6 border-b border-navy-700 transition-all duration-300 ${animatingStats.has('ft') ? 'scale-102' : ''}`}>
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-gray-400">Free Throws</span>
              <span className="text-lg font-bold">{ftPercentage}%</span>
            </div>
            <div className="mb-3">
              <div className="h-2 bg-navy-900 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${ftPercentage}%`,
                    backgroundColor: getPerformanceColor(ftPercentage)
                  }}
                />
              </div>
              <div className="mt-1 text-center text-sm text-gray-500">
                {currentStats.freeThrowsMade}/{currentStats.freeThrowsAttempted}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleFreeThrow(true)}
                className="py-3 rounded-lg font-semibold text-white bg-green-600 hover:bg-green-700 transition-all"
              >
                MADE
              </button>
              <button
                onClick={() => handleFreeThrow(false)}
                className="py-3 rounded-lg font-semibold text-white bg-red-600 hover:bg-red-700 transition-all"
              >
                MISSED
              </button>
            </div>
          </div>

          {/* 3-Pointers */}
          <div className={`transition-all duration-300 ${animatingStats.has('3pt') ? 'scale-102' : ''}`}>
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium text-gray-400">3-Pointers</span>
              <span className="text-lg font-bold">{threePtPercentage}%</span>
            </div>
            <div className="mb-3">
              <div className="h-2 bg-navy-900 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${threePtPercentage}%`,
                    backgroundColor: getPerformanceColor(threePtPercentage)
                  }}
                />
              </div>
              <div className="mt-1 text-center text-sm text-gray-500">
                {currentStats.threePointersMade}/{currentStats.threePointersAttempted}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleThreePointer(true)}
                className="py-3 rounded-lg font-semibold text-white bg-green-600 hover:bg-green-700 transition-all"
              >
                MADE
              </button>
              <button
                onClick={() => handleThreePointer(false)}
                className="py-3 rounded-lg font-semibold text-white bg-red-600 hover:bg-red-700 transition-all"
              >
                MISSED
              </button>
            </div>
          </div>
        </div>

        {/* OTHER STATS */}
        <div className="mb-6 rounded-xl bg-navy-800 border border-navy-700 p-5">
          <h2 className="text-lg font-bold mb-4 text-basketball-orange-500">Other Stats</h2>
          
          <div className="grid grid-cols-2 gap-4">
            {[
              { key: 'rebounds', label: 'Rebounds' },
              { key: 'assists', label: 'Assists' },
              { key: 'steals', label: 'Steals' },
              { key: 'blocks', label: 'Blocks' },
              { key: 'turnovers', label: 'Turnovers' },
              { key: 'fouls', label: 'Fouls' },
            ].map(({ key, label }) => (
              <div key={key} className={`transition-all duration-300 ${animatingStats.has(key) ? 'scale-105' : ''}`}>
                <div className="flex items-center justify-between p-3 rounded-lg bg-navy-900 border border-navy-700">
                  <div>
                    <div className="text-xs text-gray-400">{label}</div>
                    <div className="text-2xl font-bold">{currentStats[key as keyof GameStats]}</div>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleStatChange(key as keyof GameStats, true)}
                      className="w-8 h-8 rounded-lg bg-navy-700 hover:bg-basketball-orange-500 transition-all flex items-center justify-center"
                    >
                      +
                    </button>
                    {key !== 'fouls' && (
                      <button
                        onClick={() => handleStatChange(key as keyof GameStats, false)}
                        className="w-8 h-8 rounded-lg bg-navy-700 hover:bg-red-500 transition-all flex items-center justify-center"
                      >
                        -
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <button
            onClick={handleUndo}
            disabled={actionHistory.length === 0}
            className="py-3 px-4 rounded-lg font-semibold bg-navy-800 border border-navy-700 hover:border-basketball-orange-500 transition-all disabled:opacity-50"
          >
            Undo
          </button>
          <button
            onClick={handleClearAll}
            className="py-3 px-4 rounded-lg font-semibold bg-navy-800 border border-navy-700 hover:border-red-500 transition-all"
          >
            Clear All
          </button>
        </div>
      </div>

      {/* Complete Game Button */}
      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-navy-950 via-navy-950/90 to-transparent">
        <button
          onClick={completeGame}
          className="w-full py-4 rounded-lg font-bold text-lg text-white bg-basketball-orange-500 hover:bg-basketball-orange-600 transition-all"
        >
          Complete Game
        </button>
      </div>
    </div>
  );
}