import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { AlertTriangle, RefreshCw, Home, Bug } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackComponent?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  errorCount: number;
}

export class ErrorBoundary extends Component<Props, State> {
  private resetTimeoutId: NodeJS.Timeout | null = null;

  constructor(props: Props) {
    super(props);
    
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): State {
    // Update state so the next render will show the fallback UI
    return {
      hasError: true,
      error,
      errorInfo: null,
      errorCount: 0
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log error to console in development
    if (import.meta.env.DEV) {
      console.error('ErrorBoundary caught an error:', error, errorInfo);
    }

    // Update state with error details
    this.setState(prevState => ({
      errorInfo,
      errorCount: prevState.errorCount + 1
    }));

    // Call custom error handler if provided
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Log to error reporting service in production
    if (import.meta.env.PROD) {
      this.logErrorToService(error, errorInfo);
    }

    // Auto-reset after multiple errors (possible infinite loop)
    if (this.state.errorCount > 3) {
      this.scheduleReset(10000); // Reset after 10 seconds
    }
  }

  componentWillUnmount() {
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }
  }

  logErrorToService = (error: Error, errorInfo: ErrorInfo) => {
    // This would be replaced with actual error reporting service
    // e.g., Sentry, LogRocket, etc.
    const errorData = {
      message: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: window.location.href
    };

    // Store in localStorage as fallback
    try {
      const errors = JSON.parse(localStorage.getItem('app_errors') || '[]');
      errors.push(errorData);
      // Keep only last 10 errors
      if (errors.length > 10) {
        errors.shift();
      }
      localStorage.setItem('app_errors', JSON.stringify(errors));
    } catch (e) {
      console.error('Failed to store error:', e);
    }
  };

  scheduleReset = (delay: number) => {
    this.resetTimeoutId = setTimeout(() => {
      this.handleReset();
    }, delay);
  };

  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      errorCount: 0
    });
  };

  handleReload = () => {
    window.location.reload();
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  handleReportBug = () => {
    const error = this.state.error;
    const errorInfo = this.state.errorInfo;
    
    // Create bug report
    const bugReport = {
      error: error?.message,
      stack: error?.stack,
      componentStack: errorInfo?.componentStack,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent
    };

    // Copy to clipboard
    navigator.clipboard.writeText(JSON.stringify(bugReport, null, 2));
    alert('Bug report copied to clipboard. Please send it to support.');
  };

  render() {
    if (this.state.hasError) {
      // Custom fallback component if provided
      if (this.props.fallbackComponent) {
        return <>{this.props.fallbackComponent}</>;
      }

      // Default error UI
      return (
        <div className="min-h-screen bg-navy-950 flex items-center justify-center p-4">
          <Card variant="navy" className="max-w-2xl w-full">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-red-500">
                <AlertTriangle className="h-6 w-6" />
                Oops! Something went wrong
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-gray-300">
                <p className="mb-2">
                  We encountered an unexpected error. The issue has been logged and our team will investigate.
                </p>
                {this.state.errorCount > 1 && (
                  <p className="text-yellow-500 text-sm">
                    Multiple errors detected. The application may be unstable.
                  </p>
                )}
              </div>

              {/* Error details in development */}
              {import.meta.env.DEV && this.state.error && (
                <div className="bg-navy-900 rounded-lg p-4 space-y-2">
                  <h3 className="text-white font-semibold">Error Details (Dev Only):</h3>
                  <div className="text-red-400 text-sm font-mono">
                    {this.state.error.message}
                  </div>
                  {this.state.error.stack && (
                    <details className="cursor-pointer">
                      <summary className="text-gray-400 hover:text-white">
                        Stack Trace
                      </summary>
                      <pre className="text-xs text-gray-500 mt-2 overflow-auto max-h-48">
                        {this.state.error.stack}
                      </pre>
                    </details>
                  )}
                  {this.state.errorInfo?.componentStack && (
                    <details className="cursor-pointer">
                      <summary className="text-gray-400 hover:text-white">
                        Component Stack
                      </summary>
                      <pre className="text-xs text-gray-500 mt-2 overflow-auto max-h-48">
                        {this.state.errorInfo.componentStack}
                      </pre>
                    </details>
                  )}
                </div>
              )}

              {/* Action buttons */}
              <div className="flex flex-wrap gap-2">
                <Button
                  onClick={this.handleReset}
                  variant="primary"
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="h-4 w-4" />
                  Try Again
                </Button>
                
                <Button
                  onClick={this.handleReload}
                  variant="secondary"
                  className="flex items-center gap-2"
                >
                  <RefreshCw className="h-4 w-4" />
                  Reload Page
                </Button>
                
                <Button
                  onClick={this.handleGoHome}
                  variant="outline"
                  className="flex items-center gap-2"
                >
                  <Home className="h-4 w-4" />
                  Go Home
                </Button>

                {import.meta.env.DEV && (
                  <Button
                    onClick={this.handleReportBug}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <Bug className="h-4 w-4" />
                    Copy Bug Report
                  </Button>
                )}
              </div>

              {/* Support information */}
              <div className="text-sm text-gray-500 border-t border-navy-800 pt-4">
                <p>If this problem persists, please contact support with the following:</p>
                <ul className="list-disc list-inside mt-2">
                  <li>Time of error: {new Date().toLocaleString()}</li>
                  <li>Your browser: {navigator.userAgent.split(' ')[0]}</li>
                  <li>Error ID: {Math.random().toString(36).substr(2, 9)}</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}

// HOC for wrapping components with error boundary
export function withErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  fallbackComponent?: ReactNode
) {
  return (props: P) => (
    <ErrorBoundary fallbackComponent={fallbackComponent}>
      <Component {...props} />
    </ErrorBoundary>
  );
}

// Dashboard-specific error boundary
export class DashboardErrorBoundary extends Component<
  { children: ReactNode; dashboardName: string },
  State
> {
  constructor(props: { children: ReactNode; dashboardName: string }) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error(`Error in ${this.props.dashboardName} dashboard:`, error, errorInfo);
    
    // Log specific dashboard error
    const dashboardError = {
      dashboard: this.props.dashboardName,
      error: error.message,
      timestamp: new Date().toISOString()
    };
    
    // Store dashboard-specific errors
    try {
      const key = `dashboard_errors_${this.props.dashboardName}`;
      const errors = JSON.parse(localStorage.getItem(key) || '[]');
      errors.push(dashboardError);
      if (errors.length > 5) errors.shift();
      localStorage.setItem(key, JSON.stringify(errors));
    } catch (e) {
      console.error('Failed to log dashboard error:', e);
    }
  }

  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
      errorCount: 0
    });
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="p-8">
          <Card variant="navy">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-yellow-500">
                <AlertTriangle className="h-5 w-5" />
                {this.props.dashboardName} Dashboard Error
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-300">
                The {this.props.dashboardName} dashboard encountered an error and couldn't load properly.
              </p>
              
              {import.meta.env.DEV && this.state.error && (
                <div className="bg-navy-900 rounded p-3">
                  <p className="text-red-400 text-sm">{this.state.error.message}</p>
                </div>
              )}
              
              <div className="flex gap-2">
                <Button onClick={this.handleReset} variant="primary">
                  Retry Loading Dashboard
                </Button>
                <Button onClick={() => window.location.reload()} variant="secondary">
                  Refresh Page
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}