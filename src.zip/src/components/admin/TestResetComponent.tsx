import React, { useState, useEffect } from 'react';
import { AlertTriangle, Database, RefreshCw, Shield, Trash2, AlertCircle } from 'lucide-react';
import DatabaseResetService from '../../services/DatabaseResetService';
import TestDataSeeder from '../../services/TestDataSeeder';
import TestAccountInitializer from '../../services/TestAccountInitializer';
import { useAuth } from '../../AuthContext';

const TestResetComponent: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [isResetting, setIsResetting] = useState(false);
  const [secondConfirm, setSecondConfirm] = useState(false);
  const [resetOption, setResetOption] = useState<'full' | 'preserve' | 'seed'>('full');
  const [resetStatus, setResetStatus] = useState<{ success?: boolean; message?: string } | null>(null);
  const [canReset, setCanReset] = useState(true);
  const [resetMessage, setResetMessage] = useState('');
  const { currentUser } = useAuth();

  useEffect(() => {
    // Check if reset is allowed
    const status = DatabaseResetService.canReset();
    setCanReset(status.allowed);
    if (status.message) {
      setResetMessage(status.message);
    }
  }, []);

  const handleReset = async () => {
    if (confirmText !== 'DELETE ALL DATA') {
      alert('Please type "DELETE ALL DATA" to confirm');
      return;
    }

    if (!secondConfirm) {
      setSecondConfirm(true);
      return;
    }

    setIsResetting(true);
    setResetStatus(null);
    
    try {
      // Perform the reset based on selected option
      const options = {
        preserveAdminAccount: resetOption === 'preserve' || resetOption === 'seed',
        seedTestData: resetOption === 'seed'
      };

      const result = await DatabaseResetService.performFullReset(options);
      
      if (result.success) {
        // If seeding test data, do it now
        if (resetOption === 'seed') {
          // First initialize test accounts
          const accountResult = await TestAccountInitializer.initializeTestAccounts();
          console.log('Test accounts initialized:', accountResult);
          
          // Then seed test data
          await TestDataSeeder.seedBasicData();
        }
        
        setResetStatus({
          success: true,
          message: `✅ ${result.message}. ${result.clearedCollections} collections cleared.`
        });
        
        // Close modal after 3 seconds and redirect
        setTimeout(() => {
          window.location.href = '/';
        }, 3000);
      } else {
        setResetStatus({
          success: false,
          message: `❌ Reset failed: ${result.error}`
        });
      }
    } catch (error: any) {
      setResetStatus({
        success: false,
        message: `❌ Reset failed: ${error.message}`
      });
    } finally {
      setIsResetting(false);
    }
  };

  const resetModal = () => {
    setShowModal(false);
    setSecondConfirm(false);
    setConfirmText('');
    setResetOption('full');
    setResetStatus(null);
  };

  // Only show for admin users
  if (!currentUser || currentUser.role !== 'admin') {
    return null;
  }

  return (
    <div className="test-reset-container">
      <div className="warning-card">
        <div className="warning-header">
          <AlertTriangle className="h-8 w-8 text-red-500" />
          <h2 className="text-2xl font-bold text-white">Test Environment Reset</h2>
          <AlertTriangle className="h-8 w-8 text-red-500" />
        </div>
        
        <p className="text-gray-300 mb-4">
          This utility completely clears all data for fresh E2E testing
        </p>
        
        <div className="warning-box">
          <AlertCircle className="h-5 w-5 text-yellow-400" />
          <span className="text-yellow-400 text-sm">
            FOR TESTING PURPOSES ONLY - This action cannot be undone!
          </span>
        </div>
        
        <button 
          onClick={() => setShowModal(true)}
          disabled={!canReset || isResetting}
          className="reset-button danger"
        >
          <Trash2 className="h-5 w-5 mr-2" />
          Reset All Data for Testing
        </button>
        
        {!canReset && (
          <p className="text-red-400 text-sm mt-2">{resetMessage}</p>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay" onClick={(e) => {
          if (e.target === e.currentTarget && !isResetting) {
            resetModal();
          }
        }}>
          <div className="reset-modal">
            {!isResetting && !resetStatus ? (
              <>
                <div className="modal-header">
                  <Database className="h-10 w-10 text-red-500" />
                  <h3 className="text-2xl font-bold text-red-600">
                    ⚠️ WARNING: Complete Data Reset
                  </h3>
                </div>
                
                {!secondConfirm ? (
                  <>
                    <div className="reset-options">
                      <h4 className="text-lg font-semibold mb-3">Reset Options:</h4>
                      
                      <label className="reset-option">
                        <input
                          type="radio"
                          value="full"
                          checked={resetOption === 'full'}
                          onChange={(e) => setResetOption('full')}
                        />
                        <div>
                          <strong>Full Reset</strong>
                          <p className="text-sm text-gray-500">Delete everything including admin account</p>
                        </div>
                      </label>
                      
                      <label className="reset-option">
                        <input
                          type="radio"
                          value="preserve"
                          checked={resetOption === 'preserve'}
                          onChange={(e) => setResetOption('preserve')}
                        />
                        <div>
                          <strong>Preserve Admin</strong>
                          <p className="text-sm text-gray-500">Keep current admin account only</p>
                        </div>
                      </label>
                      
                      <label className="reset-option">
                        <input
                          type="radio"
                          value="seed"
                          checked={resetOption === 'seed'}
                          onChange={(e) => setResetOption('seed')}
                        />
                        <div>
                          <strong>Reset & Seed</strong>
                          <p className="text-sm text-gray-500">Reset and add sample test data</p>
                        </div>
                      </label>
                    </div>
                    
                    <div className="deletion-list">
                      <p className="font-semibold mb-2">This action will delete:</p>
                      <ul className="deletion-items">
                        <li>❌ ALL teams and team data</li>
                        <li>❌ ALL players and statistics</li>
                        <li>❌ ALL games and schedules</li>
                        <li>❌ ALL standings and brackets</li>
                        <li>❌ ALL messages and notifications</li>
                        <li>❌ ALL uploaded files and images</li>
                        {resetOption === 'full' && <li>❌ ALL user accounts</li>}
                      </ul>
                    </div>
                    
                    <div className="confirmation-input">
                      <p className="font-semibold mb-2">
                        Type exactly: <span className="text-red-600">DELETE ALL DATA</span>
                      </p>
                      <input
                        type="text"
                        value={confirmText}
                        onChange={(e) => setConfirmText(e.target.value)}
                        placeholder="Type confirmation text"
                        className="confirm-input"
                        autoComplete="off"
                      />
                    </div>
                  </>
                ) : (
                  <div className="final-confirmation">
                    <div className="final-warning">
                      <Shield className="h-16 w-16 text-red-600 mx-auto mb-4" />
                      <h4 className="text-xl font-bold text-red-600 mb-4">
                        🔴 FINAL CONFIRMATION REQUIRED
                      </h4>
                      <p className="text-lg mb-2">
                        Are you ABSOLUTELY SURE you want to delete everything?
                      </p>
                      <p className="text-red-500 font-bold">
                        This action is IRREVERSIBLE!
                      </p>
                    </div>
                  </div>
                )}
                
                <div className="modal-buttons">
                  <button 
                    onClick={resetModal}
                    className="cancel-button"
                    disabled={isResetting}
                  >
                    Cancel
                  </button>
                  
                  <button 
                    onClick={handleReset}
                    disabled={isResetting || (confirmText !== 'DELETE ALL DATA' && !secondConfirm)}
                    className={`confirm-button danger ${isResetting ? 'resetting' : ''}`}
                  >
                    {isResetting ? (
                      <>
                        <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                        Resetting...
                      </>
                    ) : secondConfirm ? (
                      '🔴 YES, DELETE EVERYTHING'
                    ) : (
                      'Proceed with Reset'
                    )}
                  </button>
                </div>
              </>
            ) : isResetting ? (
              <div className="reset-progress">
                <RefreshCw className="h-16 w-16 text-red-500 animate-spin mx-auto mb-4" />
                <h3 className="text-xl font-bold text-center mb-2">Resetting Database...</h3>
                <p className="text-gray-500 text-center">Please wait, this may take a few moments</p>
                <div className="progress-bar">
                  <div className="progress-fill"></div>
                </div>
              </div>
            ) : resetStatus ? (
              <div className="reset-result">
                {resetStatus.success ? (
                  <>
                    <div className="success-icon">✅</div>
                    <h3 className="text-xl font-bold text-green-600 mb-2">Reset Complete!</h3>
                    <p className="text-gray-600">{resetStatus.message}</p>
                    <p className="text-sm text-gray-500 mt-4">Redirecting to home page...</p>
                  </>
                ) : (
                  <>
                    <div className="error-icon">❌</div>
                    <h3 className="text-xl font-bold text-red-600 mb-2">Reset Failed</h3>
                    <p className="text-gray-600">{resetStatus.message}</p>
                    <button onClick={resetModal} className="cancel-button mt-4">
                      Close
                    </button>
                  </>
                )}
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
};

export default TestResetComponent;